__author__ = 'incipe'

from pico2d import *
import random

class Auto_Down_Attack_Object:
    DOWN_ATTACK = 0

    def __init__(self):

        self.state = self.DOWN_ATTACK

        self.down_attack_object_1 = load_image('resource\\AttackObject\\down_attack_object.png')
        self.down_attack_object_2 = load_image('resource\\AttackObject\\down_attack_object.png')
        self.down_attack_object_3 = load_image('resource\\AttackObject\\down_attack_object.png')
        self.down_attack_object_4 = load_image('resource\\AttackObject\\down_attack_object.png')

        #Object1
        self.object_x1=240
        self.object_y1=360

        #Object2
        self.object_x2=615
        self.object_y2=265

        #Object3
        self.object_x3=340
        self.object_y3=565

        #Object4
        self.object_x4=590
        self.object_y4=565


    def draw(self):
        self.down_attack_object_1.draw(self.object_x1, self.object_y1)
        self.down_attack_object_2.draw(self.object_x2, self.object_y2)
        self.down_attack_object_3.draw(self.object_x3, self.object_y3)
        self.down_attack_object_4.draw(self.object_x4, self.object_y4)


    def get_bb(self):
        return self.x-5.5,self.y-5.5,self.x+5.5,self.y+5.5

    def draw_bb(self):
        draw_rectangle(*self.get_bb())



class Auto_Left_Attack_Object:
    LEFT_ATTACK = 0

    def __init__(self):

        self.left_attack_object_1 = load_image('resource\\AttackObject\\left_attack_object.png')
        self.left_attack_object_2 = load_image('resource\\AttackObject\\left_attack_object.png')
        self.state = self.LEFT_ATTACK

        #Object1
        self.object_x1=185
        self.object_y1=240

        #Object2
        self.object_x2=140
        self.object_y2=465


    def draw(self):
        self.left_attack_object_1.draw(self.object_x1, self.object_y1)
        self.left_attack_object_2.draw(self.object_x2, self.object_y2)

    def get_bb(self):
        return self.x-5.5,self.y-5.5,self.x+5.5,self.y+5.5

    def draw_bb(self):
        draw_rectangle(*self.get_bb())




class Auto_Right_Attack_Object:

    def __init__(self):
        self.right_attack_object_1 = load_image('resource\\AttackObject\\right_attack_object.png')

        #Object1
        self.object_x1=765
        self.object_y1=40


    def draw(self):
        self.right_attack_object_1.draw(self.object_x1, self.object_y1)


    def get_bb(self):
        return self.x-5.5,self.y-5.5,self.x+5.5,self.y+5.5

    def draw_bb(self):
        draw_rectangle(*self.get_bb())

