__author__ = 'incipe'

from pico2d import *
import random


class Down_Attack_Ranger:
    DA = 0

    PIXEL_PER_METER = (10.0 / 0.3)
    RUN_SPEED_KMPH = 20.0
    RUN_SPEED_MPM = (RUN_SPEED_KMPH * 1000.0 / 60.0)
    RUN_SPEED_MPS = (RUN_SPEED_MPM / 60.0)
    RUN_SPEED_PPS = (RUN_SPEED_MPS * PIXEL_PER_METER)

    TIME_PER_ACTION = 0.5
    ACTION_PER_TIME = 1.0 / TIME_PER_ACTION
    FRAMES_PER_ACTION = 8

    def __init__(self):

       #Base Setting
        self.frame = random.randint(0, 1)
        self.down_attack = load_image('resource\\AttackObject\\attack.png')
        self.state = 0
        self.x=0
        self.y=0
        self.total_frames = 0



    def DownAttackUpdate(self, frame_time,State,DA):
        self.distance = Down_Attack_Ranger.RUN_SPEED_PPS * frame_time
        self.total_frames += Down_Attack_Ranger.FRAMES_PER_ACTION * Down_Attack_Ranger.ACTION_PER_TIME * frame_time

        # 상태 변환에 따른 원거리 공격(발사체) 초기화,#
        #  * 최대 범위 및 충돌체크는 main_state에서 * #


        if State == DA:
              if self.y > 0:
                self.y = 0
              elif self.x !=0:
                 self.x = 0
              else:
                self.y -= (self.distance/2)


        #원거리 공격 사거리
        if self.y <= -180:
            self.y = 0


    def DownAttackDraw(self,x,y,State,DA):
        if State == DA:
             self.down_attack.draw(self.x + x, self.y + y)


    def get_bb(self,x,y):
        return self.x + x - 5.5,self.y + y - 5.5,self.x + x + 5.5,self.y + y +5.5

    def get_bb2(self,x,y):
        return (self.x + x) - 5.5,(self.y + y) - 5.5,(self.x + x) + 5.5,(self.y + y) +5.5

    def draw_bb(self,x,y):
        draw_rectangle(*self.get_bb(x,y))





class Left_Attack_Ranger:
    LA = 0

    PIXEL_PER_METER = (10.0 / 0.3)
    RUN_SPEED_KMPH = 20.0
    RUN_SPEED_MPM = (RUN_SPEED_KMPH * 1000.0 / 60.0)
    RUN_SPEED_MPS = (RUN_SPEED_MPM / 60.0)
    RUN_SPEED_PPS = (RUN_SPEED_MPS * PIXEL_PER_METER)

    TIME_PER_ACTION = 0.5
    ACTION_PER_TIME = 1.0 / TIME_PER_ACTION
    FRAMES_PER_ACTION = 8

    def __init__(self):

       #Base Setting
        self.frame = random.randint(0, 1)
        self.left_attack = load_image('resource\\AttackObject\\left_attack.png')
        self.state = self.LA
        self.x=0
        self.y=0
        self.total_frames = 0



    def LeftAttackUpdate(self, frame_time,State,LA):
        self.distance = Left_Attack_Ranger.RUN_SPEED_PPS * frame_time
        self.total_frames += Left_Attack_Ranger.FRAMES_PER_ACTION * Left_Attack_Ranger.ACTION_PER_TIME * frame_time

        # 상태 변환에 따른 원거리 공격(발사체) 초기화,#
        #  * 최대 범위 및 충돌체크는 main_state에서 * #


        if State == LA:
            if self.x < 0:
                self.x = 0
            elif self.y !=0:
               self.y = 0
            else:
                self.x += self.distance


        #원거리 공격 사거리
        if self.x >= 180:
            self.x = 0


    def DownAttackDraw(self,x,y,State,DA):
        if State == DA:
             self.left_attack.draw(self.x + x, self.y + y)

    def get_bb(self,x,y):
        return self.x + x - 5.5,self.y + y - 5.5,self.x + x + 5.5,self.y + y +5.5

    def get_bb2(self,x,y):
        return (self.x + x) - 5.5,(self.y + y) - 5.5,(self.x + x) + 5.5,(self.y + y) +5.5

    def draw_bb(self,x,y):
        draw_rectangle(*self.get_bb(x,y))