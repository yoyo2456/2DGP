import random
import json
import os
from pico2d import *
from maze import *
from Player import *
from Player_Ranger import *
from AI import *
from AI_Ranger import *
from Jewelry import *
from Attack_Object import *
from Attack_Object_Ragner import *
from pico2d import *


import title_state
import game_framework




name = "MainState"
count = None
font = None



def get_frame_time():

    global current_time

    frame_time = get_time() - current_time
    current_time += frame_time
    return frame_time


# Global 변수 및 기타 변수 선언
def enter():

    #Player 관련
    global player,background
    global ranger #플레이어 원거리 공격

    #AI 관련
    global ai_1,ai_2,ai_3,ai_4
    global ai_ranger_1,ai_ranger_2,ai_ranger_3,ai_ranger_4
    global ai_1s

    #Map 관련
    global out_tile,in_tile

    #보석 관련
    global blue_jewelry,red_jewelry, green_jewelry, yellow_jewelry

    #Attack 오브젝트 관련
    global auto_down_attack_object,auto_left_attack_object,auto_right_attack_object
    global auto_down_ranger,auto_left_ranger

    #-s 관련
    global out_tiles, in_tiles, blue_jewelrys, red_jewelrys, green_jewelrys, yellow_jewelrys,rangers

    #Font 관련
    global font


    player = Player()
    ranger = Ranger()

    font = load_font('Font\\2DGP.TTF')

    ai_1 = AI_1()
    ai_2 = AI_2()
    ai_3 = AI_3()
    ai_4 = AI_4()

    ai_ranger_1 = AI_Ranger_1()
    ai_ranger_2 = AI_Ranger_2()
    ai_ranger_3 = AI_Ranger_3()
    ai_ranger_4 = AI_Ranger_4()



    background = Background()
    out_tile = Out_Tile()
    in_tile = In_Tile()

    in_tiles = in_tile.create_in_tile()
    #out_tiles = out_tile.create_out_tile()

    red_jewelry = red_Jewelry()
    blue_jewelry = blue_Jewelry()
    green_jewelry = green_Jewelry()
    yellow_jewelry = yellow_Jewelry()

    blue_jewelrys = blue_jewelry.create_blue_jewelry()
    red_jewelrys = red_jewelry.create_red_jewelry()
    green_jewelrys = green_jewelry.create_green_jewelry()
    yellow_jewelrys =  yellow_jewelry.create_yellow_jewelry()

    auto_down_attack_object =  Auto_Down_Attack_Object()
    auto_left_attack_object =  Auto_Left_Attack_Object()
    auto_right_attack_object = Auto_Right_Attack_Object()

    auto_down_ranger = Down_Attack_Ranger()
    auto_left_ranger = Left_Attack_Ranger()



# Collide
def collide(a,b):
     left_a, bottom_a, right_a, top_a = a.get_bb()
     left_b, bottom_b, right_b, top_b = b.get_bb()

     if left_a > right_b:
         return False
     if right_a < left_b:
         return False
     if top_a < bottom_b:
          return False
     if bottom_a > top_b:
          return False
     return True


# Collide2, Ranger 전용
def collide2(a,b,player_x,player_y):
     left_a, bottom_a, right_a, top_a = a.get_bb2(player_x,player_y)
     left_b, bottom_b, right_b, top_b = b.get_bb()

     if left_a > right_b:
         return False
     if right_a < left_b:
         return False
     if top_a < bottom_b:
          return False
     if bottom_a > top_b:
          return False
     return True




def handle_events(frame_time):
    events = get_events()
    for event in events:
        if event.type == SDL_QUIT:
            game_framework.quit()
        elif event.type == SDL_KEYDOWN and event.key == SDLK_ESCAPE:
            game_framework.change_state(title_state)
        else:
            player.handle_event(event)

current_time = 0.0



def update(frame_time):
    global out_tile,out_tiles,in_tile,in_tiles,road,roads
    global count

    out_tiles = out_tile.create_out_tile() #Frame 조절용

    #jewelry get & reomove
    for blue_jewelry in blue_jewelrys:
        if collide(player, blue_jewelry):
           blue_jewelrys.remove(blue_jewelry)
           player.get_BJ()

    for yellow_jewelry in yellow_jewelrys:
        if collide(player, yellow_jewelry):
           yellow_jewelrys.remove(yellow_jewelry)
           player.get_YJ()

    for red_jewelry in red_jewelrys:
        if collide(player, red_jewelry):
           red_jewelrys.remove(red_jewelry)
           player.get_RJ()

    for green_jewelry in green_jewelrys:
        if collide(player, green_jewelry):
           green_jewelrys.remove(green_jewelry)
           player.get_GJ()


 # 기본적인 IF 조건 설정 후 내부에서 '25' 수치를 이용해 각 방향에 따른 충돌체크 보정#

#.........................................................................#
                  # player, AI Collide  #

    #1-1 Player Ranger, AI  attack Collide
    if collide2(ranger,ai_1,player.x,player.y):
          if player.state == player.LEFT_ATTACK:
               if player.x + ranger.x  < ai_1.x:
                   ranger.x = 0
                   ai_1.hp -=15
                   if ai_1.hp <= 0:
                       ai_1.switch = False

          if player.state == player.RIGHT_ATTACK:
               if player.x + ranger.x  < ai_1.x:
                   ranger.x = 0
                   ai_1.hp -=15
                   if ai_1.hp <= 0:
                       ai_1.switch = False

          if player.state == player.UP_ATTACK :
               if player.y + ranger.y  < ai_1.y:
                   ranger.y = 0
                   ai_1.hp -=15
                   if ai_1.hp <= 0:
                       ai_1.switch = False

          if player.state == player.DOWN_ATTACK:
               if player.y + ranger.y - 25 < ai_1.y:
                   ranger.y = 0
                   ai_1.hp -=15
                   if ai_1.hp <= 0:
                       ai_1.switch = False

    #1-2 Player Ranger, AI  attack Collide
    if collide2(ranger,ai_2,player.x,player.y):
          if player.state == player.LEFT_ATTACK:
               if player.x + ranger.x  < ai_2.x:
                   ranger.x = 0
                   ai_2.hp -=15
                   if ai_2.hp <= 0:
                       ai_2.switch = False

          if player.state == player.RIGHT_ATTACK:
               if player.x + ranger.x  < ai_2.x:
                   ranger.x = 0
                   ai_2.hp -=15
                   if ai_2.hp <= 0:
                       ai_2.switch = False

          if player.state == player.UP_ATTACK :
               if player.y + ranger.y  < ai_2.y:
                   ranger.y = 0
                   ai_2.hp -=15
                   if ai_2.hp <= 0:
                       ai_2.switch = False

          if player.state == player.DOWN_ATTACK:
               if player.y + ranger.y - 25 < ai_2.y:
                   ranger.y = 0
                   ai_2.hp -=15
                   if ai_2.hp <= 0:
                       ai_2.switch = False


    #1-3 Player Ranger, AI  attack Collide
    if collide2(ranger,ai_3,player.x,player.y):
          if player.state == player.LEFT_ATTACK:
               if player.x + ranger.x  < ai_3.x:
                   ranger.x = 0
                   ai_3.hp -=15
                   if ai_3.hp <= 0:
                       ai_3.switch = False

          if player.state == player.RIGHT_ATTACK:
               if player.x + ranger.x  < ai_3.x:
                   ranger.x = 0
                   ai_3.hp -=15
                   if ai_3.hp <= 0:
                       ai_3.switch = False

          if player.state == player.UP_ATTACK :
               if player.y + ranger.y  < ai_3.y:
                   ranger.y = 0
                   ai_3.hp -=15
                   if ai_3.hp <= 0:
                       ai_3.switch = False

          if player.state == player.DOWN_ATTACK:
               if player.y + ranger.y - 25 < ai_3.y:
                   ranger.y = 0
                   ai_3.hp -=15
                   if ai_3.hp <= 0:
                       ai_3.switch = False

    #1-4 Player Ranger, AI  attack Collide
    if collide2(ranger,ai_4,player.x,player.y):
          if player.state == player.LEFT_ATTACK:
               if player.x + ranger.x  < ai_4.x:
                   ranger.x = 0
                   ai_4.hp -=15
                   if ai_4.hp <= 0:
                       ai_4.switch = False

          if player.state == player.RIGHT_ATTACK:
               if player.x + ranger.x  < ai_4.x:
                   ranger.x = 0
                   ai_4.hp -=15
                   if ai_4.hp <= 0:
                       ai_4.switch = False

          if player.state == player.UP_ATTACK :
               if player.y + ranger.y  < ai_4.y:
                   ranger.y = 0
                   ai_4.hp -=15
                   if ai_4.hp <= 0:
                       ai_4.switch = False

          if player.state == player.DOWN_ATTACK:
               if player.y + ranger.y - 25 < ai_4.y:
                   ranger.y = 0
                   ai_4.hp -=15
                   if ai_4.hp <= 0:
                       ai_4.switch = False


#.........................................................................#





#.........................................................................#
                  # player 관련 Collide #

    # Out_tile 관련 Collide
    for out_tile in out_tiles:
        #Player, tile Attack Collide(원거리 공격)
       if collide2(ranger,out_tile,player.x,player.y):
           if player.state == player.LEFT_ATTACK:
               if player.x + ranger.x  < out_tile.x:
                   ranger.x = 0

           if player.state == player.RIGHT_ATTACK:
               if player.x + ranger.x + 75 > out_tile.x: # xPos +75 보정값
                   ranger.x = 0

           if player.state == player.UP_ATTACK :
               if player.y + ranger.y + 25 > out_tile.y: # yPos +25 보정값
                   ranger.y = 0

           if player.state == player.DOWN_ATTACK:
               if player.y + ranger.y + 25 > out_tile.y:
                   ranger.y = 0


    for in_tile in in_tiles:
       if collide(player,in_tile):
           #1 Player, Tile Move Collide
           if (player.state == player.LEFT_MOVE or player.state == player.STANDING):
                if player.x  < in_tile.x:
                   if player.x > in_tile.x + 25:
                       pass
                elif player.x < in_tile.x + 25:
                      player.leftCollide_Player()

           if (player.state == player.RIGHT_MOVE or player.state == player.STANDING):
                if player.x  < in_tile.x:
                   if player.x > in_tile.x - 25:
                       pass
                   elif player.x < in_tile.x - 25:
                      player.rightCollide_Player()

           if (player.state == player.UP_MOVE or player.state == player.STANDING):
               if player.y  < in_tile.y:
                   if player.y > in_tile.y - 25:
                       pass
                   elif player.y < in_tile.y - 25:
                      player.upCollide_Player()

           if (player.state == player.DOWN_MOVE or player.state == player.STANDING):
                 if player.y  > in_tile.y:
                     player.downCollide_Player()

           #2 Player, Tile Attack Collide(근접 공격)
           if player.state == player.LEFT_ATTACK:
               if player.x  < in_tile.x:
                   if player.x > in_tile.x + 25:
                      pass
                   elif player.x < in_tile.x + 25:
                      player.leftCollide_Player()

           if player.state == player.RIGHT_ATTACK:
                if player.x  < in_tile.x:
                   if player.x > in_tile.x - 25:
                       pass
                   elif player.x < in_tile.x - 25:
                      player.rightCollide_Player()

           if player.state == player.UP_ATTACK:
                if player.y  < in_tile.y:
                   if player.y > in_tile.y - 25:
                       pass
                   elif player.y < in_tile.y - 25:
                      player.upCollide_Player()

           if player.state == player.DOWN_ATTACK:
             if player.y  > in_tile.y:
                 player.downCollide_Player()


    #3 player, Tile Attack Collide(원거리 공격)
    for in_tile in in_tiles:
       if collide2(ranger,in_tile,player.x,player.y):

           if player.state == player.LEFT_ATTACK:
               if player.x + ranger.x  < in_tile.x:
                   ranger.x = 0

           if player.state == player.RIGHT_ATTACK:
               if player.x + ranger.x  < in_tile.x:
                   ranger.x = 0

           if player.state == player.UP_ATTACK :
               if player.y + ranger.y  < in_tile.y:
                   ranger.y = 0

           if player.state == player.DOWN_ATTACK:
               if player.y + ranger.y - 25 < in_tile.y:
                   ranger.y = 0

#.........................................................................#




#.........................................................................#
                  # AI 관련 Collide  #

    # Out_tile 관련 Collide
    for out_tile in out_tiles:
        #AI_1, tile Attack Collide(원거리 공격)
       if collide2(ai_ranger_1,out_tile,ai_1.x,ai_1.y):
           if ai_1.state == ai_1.LEFT_MOVE:
               if ai_1.x + ai_ranger_1.x -25 < out_tile.x:
                   ai_ranger_1.x = 0

           if ai_1.state == ai_1.RIGHT_MOVE:
               if ai_1.x + ai_ranger_1.x  > out_tile.x:
                   ai_ranger_1.x = 0

           if ai_1.state == ai_1.UP_MOVE :
               if ai_1.y + ai_ranger_1.y  > out_tile.y:
                   ai_ranger_1.y = 0

           if ai_1.state == ai_1.DOWN_MOVE:
               if ai_1.y + ai_ranger_1.y + 25  < out_tile.y:
                   ai_ranger_1.y = 0

       #AI_2, tile Attack Collide(원거리 공격)
       if collide2(ai_ranger_2,out_tile,ai_2.x,ai_2.y):
           if ai_2.state == ai_2.LEFT_MOVE:
               if ai_2.x + ai_ranger_2.x -25 < out_tile.x:
                   ai_ranger_2.x = 0

           if ai_2.state == ai_2.RIGHT_MOVE:
               if ai_2.x + ai_ranger_2.x  > out_tile.x:
                   ai_ranger_2.x = 0

           if ai_2.state == ai_2.UP_MOVE :
               if ai_2.y + ai_ranger_2.y  > out_tile.y: # yPos +25 보정값
                   ai_ranger_2.y = 0

           if ai_2.state == ai_2.DOWN_MOVE:
               if ai_2.y + ai_ranger_2.y + 25 < out_tile.y:
                   ai_ranger_2.y = 0


       #AI_3, tile Attack Collide(원거리 공격)
       if collide2(ai_ranger_3,out_tile,ai_3.x,ai_3.y):
           if ai_3.state == ai_3.LEFT_MOVE:
               if ai_3.x + ai_ranger_3.x - 25 < out_tile.x:
                   ai_ranger_3.x = 0

           if ai_3.state == ai_3.RIGHT_MOVE:
               if ai_3.x + ai_ranger_3.x  > out_tile.x:
                   ai_ranger_3.x = 0

           if ai_3.state == ai_3.UP_MOVE :
               if ai_3.y + ai_ranger_3.y  >  out_tile.y: # yPos +25 보정값
                   ai_ranger_3.y = 0

           if ai_3.state == ai_3.DOWN_MOVE:
               if ai_3.y + ai_ranger_3.y + 25 <  out_tile.y:
                   ai_ranger_3.y = 0


        #AI_4, tile Attack Collide(원거리 공격)
       if collide2(ai_ranger_4,out_tile,ai_4.x,ai_4.y):
           if ai_4.state == ai_4.LEFT_MOVE:
               if ai_4.x + ai_ranger_4.x - 25 < out_tile.x:
                   ai_ranger_4.x = 0

           if ai_4.state == ai_4.RIGHT_MOVE:
               if ai_4.x + ai_ranger_4.x  > out_tile.x:
                   ai_ranger_4.x = 0

           if ai_4.state == ai_4.UP_MOVE :
               if ai_4.y + ai_ranger_4.y  > out_tile.y: # yPos +25 보정값
                   ai_ranger_4.y = 0

           if ai_4.state == ai_4.DOWN_MOVE:
               if ai_4.y + ai_ranger_4.y + 25 < out_tile.y:
                   ai_ranger_4.y = 0




    #In_tile 관련 Collide
    for in_tile in in_tiles:
          #1-1. AI_1, Tile Move Collide
          if collide(ai_1,in_tile):
              if (ai_1.state == ai_1.RIGHT_MOVE):
                  if ai_1.x < in_tile.x:
                      ai_1.x-=5
                      ai_1.state=random.randint(1,4)
              elif (ai_1.state == ai_1.UP_MOVE):
                  if ai_1.y < in_tile.y:
                      ai_1.y-=5
                      ai_1.state=random.randint(1,4)
                  while 1:
                    if(ai_1.state == ai_1.UP_MOVE):
                        ai_1.state=random.randint(1,4)
                    else:
                        break;
              elif (ai_1.state == ai_1.LEFT_MOVE):
                  if ai_1.x > in_tile.x:
                      ai_1.x+=5
                      ai_1.state=random.randint(1,4)
                  while 1:
                     if(ai_1.state == ai_1.LEFT_MOVE):
                         ai_1.state=random.randint(1,4)
                     else:
                        break;
              elif (ai_1.state == ai_1.DOWN_MOVE):
                   if ai_1.y > in_tile.y:
                       ai_1.y+=5
                       ai_1.state=random.randint(1,4)

          #1-2. AI_1, Tile Attack Collide(원거리 공격)
          if collide2(ai_ranger_1,in_tile,ai_1.x,ai_1.y):
              if ai_1.state == ai_1.LEFT_MOVE:
                  if ai_1.x + ai_ranger_1.x  < in_tile.x:
                      ai_ranger_1.x = 0

              if ai_1.state == ai_1.RIGHT_MOVE:
                  if ai_1.x + ai_ranger_1.x  > in_tile.x:
                      ai_ranger_1.x = 0

              if ai_1.state == ai_1.UP_MOVE:
                  if ai_1.y + ai_ranger_1.y + 25 > in_tile.y: # yPos +25 보정값
                      ai_ranger_1.y = 0

              if ai_1.state == ai_1.DOWN_MOVE:
                  if ai_1.y + ai_ranger_1.y < in_tile.y:
                      ai_ranger_1.y = 0

          #2-1 AI_2, Tile Move Collide
          if collide(ai_2,in_tile):
              if (ai_2.state == ai_2.RIGHT_MOVE):
                  if ai_2.x < in_tile.x:
                      ai_2.x-=5
                      ai_2.state=random.randint(1,4)
              elif (ai_2.state == ai_2.UP_MOVE):
                  if ai_2.y < in_tile.y:
                      ai_2.y-=5
                      ai_2.state=random.randint(1,4)
                  while 1:
                    if(ai_2.state == ai_2.UP_MOVE):
                        ai_2.state=random.randint(1,4)
                    else:
                        break;
              elif (ai_2.state == ai_2.LEFT_MOVE):
                  if ai_2.x > in_tile.x:
                      ai_2.x+=5
                      ai_2.state=random.randint(1,4)
                  while 1:
                     if(ai_2.state == ai_2.LEFT_MOVE):
                         ai_2.state=random.randint(1,4)
                     else:
                        break;
              elif (ai_2.state == ai_2.DOWN_MOVE):
                   if ai_2.y > in_tile.y:
                       ai_2.y+=5
                       ai_2.state=random.randint(1,4)

          #2-2. AI_2, Tile Attack Collide(원거리 공격)
          if collide2(ai_ranger_2,in_tile,ai_2.x,ai_2.y):
              if ai_2.state == ai_2.LEFT_MOVE:
                  if ai_2.x + ai_ranger_2.x  < in_tile.x:
                      ai_ranger_2.x = 0

              if ai_2.state == ai_2.RIGHT_MOVE:
                  if ai_2.x + ai_ranger_2.x  > in_tile.x:
                      ai_ranger_2.x = 0

              if ai_2.state == ai_2.UP_MOVE:
                  if ai_2.y + ai_ranger_2.y + 25 > in_tile.y: # yPos +25 보정값
                      ai_ranger_2.y = 0

              if ai_2.state == ai_2.DOWN_MOVE:
                  if ai_2.y + ai_ranger_2.y < in_tile.y:
                      ai_ranger_2.y = 0


          #3-1 AI_3, Tile Move Collide
          if collide(ai_3,in_tile):
              if (ai_3.state == ai_3.RIGHT_MOVE):
                  if ai_3.x < in_tile.x:
                      ai_3.x-=5
                      ai_3.state=random.randint(1,4)
              elif (ai_3.state == ai_3.UP_MOVE):
                  if ai_3.y < in_tile.y:
                      ai_3.y-=5
                      ai_3.state=random.randint(1,4)
                  while 1:
                    if(ai_3.state == ai_3.UP_MOVE):
                        ai_3.state=random.randint(1,4)
                    else:
                        break;
              elif (ai_3.state == ai_3.LEFT_MOVE):
                  if ai_3.x > in_tile.x:
                      ai_3.x+=5
                      ai_3.state=random.randint(1,4)
                  while 1:
                     if(ai_3.state == ai_3.LEFT_MOVE):
                         ai_3.state=random.randint(1,4)
                     else:
                        break;
              elif (ai_3.state == ai_3.DOWN_MOVE):
                   if ai_3.y > in_tile.y:
                       ai_3.y+=5
                       ai_3.state=random.randint(1,4)

           #3-2. AI_3, Tile Attack Collide(원거리 공격)
          if collide2(ai_ranger_3,in_tile,ai_3.x,ai_3.y):
              if ai_3.state == ai_3.LEFT_MOVE:
                  if ai_3.x + ai_ranger_3.x  < in_tile.x:
                      ai_ranger_3.x = 0

              if ai_3.state == ai_3.RIGHT_MOVE:
                  if ai_3.x + ai_ranger_3.x  > in_tile.x:
                      ai_ranger_3.x = 0

              if ai_3.state == ai_3.UP_MOVE:
                  if ai_3.y + ai_ranger_3.y + 25 > in_tile.y: # yPos +25 보정값
                      ai_ranger_3.y = 0

              if ai_3.state == ai_3.DOWN_MOVE:
                  if ai_3.y + ai_ranger_3.y < in_tile.y:
                      ai_ranger_3.y = 0



          #4 AI_4, Tile Move Collide
          if collide(ai_4,in_tile):
              if (ai_4.state == ai_4.RIGHT_MOVE):
                  if ai_4.x < in_tile.x:
                      ai_4.x-=5
                      ai_4.state=random.randint(1,4)
              elif (ai_4.state == ai_4.UP_MOVE):
                  if ai_4.y < in_tile.y:
                      ai_4.y-=5
                      ai_4.state=random.randint(1,4)
                  while 1:
                    if(ai_4.state == ai_4.UP_MOVE):
                        ai_4.state=random.randint(1,4)
                    else:
                        break;
              elif (ai_4.state == ai_4.LEFT_MOVE):
                  if ai_4.x > in_tile.x:
                      ai_4.x+=5
                      ai_4.state=random.randint(1,4)
                  while 1:
                     if(ai_4.state == ai_4.LEFT_MOVE):
                         ai_4.state=random.randint(1,4)
                     else:
                        break;
              elif (ai_4.state == ai_4.DOWN_MOVE):
                   if ai_4.y > in_tile.y:
                       ai_4.y+=5
                       ai_4.state=random.randint(1,4)

          #4-2. AI_4, Tile Attack Collide(원거리 공격)
          if collide2(ai_ranger_4,in_tile,ai_4.x,ai_4.y):
              if ai_4.state == ai_4.LEFT_MOVE:
                  if ai_4.x + ai_ranger_4.x  < in_tile.x:
                      ai_ranger_4.x = 0

              if ai_4.state == ai_4.RIGHT_MOVE:
                  if ai_4.x + ai_ranger_4.x  > in_tile.x:
                      ai_ranger_4.x = 0

              if ai_4.state == ai_4.UP_MOVE:
                  if ai_4.y + ai_ranger_4.y + 25 > in_tile.y: # yPos +25 보정값
                      ai_ranger_4.y = 0

              if ai_4.state == ai_4.DOWN_MOVE:
                  if ai_4.y + ai_ranger_4.y < in_tile.y:
                      ai_ranger_4.y = 0


#.........................................................................#


    player.update(frame_time)
    ranger.AttackUpdate(frame_time,player.state, player.RIGHT_ATTACK, player.LEFT_ATTACK, player.UP_ATTACK, player.DOWN_ATTACK,player.STANDING)
    auto_down_ranger.DownAttackUpdate(frame_time,auto_down_attack_object.state,auto_down_attack_object.DOWN_ATTACK)
    auto_left_ranger.LeftAttackUpdate(frame_time,auto_left_attack_object.state,auto_left_attack_object.LEFT_ATTACK)


    if ai_1.switch == True:
        ai_ranger_1.AttackUpdate(frame_time,ai_1.state, ai_1.RIGHT_MOVE, ai_1.LEFT_MOVE, ai_1.UP_MOVE, ai_1.DOWN_MOVE)
        ai_1.update(frame_time)

    if ai_2.switch == True:
        ai_ranger_2.AttackUpdate(frame_time,ai_2.state, ai_2.RIGHT_MOVE, ai_2.LEFT_MOVE, ai_2.UP_MOVE, ai_2.DOWN_MOVE)
        ai_2.update(frame_time)

    if ai_3.switch == True:
       ai_ranger_3.AttackUpdate(frame_time,ai_3.state, ai_3.RIGHT_MOVE, ai_3.LEFT_MOVE, ai_3.UP_MOVE, ai_3.DOWN_MOVE)
       ai_3.update(frame_time)

    if ai_4.switch == True:
      ai_ranger_4.AttackUpdate(frame_time,ai_4.state, ai_4.RIGHT_MOVE, ai_4.LEFT_MOVE, ai_4.UP_MOVE, ai_4.DOWN_MOVE)
      ai_4.update(frame_time)











def draw(frame_time):
    clear_canvas()

   #........Draw Background........#
    background.draw()

    #........Draw Tile.........#
    for out_tile in out_tiles:
        out_tile.draw()
        #out_tile.draw_bb()

    for in_tile in in_tiles:
        in_tile.draw()
        #in_tile.draw_bb()


    #........Draw Jewely.........#
    for red_jewelry in red_jewelrys:
        red_jewelry.draw()
        #red_jewelry.draw_bb()

    for green_jewelry in green_jewelrys:
        green_jewelry.draw()
        #green_jewelry.draw_bb()

    for yellow_jewelry in yellow_jewelrys:
        yellow_jewelry.draw()
        #yellow_jewelry.draw_bb()

    for blue_jewelry in blue_jewelrys:
        blue_jewelry.draw()


   #........Draw Font.........#
    font.draw(25,590, 'Blue : %d' % (player.BJ_count),(0,0,255))
    font.draw(100,590, 'Red : %d' % (player.RJ_count),(255,0,0))
    font.draw(160,590, 'Yellow : %d' % (player.YJ_count),(255,255,0))
    font.draw(245,590, 'Green : %d' % (player.GJ_count),(0,255,0))
    font.draw(320,590, 'player.x : %d' % (player.x),(0,255,0))
    font.draw(450,590, 'ranger.x : %d' % (ranger.x),(0,255,0))
    font.draw(320,490, '[AI_1.hp : %d]' % (ai_1.hp),(255,255,0))

    #........Draw Player.........#
    player.draw()
    player.draw_bb()
    ranger.AttackDraw(player.x, player.y,player.state,player.RIGHT_ATTACK,player.LEFT_ATTACK,player.UP_ATTACK,player.DOWN_ATTACK) #원거리 공격 Draw
    #ranger.draw_bb(player.x, player.y) #원거리 공격 Bounding Bax Draw


    #........Draw Auto.........#

    auto_down_ranger.DownAttackDraw(auto_down_attack_object.object_x1,auto_down_attack_object.object_y1,auto_down_attack_object.state,auto_down_attack_object.DOWN_ATTACK)
    auto_down_ranger.DownAttackDraw(auto_down_attack_object.object_x2,auto_down_attack_object.object_y2,auto_down_attack_object.state,auto_down_attack_object.DOWN_ATTACK)
    auto_down_ranger.DownAttackDraw(auto_down_attack_object.object_x3,auto_down_attack_object.object_y3,auto_down_attack_object.state,auto_down_attack_object.DOWN_ATTACK)
    auto_down_ranger.DownAttackDraw(auto_down_attack_object.object_x4,auto_down_attack_object.object_y4,auto_down_attack_object.state,auto_down_attack_object.DOWN_ATTACK)

    auto_left_ranger.DownAttackDraw(auto_left_attack_object.object_x1,auto_left_attack_object.object_y1,auto_left_attack_object.state,auto_left_attack_object.LEFT_ATTACK)
    auto_left_ranger.DownAttackDraw(auto_left_attack_object.object_x2,auto_left_attack_object.object_y2,auto_left_attack_object.state,auto_left_attack_object.LEFT_ATTACK)




    #........Draw AI.........#
    if ai_1.switch == True:
        ai_ranger_1.AttackDraw(ai_1.x, ai_1.y,ai_1.state,ai_1.RIGHT_MOVE,ai_1.LEFT_MOVE,ai_1.UP_MOVE,ai_1.DOWN_MOVE) # AI 원거리 공격 Draw
        ai_1.draw()

    if ai_2.switch == True:
       ai_ranger_2.AttackDraw(ai_2.x, ai_2.y,ai_2.state,ai_2.RIGHT_MOVE,ai_2.LEFT_MOVE,ai_2.UP_MOVE,ai_2.DOWN_MOVE) # AI 원거리 공격 Draw
       ai_2.draw()

    if ai_3.switch == True:
        ai_ranger_3.AttackDraw(ai_3.x, ai_3.y,ai_3.state,ai_3.RIGHT_MOVE,ai_3.LEFT_MOVE,ai_3.UP_MOVE,ai_3.DOWN_MOVE) # AI 원거리 공격 Draw
        ai_3.draw()

    if ai_4.switch == True:
        ai_ranger_4.AttackDraw(ai_4.x, ai_4.y,ai_1.state,ai_4.RIGHT_MOVE,ai_4.LEFT_MOVE,ai_4.UP_MOVE,ai_4.DOWN_MOVE) # AI 원거리 공격 Draw
        ai_4.draw()


    #..........Draw Auto Object.......#
    auto_down_attack_object.draw()
    auto_left_attack_object.draw()
    auto_right_attack_object.draw()








    update_canvas()












