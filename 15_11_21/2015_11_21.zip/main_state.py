import random
import json
import os

from pico2d import *
from maze import *
from Player import *


import game_framework
from pico2d import debug_print
import title_state


name = "MainState"

player = None
background = None
tile = None
tiles = None
font = None


def get_frame_time():

    global current_time

    frame_time = get_time() - current_time
    current_time += frame_time
    return frame_time



def enter():
    global  player,background,out_tile,in_tile

    player = Player()
    background = Background()
    out_tile = Out_Tile()
    in_tile = In_Tile()





def exit():
    pass


def pause():
    pass


def resume():
    pass

# a : Player, b : Obstacle
def collide(a,b):
     left_a, bottom_a, right_a, top_a = a.get_bb()
     left_b, bottom_b, right_b, top_b = b.get_bb()

     if left_a > right_b:
     #    a.setPosX(a.getDistance())
         return False
     if right_a < left_b:
     #    a.setPosX(a.getDistance())
         return False
     if top_a < bottom_b:
     #    a.setPosY(a.getDistance())
         return False
     if bottom_a > top_b:
     #    a.setPosY(a.getDistance())
         return False

     return True



def handle_events(frame_time):
    events = get_events()
    for event in events:
        if event.type == SDL_QUIT:
            game_framework.quit()
        elif event.type == SDL_KEYDOWN and event.key == SDLK_ESCAPE:
            game_framework.change_state(title_state)
        else:
            player.handle_event(event)

current_time = 0.0



def update(frame_time):
    global out_tile,out_tiles,in_tile,in_tiles
    global mpX,mpY

    out_tiles = out_tile.create_out_tile()
    in_tiles = in_tile.create_in_tile()

    #for out_tile in out_tiles:
       #if collide(player,out_tile):
         #   mpX,mpY = player.mpPos()
         #  if mpX < out_tile.x:
         #      player.setMinPosX( player.getDistance()+ 4)
         #  elif mpX > mpY:
         #      player.setPlusPosX( player.getDistance())
         #  elif mpY < out_tile.y:
         #      player.setMinPosY( player.getDistance())
         #  elif mpY > out_tile.y:
         #      player.setPlusPosY( player.getDistance())
               # print("UnCollisionCheck")
               #player.StopPlayer()

    for in_tile in in_tiles:
       if collide(player,in_tile):
           mpX,mpY = player.mpPos()


    player.update(frame_time)







def draw(frame_time):
    clear_canvas()
    background.draw()

    for out_tile in out_tiles:
        out_tile.draw()

    for in_tile in in_tiles:
        in_tile.draw()


   # print("main Draw -> self.x[5][4] = %d, self.y[5][4] = %d " %(tile.x[5][4],tile.y[5][4]))
    player.draw()
    update_canvas()












