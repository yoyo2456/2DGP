__author__ = 'Administrator'


from pico2d import *
import random


class AI_Ranger_1:
    RA, LA, UA, DA = 0,1,2,3

    PIXEL_PER_METER = (10.0 / 0.3)
    RUN_SPEED_KMPH = 20.0
    RUN_SPEED_MPM = (RUN_SPEED_KMPH * 1000.0 / 60.0)
    RUN_SPEED_MPS = (RUN_SPEED_MPM / 60.0)
    RUN_SPEED_PPS = (RUN_SPEED_MPS * PIXEL_PER_METER)

    TIME_PER_ACTION = 0.5
    ACTION_PER_TIME = 1.0 / TIME_PER_ACTION
    FRAMES_PER_ACTION = 8

    def __init__(self):

       #Base Setting
        self.frame = random.randint(0, 1)
        self.right_attack = load_image('resource\\AI\\ai_rightAttack.png')
        self.left_attack = load_image('resource\\AI\\ai_leftAttack.png')
        self.up_attack = load_image('resource\\AI\\ai_upAttack.png')
        self.down_attack = load_image('resource\\AI\\ai_downAttack.png')
        self.state = 0
        self.x=0
        self.y=0
        self.old_x = 0
        self.old_y = 0
        self.total_frames = 0



    def AttackUpdate(self, frame_time,State,RA,LA,UA,DA):
        self.distance = AI_Ranger_1.RUN_SPEED_PPS * frame_time
        self.total_frames += AI_Ranger_1.FRAMES_PER_ACTION * AI_Ranger_1.ACTION_PER_TIME * frame_time

        # 상태 변환에 따른 원거리 공격(발사체) 초기화,#
        #  * 최대 범위 및 충돌체크는 main_state에서 * #

        if State == RA:
            if self.x < 0:
                self.x = 0
            elif self.y !=0:
                self.y = 0
            else:
                self.x += self.distance

        if State == LA:
            if self.x > 0:
                self.x = 0
            elif self.y !=0:
               self.y = 0
            else:
                self.x -= self.distance


        if State == UA:
              if self.y < 0:
                self.y = 0
              elif self.x !=0:
                self.x = 0
              else:
                self.y += self.distance

        if State == DA:
              if self.y > 0:
                self.y = 0
              elif self.x !=0:
                 self.x = 0
              else:
                self.y -= self.distance


        #원거리 공격 사거리
        if self.x >= 80:
            self.x = 0
        if self.x <= -80:
            self.x = 0
        if self.y >= 80:
            self.y = 0
        if self.y <= -80:
            self.y = 0


    def AttackDraw(self,x,y,State,RA,LA,UA,DA):
         if State == RA:
             self.right_attack.draw(self.x + x, self.y + y)
         if State == LA:
             self.left_attack.draw(self.x + x, self.y + y)
         if State == UA:
             self.up_attack.draw(self.x + x, self.y + y)
         if State == DA:
             self.down_attack.draw(self.x + x, self.y + y)


    def get_bb(self,x,y):
        return self.x + x - 5.5,self.y + y - 5.5,self.x + x + 5.5,self.y + y +5.5

    def get_bb2(self,x,y):
        return (self.x + x) - 5.5,(self.y + y) - 5.5,(self.x + x) + 5.5,(self.y + y) +5.5

    def draw_bb(self,x,y):
        draw_rectangle(*self.get_bb(x,y))



class AI_Ranger_2:
    RA, LA, UA, DA = 0,1,2,3

    PIXEL_PER_METER = (10.0 / 0.3)
    RUN_SPEED_KMPH = 20.0
    RUN_SPEED_MPM = (RUN_SPEED_KMPH * 1000.0 / 60.0)
    RUN_SPEED_MPS = (RUN_SPEED_MPM / 60.0)
    RUN_SPEED_PPS = (RUN_SPEED_MPS * PIXEL_PER_METER)

    TIME_PER_ACTION = 0.5
    ACTION_PER_TIME = 1.0 / TIME_PER_ACTION
    FRAMES_PER_ACTION = 8

    def __init__(self):

       #Base Setting
        self.frame = random.randint(0, 1)
        self.right_attack = load_image('resource\\AI\\ai_rightAttack.png')
        self.left_attack = load_image('resource\\AI\\ai_leftAttack.png')
        self.up_attack = load_image('resource\\AI\\ai_upAttack.png')
        self.down_attack = load_image('resource\\AI\\ai_downAttack.png')
        self.state = 0
        self.x=0
        self.y=0
        self.old_x = 0
        self.old_y = 0
        self.total_frames = 0



    def AttackUpdate(self, frame_time,State,RA,LA,UA,DA):
        self.distance = AI_Ranger_2.RUN_SPEED_PPS * frame_time
        self.total_frames += AI_Ranger_2.FRAMES_PER_ACTION * AI_Ranger_2.ACTION_PER_TIME * frame_time

        # 상태 변환에 따른 원거리 공격(발사체) 초기화,#
        #  * 최대 범위 및 충돌체크는 main_state에서 * #

        if State == RA:
            if self.x < 0:
                self.x = 0
            elif self.y !=0:
                self.y = 0
            else:
                self.x += self.distance

        if State == LA:
            if self.x > 0:
                self.x = 0
            elif self.y !=0:
               self.y = 0
            else:
                self.x -= self.distance


        if State == UA:
              if self.y < 0:
                self.y = 0
              elif self.x !=0:
                self.x = 0
              else:
                self.y += self.distance

        if State == DA:
              if self.y > 0:
                self.y = 0
              elif self.x !=0:
                 self.x = 0
              else:
                self.y -= self.distance


        #원거리 공격 사거리
        if self.x >= 80:
            self.x = 0
        if self.x <= -80:
            self.x = 0
        if self.y >= 80:
            self.y = 0
        if self.y <= -80:
            self.y = 0


    def AttackDraw(self,x,y,State,RA,LA,UA,DA):
         if State == RA:
             self.right_attack.draw(self.x + x, self.y + y)
         if State == LA:
             self.left_attack.draw(self.x + x, self.y + y)
         if State == UA:
             self.up_attack.draw(self.x + x, self.y + y)
         if State == DA:
             self.down_attack.draw(self.x + x, self.y + y)


    def get_bb(self,x,y):
        return self.x + x - 5.5,self.y + y - 5.5,self.x + x + 5.5,self.y + y +5.5

    def get_bb2(self,x,y):
        return (self.x + x) - 5.5,(self.y + y) - 5.5,(self.x + x) + 5.5,(self.y + y) +5.5

    def draw_bb(self,x,y):
        draw_rectangle(*self.get_bb(x,y))




class AI_Ranger_3:
    RA, LA, UA, DA = 0,1,2,3

    PIXEL_PER_METER = (10.0 / 0.3)
    RUN_SPEED_KMPH = 20.0
    RUN_SPEED_MPM = (RUN_SPEED_KMPH * 1000.0 / 60.0)
    RUN_SPEED_MPS = (RUN_SPEED_MPM / 60.0)
    RUN_SPEED_PPS = (RUN_SPEED_MPS * PIXEL_PER_METER)

    TIME_PER_ACTION = 0.5
    ACTION_PER_TIME = 1.0 / TIME_PER_ACTION
    FRAMES_PER_ACTION = 8

    def __init__(self):

       #Base Setting
        self.frame = random.randint(0, 1)
        self.right_attack = load_image('resource\\AI\\ai_rightAttack.png')
        self.left_attack = load_image('resource\\AI\\ai_leftAttack.png')
        self.up_attack = load_image('resource\\AI\\ai_upAttack.png')
        self.down_attack = load_image('resource\\AI\\ai_downAttack.png')
        self.state = 0
        self.x=0
        self.y=0
        self.old_x = 0
        self.old_y = 0
        self.total_frames = 0



    def AttackUpdate(self, frame_time,State,RA,LA,UA,DA):
        self.distance = AI_Ranger_3.RUN_SPEED_PPS * frame_time
        self.total_frames += AI_Ranger_3.FRAMES_PER_ACTION * AI_Ranger_3.ACTION_PER_TIME * frame_time

        # 상태 변환에 따른 원거리 공격(발사체) 초기화,#
        #  * 최대 범위 및 충돌체크는 main_state에서 * #

        if State == RA:
            if self.x < 0:
                self.x = 0
            elif self.y !=0:
                self.y = 0
            else:
                self.x += self.distance

        if State == LA:
            if self.x > 0:
                self.x = 0
            elif self.y !=0:
               self.y = 0
            else:
                self.x -= self.distance


        if State == UA:
              if self.y < 0:
                self.y = 0
              elif self.x !=0:
                self.x = 0
              else:
                self.y += self.distance

        if State == DA:
              if self.y > 0:
                self.y = 0
              elif self.x !=0:
                 self.x = 0
              else:
                self.y -= self.distance


        #원거리 공격 사거리
        if self.x >= 80:
            self.x = 0
        if self.x <= -80:
            self.x = 0
        if self.y >= 80:
            self.y = 0
        if self.y <= -80:
            self.y = 0


    def AttackDraw(self,x,y,State,RA,LA,UA,DA):
         if State == RA:
             self.right_attack.draw(self.x + x, self.y + y)
         if State == LA:
             self.left_attack.draw(self.x + x, self.y + y)
         if State == UA:
             self.up_attack.draw(self.x + x, self.y + y)
         if State == DA:
             self.down_attack.draw(self.x + x, self.y + y)


    def get_bb(self,x,y):
        return self.x + x - 5.5,self.y + y - 5.5,self.x + x + 5.5,self.y + y +5.5

    def get_bb2(self,x,y):
        return (self.x + x) - 5.5,(self.y + y) - 5.5,(self.x + x) + 5.5,(self.y + y) +5.5

    def draw_bb(self,x,y):
        draw_rectangle(*self.get_bb(x,y))






class AI_Ranger_4:
    RA, LA, UA, DA = 0,1,2,3

    PIXEL_PER_METER = (10.0 / 0.3)
    RUN_SPEED_KMPH = 20.0
    RUN_SPEED_MPM = (RUN_SPEED_KMPH * 1000.0 / 60.0)
    RUN_SPEED_MPS = (RUN_SPEED_MPM / 60.0)
    RUN_SPEED_PPS = (RUN_SPEED_MPS * PIXEL_PER_METER)

    TIME_PER_ACTION = 0.5
    ACTION_PER_TIME = 1.0 / TIME_PER_ACTION
    FRAMES_PER_ACTION = 8

    def __init__(self):

       #Base Setting
        self.frame = random.randint(0, 1)
        self.right_attack = load_image('resource\\AI\\ai_rightAttack.png')
        self.left_attack = load_image('resource\\AI\\ai_leftAttack.png')
        self.up_attack = load_image('resource\\AI\\ai_upAttack.png')
        self.down_attack = load_image('resource\\AI\\ai_downAttack.png')
        self.state = 0
        self.x=0
        self.y=0
        self.old_x = 0
        self.old_y = 0
        self.total_frames = 0



    def AttackUpdate(self, frame_time,State,RA,LA,UA,DA):
        self.distance = AI_Ranger_4.RUN_SPEED_PPS * frame_time
        self.total_frames += AI_Ranger_4.FRAMES_PER_ACTION * AI_Ranger_4.ACTION_PER_TIME * frame_time

        # 상태 변환에 따른 원거리 공격(발사체) 초기화,#
        #  * 최대 범위 및 충돌체크는 main_state에서 * #

        if State == RA:
            if self.x < 0:
                self.x = 0
            elif self.y !=0:
                self.y = 0
            else:
                self.x += self.distance

        if State == LA:
            if self.x > 0:
                self.x = 0
            elif self.y !=0:
               self.y = 0
            else:
                self.x -= self.distance


        if State == UA:
              if self.y < 0:
                self.y = 0
              elif self.x !=0:
                self.x = 0
              else:
                self.y += self.distance

        if State == DA:
              if self.y > 0:
                self.y = 0
              elif self.x !=0:
                 self.x = 0
              else:
                self.y -= self.distance


        #원거리 공격 사거리
        if self.x >= 120:
            self.x = 0
        if self.x <= -120:
            self.x = 0
        if self.y >= 120:
            self.y = 0
        if self.y <= -120:
            self.y = 0


    def AttackDraw(self,x,y,State,RA,LA,UA,DA):
         if State == RA:
             self.right_attack.draw(self.x + x, self.y + y)
         if State == LA:
             self.left_attack.draw(self.x + x, self.y + y)
         if State == UA:
             self.up_attack.draw(self.x + x, self.y + y)
         if State == DA:
             self.down_attack.draw(self.x + x, self.y + y)


    def get_bb(self,x,y):
        return self.x + x - 5.5,self.y + y - 5.5,self.x + x + 5.5,self.y + y +5.5

    def get_bb2(self,x,y):
        return (self.x + x) - 5.5,(self.y + y) - 5.5,(self.x + x) + 5.5,(self.y + y) +5.5

    def draw_bb(self,x,y):
        draw_rectangle(*self.get_bb(x,y))















