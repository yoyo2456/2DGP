__author__ = 'Administrator'

from pico2d import *
from maze import *
from Player import *
import random

in_tile = None
player = None
ranger = None

class Ranger:
    RA, LA, UA, DA, EF, ST = 0,1,2,3,4,5

    PIXEL_PER_METER = (10.0 / 0.3)
    RUN_SPEED_KMPH = 20.0
    RUN_SPEED_MPM = (RUN_SPEED_KMPH * 1000.0 / 60.0)
    RUN_SPEED_MPS = (RUN_SPEED_MPM / 60.0)
    RUN_SPEED_PPS = (RUN_SPEED_MPS * PIXEL_PER_METER)

    TIME_PER_ACTION = 0.5
    ACTION_PER_TIME = 1.0 / TIME_PER_ACTION
    FRAMES_PER_ACTION = 8
    SHOT_SOUND = None

    def __init__(self):


       #Base Setting
        self.frame = random.randint(0, 1)

        self.right_attack = load_image('resource\\Player\\right_attack.png')
        self.left_attack = load_image('resource\\Player\\left_attack.png')
        self.up_attack = load_image('resource\\Player\\up_attack.png')
        self.down_attack = load_image('resource\\Player\\down_attack.png')

        self.state = self.ST
        self.old_x = 0
        self.old_y = 0
        self.x=0
        self.y=0
        self.total_frames = 0




    def AttackUpdate(self, frame_time,State,RA,LA,UA,DA):
        self.distance = Ranger.RUN_SPEED_PPS * frame_time
        self.total_frames += Ranger.FRAMES_PER_ACTION * Ranger.ACTION_PER_TIME * frame_time


        if State == RA:
            if self.x < 0:
                self.x = 0
            elif self.y !=0:
                self.y = 0
            else:
                self.x += self.distance + 5

        if State == LA:
            if self.x > 0:
                self.x = 0
            elif self.y !=0:
               self.y = 0
            else:
                self.x -= self.distance + 5


        if State == UA:
            if self.y < 0:
                self.y = 0
            elif self.x !=0:
                self.x = 0
            else:
                self.y += self.distance + 5

        if State == DA:
              if self.y > 0:
                self.y = 0
              elif self.x !=0:
                 self.x = 0
              else:
                self.y -= self.distance + 5



        if self.x >= 150:
            self.x = 0
        if self.x <= -150:
            self.x = 0
        if self.y >= 150:
            self.y = 0
        if self.y <= -150:
            self.y = 0


    def AttackDraw(self,x,y,State,RA,LA,UA,DA):
         if State == RA:
             self.right_attack.draw(self.x + x, self.y + y)
         if State == LA:
             self.left_attack.draw(self.x + x, self.y + y)
         if State == UA:
             self.up_attack.draw(self.x + x, self.y + y)
         if State == DA:
             self.down_attack.draw(self.x + x, self.y + y)


    def get_bb(self):
        return (self.x) - 5.5,(self.y) - 5.5,(self.x) + 5.5,(self.y) +5.5

    def get_bb2(self,x,y):
        return (self.x + x) - 5.5,(self.y + y) - 5.5,(self.x + x) + 5.5,(self.y + y) +5.5

    def draw_bb(self,x,y):
        draw_rectangle(*self.get_bb2(x,y))







