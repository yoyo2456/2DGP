from pico2d import *
import random

class Player:

    STANDING,LEFT_MOVE,RIGHT_MOVE,UP_MOVE,DOWN_MOVE=0,1,2,3,4
    ATTACK,SKILL=5,6

    PIXEL_PER_METER = (10.0 / 0.3)
    RUN_SPEED_KMPH = 20.0
    RUN_SPEED_MPM = (RUN_SPEED_KMPH * 1000.0 / 60.0)
    RUN_SPEED_MPS = (RUN_SPEED_MPM / 60.0)
    RUN_SPEED_PPS = (RUN_SPEED_MPS * PIXEL_PER_METER)



    def __init__(self):
        self.frame = random.randint(0, 7)
        self.total_frames = 0.0
        self.dir = 1
        self.image_rightMove = load_image('player_right.png')
        self.image_leftMove = load_image('player_left.png')

        self.frame_y = 0
        self.frame_x = 0
        self.state = self.STANDING
        self.old_state=self.state
        self.x=100
        self.y=100
        self.hp=5

    def update(self):

        if self.state==self.ATTACK:
            self.frame_x = (self.frame_x + 1) % 9
        elif self.state==self.SKILL:
            if self.frame_x==12:
                self.frame_x=0
                self.state=self.old_state
            self.frame_x = (self.frame_x + 1) % 13
        else:
            self.frame_x = (self.frame_x + 1) % 5
            delay(0.03)

        if self.state == self.RIGHT_MOVE:
            self.x = min(750, self.x + 5)
        elif self.state == self.LEFT_MOVE:
            self.x = max(50, self.x - 5)
        elif self.state == self.UP_MOVE:
            self.y = min(750, self.y + 5)
        elif self.state == self.DOWN_MOVE:
            self.y = max(50, self.y - 5)

    def draw(self):
       if self.state==self.LEFT_MOVE:
            self.image_leftMove.clip_draw(self.frame_x * 117, self.frame_y * 115, 117, 115, self.x, self.y)
       elif self.state==self.RIGHT_MOVE:
            self.image_rightMove.clip_draw(self.frame_x * 117, self.frame_y * 115, 117, 115, self.x, self.y)
       else:
            self.image_rightMove.clip_draw(self.frame_x * 117, self.frame_y * 115, 117, 115, self.x, self.y)

    def handle_event(self, event):
          if (event.type, event.key) == (SDL_KEYDOWN, SDLK_LEFT):
            if self.state==self.SKILL:
                self.old_state=self.LEFT_MOVE
            else:
                self.state=self.LEFT_MOVE
          elif (event.type, event.key) == (SDL_KEYDOWN, SDLK_RIGHT):
            if self.state==self.SKILL:
                self.old_state=self.RIGHT_MOVE
            else:
                self.state=self.RIGHT_MOVE
          elif (event.type, event.key) == (SDL_KEYDOWN, SDLK_UP):
            if self.state==self.SKILL:
                self.old_state=self.UP_MOVE
            else:
                self.state=self.UP_MOVE
          elif (event.type, event.key) == (SDL_KEYDOWN, SDLK_DOWN):
            if self.state==self.SKILL:
                self.old_state=self.DOWN_MOVE
            else:
                self.state=self .DOWN_MOVE
          elif (event.type, event.key) == (SDL_KEYUP, SDLK_LEFT):
            if self.state==self.LEFT_MOVE:
                self.state=self .STANDING
            elif self.state==self.SKILL:
                self.old_state=self.STANDING
          elif (event.type, event.key) == (SDL_KEYUP, SDLK_RIGHT):
            if self.state==self.RIGHT_MOVE:
                self.state=self.STANDING
            elif self.state==self.SKILL:
                self.old_state=self.STANDING
          elif (event.type, event.key) == (SDL_KEYUP, SDLK_UP):
            if self.state==self.UP_MOVE:
                self.state=self.STANDING
            elif self.state==self.SKILL:
                self.old_state=self.STANDING
          elif (event.type, event.key) == (SDL_KEYUP, SDLK_DOWN):
            if self.state==self.DOWN_MOVE:
                self.state=self.STANDING
            elif self.state==self.SKILL:
                self.old_state=self.STANDING
