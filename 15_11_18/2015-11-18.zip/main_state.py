import random
import json
import os

from pico2d import *
from maze import *
from Player import *


import game_framework
import title_state


name = "MainState"

player = None
background = None
tile = None
font = None
tile_count = 0


def get_frame_time():

    global current_time

    frame_time = get_time() - current_time
    current_time += frame_time
    return frame_time



def enter():
    global  player,background,tile,tiles

    player = Player()
    background = Background()
    tile = Tile()
    tiles=[Tile() for i in range(192)]



def exit():
    pass


def pause():
    pass


def resume():
    pass


def collide(a,b):
     left_a, bottom_a, right_a, top_a = a.get_bb()
     left_b, bottom_b, right_b, top_b = b.get_bb()

     if left_a > right_b: return False
     if right_a < left_b: return False
     if top_a < bottom_b: return False
     if bottom_a > top_b: return False
     return True



def handle_events(frame_time):
    events = get_events()
    for event in events:
        if event.type == SDL_QUIT:
            game_framework.quit()
        elif event.type == SDL_KEYDOWN and event.key == SDLK_ESCAPE:
            game_framework.change_state(title_state)
        else:
            player.handle_event(event)

current_time = 0.0



def update(frame_time):
     player.update(frame_time)



def draw(frame_time):
    clear_canvas()
    background.draw()
    tile.draw()
    #tile.draw_bb()
    player.draw()
    update_canvas()












