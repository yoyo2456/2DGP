__author__ = 'incipe'


import random
import json
import os

from pico2d import *
from maze import *

tile = None

class Player:

    STANDING,RIGHT_MOVE,DOWN_MOVE,LEFT_MOVE,UP_MOVE=0,1,2,3,4
    ATTACK,SKILL=5,6

    PIXEL_PER_METER = (10.0 / 0.3)
    RUN_SPEED_KMPH = 20.0
    RUN_SPEED_MPM = (RUN_SPEED_KMPH * 1000.0 / 60.0)
    RUN_SPEED_MPS = (RUN_SPEED_MPM / 60.0)
    RUN_SPEED_PPS = (RUN_SPEED_MPS * PIXEL_PER_METER)

    TIME_PER_ACTION = 0.5
    ACTION_PER_TIME = 1.0 / TIME_PER_ACTION
    FRAMES_PER_ACTION = 8



    def __init__(self):
        self.frame = random.randint(0, 7)
        self.total_frames = 0.0
        self.dir = 1
        self.image = load_image('resource\\Player.png')
        self.frame_y = 0
        self.frame_x = 0
        self.state = self.STANDING # 기본 상태
        self.old_state=self.state
        self.x=100
        self.y=100
        self.hp=5 #Player Hp

        #Player Collison Check
        self.TileCoX = False
        self.TileCoY = False
        self.CoX = 0
        self.CoY = 0


        global tile
        tile = Tile()



    def handle_event(self, event):
          if (event.type, event.key) == (SDL_KEYDOWN, SDLK_LEFT):
            if self.state==self.SKILL:
                self.old_state=self.LEFT_MOVE
            else:
                self.state=self.LEFT_MOVE
          elif (event.type, event.key) == (SDL_KEYDOWN, SDLK_RIGHT):
            if self.state==self.SKILL:
                self.old_state=self.RIGHT_MOVE
            else:
                self.state=self.RIGHT_MOVE
          elif (event.type, event.key) == (SDL_KEYDOWN, SDLK_UP):
            if self.state==self.SKILL:
                self.old_state=self.UP_MOVE
            else:
                self.state=self.UP_MOVE
          elif (event.type, event.key) == (SDL_KEYDOWN, SDLK_DOWN):
            if self.state==self.SKILL:
                self.old_state=self.DOWN_MOVE
            else:
                self.state=self .DOWN_MOVE
          elif (event.type, event.key) == (SDL_KEYUP, SDLK_LEFT):
            if self.state==self.LEFT_MOVE:
                self.state=self .STANDING
            elif self.state==self.SKILL:
                self.old_state=self.STANDING
          elif (event.type, event.key) == (SDL_KEYUP, SDLK_RIGHT):
            if self.state==self.RIGHT_MOVE:
                self.state=self.STANDING
            elif self.state==self.SKILL:
                self.old_state=self.STANDING
          elif (event.type, event.key) == (SDL_KEYUP, SDLK_UP):
            if self.state==self.UP_MOVE:
                self.state=self.STANDING
            elif self.state==self.SKILL:
                self.old_state=self.STANDING
          elif (event.type, event.key) == (SDL_KEYUP, SDLK_DOWN):
            if self.state==self.DOWN_MOVE:
                self.state=self.STANDING
            elif self.state==self.SKILL:
                self.old_state=self.STANDING



    def update(self, frame_time):

        self.distance = Player.RUN_SPEED_PPS * frame_time
        self.total_frames += Player.FRAMES_PER_ACTION * Player.ACTION_PER_TIME * frame_time
        self.frame = (self.frame + 1) % 6
        self.frame_x = (self.frame_x + 1) % 8
        delay(0.07)

        if self.state == self.RIGHT_MOVE:
            self.x += (self.dir * self.distance)
        elif self.state == self.LEFT_MOVE:
            self.x -= (self.dir * self.distance)
        elif self.state == self.UP_MOVE:
            self.y += (self.dir * self.distance)
        elif self.state == self.DOWN_MOVE:
            self.y -= (self.dir * self.distance)

    def draw(self):
        self.image.clip_draw(self.frame * 81, self.state * 60, 81, 60, self.x, self.y)
       # tile.get_bb()


    def get_bb(self):
        return self.x-25,self.y-25,self.x+25,self.y+25

    def draw_bb(self):
        pass



