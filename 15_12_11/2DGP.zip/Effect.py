__author__ = 'Administrator'

from pico2d import *
from maze import *
from Player import *
import random


#AI, Player
class Effect_1:


    PIXEL_PER_METER = (10.0 / 0.3)
    RUN_SPEED_KMPH = 20.0
    RUN_SPEED_MPM = (RUN_SPEED_KMPH * 1000.0 / 60.0)
    RUN_SPEED_MPS = (RUN_SPEED_MPM / 60.0)
    RUN_SPEED_PPS = (RUN_SPEED_MPS * PIXEL_PER_METER)

    TIME_PER_ACTION = 0.5
    ACTION_PER_TIME = 1.0 / TIME_PER_ACTION
    FRAMES_PER_ACTION = 8



    def __init__(self):
        global ranger


        #Base Setting
        self.frame = random.randint(0, 7)
        self.total_frames = 0.0
        self.state = 0

        self.downEffect = load_image('resource\\Effect\\\down_attack_effect.png')
        self.upEffect = load_image('resource\\Effect\\up_attack_effect.png')
        self.rightEffect = load_image('resource\\Effect\\right_attack_effect.png')
        self.leftEffect = load_image('resource\\Effect\\left_attack_effect.png')

        self.boom_left_effect = load_image('resource\\Effect\\boom_left_effect.png')
        self.boom_right_effect = load_image('resource\\Effect\\boom_right_effect.png')

        #Player
        self.effect_switch = False

        #AI
        self.effect_ai1_switch = False
        self.effect_ai2_switch = False
        self.effect_ai3_switch = False
        self.effect_ai4_switch = False



        self.x=0
        self.y=0
        self.distance = 0


    def update(self):
       self.frame = (self.frame + 1) % 3



    def draw(self,PX,PY,ST,LA,RA,DA,UA):
        if self.effect_switch == True and ST == DA:
           self.downEffect.clip_draw(self.frame * 41, self.state * 30, 41, 30, PX,PY+12.5)
           self.effect_switch = False

        if self.effect_switch == True and ST == UA:
           self.upEffect.clip_draw(self.frame * 41, self.state * 30, 41, 30, PX,PY-12.5)
           self.effect_switch = False

        if self.effect_switch == True and ST == RA:
           self.rightEffect.clip_draw(self.frame * 41, self.state * 30, 41, 30, PX - 5.5,PY)
           self.effect_switch = False

        if self.effect_switch == True and ST == LA:
           self.leftEffect.clip_draw(self.frame * 41, self.state * 30, 41, 30, PX + 5.5,PY)
           self.effect_switch = False


    def ai1_draw(self,PX,PY,ST,LA,RA,DA,UA):
        if self.effect_ai1_switch == True and ST == DA:
           self.downEffect.clip_draw(self.frame * 41, self.state * 30, 41, 30, PX,PY + 12.5)
           self.effect_ai1_switch = False

        if self.effect_ai1_switch == True and ST == UA:
           self.upEffect.clip_draw(self.frame * 41, self.state * 30, 41, 30, PX,PY - 12.5)
           self.effect_ai1_switch = False

        if self.effect_ai1_switch == True and ST == RA:
           self.rightEffect.clip_draw(self.frame * 41, self.state * 30, 41, 30, PX,PY)
           self.effect_ai1_switch = False

        if self.effect_ai1_switch == True and ST == LA:
           self.leftEffect.clip_draw(self.frame * 41, self.state * 30, 41, 30, PX,PY)
           self.effect_ai1_switch = False



    def ai2_draw(self,PX,PY,ST,LA,RA,DA,UA):
        if self.effect_ai2_switch == True and ST == DA:
           self.downEffect.clip_draw(self.frame * 41, self.state * 30, 41, 30, PX,PY + 12.5)
           self.effect_ai2_switch = False

        if self.effect_ai2_switch == True and ST == UA:
           self.upEffect.clip_draw(self.frame * 41, self.state * 30, 41, 30, PX,PY - 12.5)
           self.effect_ai2_switch = False

        if self.effect_ai2_switch == True and ST == RA:
           self.rightEffect.clip_draw(self.frame * 41, self.state * 30, 41, 30, PX,PY)
           self.effect_ai2_switch = False

        if self.effect_ai2_switch == True and ST == LA:
           self.leftEffect.clip_draw(self.frame * 41, self.state * 30, 41, 30, PX,PY)
           self.effect_ai2_switch = False



    def ai3_draw(self,PX,PY,ST,LA,RA,DA,UA):
        if self.effect_ai3_switch == True and ST == DA:
           self.downEffect.clip_draw(self.frame * 41, self.state * 30, 41, 30, PX,PY + 12.5)
           self.effect_ai3_switch = False

        if self.effect_ai3_switch == True and ST == UA:
           self.upEffect.clip_draw(self.frame * 41, self.state * 30, 41, 30, PX,PY - 12.5)
           self.effect_ai3_switch = False

        if self.effect_ai3_switch == True and ST == RA:
           self.rightEffect.clip_draw(self.frame * 41, self.state * 30, 41, 30, PX,PY)
           self.effect_ai3_switch = False

        if self.effect_ai3_switch == True and ST == LA:
           self.leftEffect.clip_draw(self.frame * 41, self.state * 30, 41, 30, PX,PY)
           self.effect_ai3_switch = False



    def ai4_draw(self,PX,PY,ST,LA,RA,DA,UA):
        if self.effect_ai4_switch == True and ST == DA:
           self.downEffect.clip_draw(self.frame * 41, self.state * 30, 41, 30, PX,PY + 12.5)
           self.effect_ai4_switch = False

        if self.effect_ai4_switch == True and ST == UA:
           self.upEffect.clip_draw(self.frame * 41, self.state * 30, 41, 30, PX,PY - 12.5)
           self.effect_ai4_switch = False

        if self.effect_ai4_switch == True and ST == RA:
           self.rightEffect.clip_draw(self.frame * 41, self.state * 30, 41, 30, PX,PY)
           self.effect_ai4_switch = False

        if self.effect_ai4_switch == True and ST == LA:
           self.leftEffect.clip_draw(self.frame * 41, self.state * 30, 41, 30, PX,PY)
           self.effect_ai4_switch = False




    def auto_down_draw(self,PX,PY,ST,LA):
        if self.effect_auto_left_switch == True and ST == LA:
           self.boom_left_effect.clip_draw(self.frame * 41, self.state * 30, 41, 30, PX,PY)
           self.effect_auto_left_switch = False




    def get_bb(self):
        return self.x-6.5,self.y-7.5,self.x+6.5,self.y+5.5

    def draw_bb(self):
        draw_rectangle(*self.get_bb())




#Auto_Object
class Effect_2:


    PIXEL_PER_METER = (10.0 / 0.3)
    RUN_SPEED_KMPH = 20.0
    RUN_SPEED_MPM = (RUN_SPEED_KMPH * 1000.0 / 60.0)
    RUN_SPEED_MPS = (RUN_SPEED_MPM / 60.0)
    RUN_SPEED_PPS = (RUN_SPEED_MPS * PIXEL_PER_METER)

    TIME_PER_ACTION = 0.5
    ACTION_PER_TIME = 1.0 / TIME_PER_ACTION
    FRAMES_PER_ACTION = 8


    def __init__(self):
        global ranger

        #Base Setting
        self.frame = random.randint(0, 3)
        self.total_frames = 0.0
        self.state = 0

        self.boom_left_effect = load_image('resource\\Effect\\boom_effect.png')
        self.boom_right_effect = load_image('resource\\Effect\\boom_effect.png')
        self.boom_down_effect = load_image('resource\\Effect\\boom_effect2.png')


        #AutoDdwon
        self.effect_auto_down_switch_1 = False
        self.effect_auto_down_switch_2 = False
        self.effect_auto_down_switch_3 = False
        self.effect_auto_down_switch_4 = False


        #AutoLeft & AutoRight
        self.effect_auto_left_switch_1 = False
        self.effect_auto_left_switch_2 = False
        self.effect_auto_right_switch = False


        self.x=0
        self.y=0
        self.distance = 0


    def update(self, frame_time):
       self.distance = Effect_2.RUN_SPEED_PPS * frame_time
       self.total_frames += Effect_2.FRAMES_PER_ACTION * Effect_2.ACTION_PER_TIME * frame_time
       self.frame = (self.frame + 1) % 4


    def auto_down_draw_1(self,PX,PY,ST,DA,RY):
        if self.effect_auto_down_switch_1 == True and ST == DA:
           self.boom_down_effect.clip_draw(self.frame * 40, self.state * 30, 40, 30, PX,PY)
           if RY < -40 :
               self.effect_auto_down_switch_1 = False

    def auto_down_draw_2(self,PX,PY,ST,DA,RY):
        if self.effect_auto_down_switch_2 == True and ST == DA:
           self.boom_down_effect.clip_draw(self.frame * 40, self.state * 30, 40, 30, PX,PY)
           if RY < -40 :
               self.effect_auto_down_switch_2 = False

    def auto_down_draw_3(self,PX,PY,ST,DA,RY):
        if self.effect_auto_down_switch_3 == True and ST == DA:
           self.boom_down_effect.clip_draw(self.frame * 40, self.state * 30, 40, 30, PX,PY)
           if RY < -40 :
               self.effect_auto_down_switch_3 = False

    def auto_down_draw_4(self,PX,PY,ST,DA,RY):
        if self.effect_auto_down_switch_4 == True and ST == DA:
           self.boom_down_effect.clip_draw(self.frame * 40, self.state * 30, 40, 30, PX,PY)
           if RY < -40 :
               self.effect_auto_down_switch_4 = False



    def auto_left_draw_1(self,PX,PY,ST,LA,RX):
        if self.effect_auto_left_switch_1 == True and ST == LA:
           self.boom_left_effect.clip_draw(self.frame * 40, self.state * 30, 40, 30, PX,PY)
           if RX > 10 :
               self.effect_auto_left_switch_1 = False

    def auto_left_draw_2(self,PX,PY,ST,LA,RX):
        if self.effect_auto_left_switch_2 == True and ST == LA:
           self.boom_left_effect.clip_draw(self.frame * 40, self.state * 30, 40, 30, PX,PY)
           if RX > 10 :
               self.effect_auto_left_switch_2 = False


    def auto_right_draw(self,PX,PY,ST,RA,RX):
        if self.effect_auto_right_switch == True and ST == RA:
           self.boom_left_effect.clip_draw(self.frame * 41, self.state * 30, 41, 30, PX,PY)
           if RX < -10 :
               self.effect_auto_right_switch = False





    def get_bb(self):
        return self.x-6.5,self.y-7.5,self.x+6.5,self.y+5.5

    def draw_bb(self):
        draw_rectangle(*self.get_bb())






