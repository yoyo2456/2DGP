from pico2d import *
from maze import *


import random
import json
import os

ranger = None
in_tile = None
player = None


class Ranger:
    RA, LA, UA, DA = 0,1,2,3

    PIXEL_PER_METER = (10.0 / 0.3)
    RUN_SPEED_KMPH = 20.0
    RUN_SPEED_MPM = (RUN_SPEED_KMPH * 1000.0 / 60.0)
    RUN_SPEED_MPS = (RUN_SPEED_MPM / 60.0)
    RUN_SPEED_PPS = (RUN_SPEED_MPS * PIXEL_PER_METER)

    TIME_PER_ACTION = 0.5
    ACTION_PER_TIME = 1.0 / TIME_PER_ACTION
    FRAMES_PER_ACTION = 8

    def __init__(self):

        global in_tile,player

       #Base Setting
        self.frame = random.randint(0, 1)
        self.right_attack = load_image('resource\\Player\\right_attack.png')
        self.left_attack = load_image('resource\\Player\\left_attack.png')
        self.up_attack = load_image('resource\\Player\\up_attack.png')
        self.down_attack = load_image('resource\\Player\\down_attack.png')
        self.state = 0
        self.x=0
        self.y=0
        self.total_frames = 0

        #global
        in_tile = In_Tile()





    def AttackUpdate(self, frame_time,State,RA,LA,UA,DA,PX,PY):
        self.distance = Ranger.RUN_SPEED_PPS * frame_time
        self.total_frames += Ranger.FRAMES_PER_ACTION * Ranger.ACTION_PER_TIME * frame_time


        if State == RA:
            if self.x < 0:
                self.x = 0
            elif self.y !=0:
                self.y = 0
            else:
                self.x += self.distance

        if State == LA:
            if self.x > 0:
                self.x = 0
            elif self.y !=0:
               self.y = 0
            else:
                self.x -= self.distance


        if State == UA:
            if self.y < 0:
                self.y = 0
            elif self.x !=0:
                self.x = 0
            else:
                self.y += self.distance

        if State == DA:
              if self.y > 0:
                self.y = 0
              elif self.x !=0:
                 self.x = 0
              else:
                self.y -= self.distance



        if self.x >= 150:
            self.x = 0
        if self.x <= -150:
            self.x = 0
        if self.y >= 150:
            self.y = 0
        if self.y <= -150:
            self.y = 0


    def AttackDraw(self,x,y,State,RA,LA,UA,DA):
         if State == RA:
             self.right_attack.draw(self.x + x, self.y + y)
         if State == LA:
             self.left_attack.draw(self.x + x, self.y + y)
         if State == UA:
             self.up_attack.draw(self.x + x, self.y + y)
         if State == DA:
             self.down_attack.draw(self.x + x, self.y + y)


    def get_bb(self):
        return (self.x) - 5.5,(self.y) - 5.5,(self.x) + 5.5,(self.y) +5.5

    def get_bb2(self,x,y):
        return (self.x + x) - 5.5,(self.y + y) - 5.5,(self.x + x) + 5.5,(self.y + y) +5.5

    def draw_bb(self,x,y):
        draw_rectangle(*self.get_bb2(x,y))

    def RangerCollide(a,b,PX,PY):
        left_a, bottom_a, right_a, top_a = a.get_bb(PX,PY)
        left_b, bottom_b, right_b, top_b = b.get_bb()

        if left_a > right_b:
            return False
        if right_a < left_b:
            return False
        if top_a < bottom_b:
            return False
        if bottom_a > top_b:
            return False
        return True









class Player:

    STANDING,RIGHT_MOVE,DOWN_MOVE,LEFT_MOVE,UP_MOVE=0,1,2,3,4
    RIGHT_ATTACK,DOWN_ATTACK,LEFT_ATTACK,UP_ATTACK,SKILL=5,6,7,8,9
    PIXEL_PER_METER = (10.0 / 0.3)
    RUN_SPEED_KMPH = 20.0
    RUN_SPEED_MPM = (RUN_SPEED_KMPH * 1000.0 / 60.0)
    RUN_SPEED_MPS = (RUN_SPEED_MPM / 60.0)
    RUN_SPEED_PPS = (RUN_SPEED_MPS * PIXEL_PER_METER)

    TIME_PER_ACTION = 0.5
    ACTION_PER_TIME = 1.0 / TIME_PER_ACTION
    FRAMES_PER_ACTION = 8



    def __init__(self):
        global ranger,in_tile,player

       #Base Setting
        self.frame = random.randint(0, 7)
        self.total_frames = 0.0
        self.dir = 1
        self.diration = 0
        self.bf_diration = 0
        self.PlayerMoveImage = load_image('resource\\Player\\player2.png')

        self.frame_y = 0
        self.frame_x = 0
        self.state = self.STANDING # 기본 상태
        self.bf_state = self.STANDING # 이전 상태
        self.x=400
        self.y=300
        self.distance = 0

       #Player Game Info
        self.hp = 100
        self.base_attack_damage = 20




        #collide
        self.left_collid = False
        self.right_collid = False
        self.up_collid = False
        self.down_collid = False

        #Jewelry count
        self.BJ_count = 0
        self.RJ_count = 0
        self.YJ_count = 0
        self.GJ_count = 0

        #outside
        ranger = Ranger()
        in_tile = In_Tile()







    def handle_event(self, event):

        #Key Down
          if (event.type, event.key) == (SDL_KEYDOWN, SDLK_LEFT):
                self.state=self.LEFT_MOVE
                self.diration = 0
          elif (event.type, event.key) == (SDL_KEYDOWN, SDLK_RIGHT):
                self.state=self.RIGHT_MOVE
                self.diration = 1
          elif (event.type, event.key) == (SDL_KEYDOWN, SDLK_UP):
                self.state=self.UP_MOVE
                self.diration = 2
          elif (event.type, event.key) == (SDL_KEYDOWN, SDLK_DOWN):
                self.state=self.DOWN_MOVE
                self.diration = 3


          elif (event.type, event.key) == (SDL_KEYDOWN, SDLK_LCTRL) and self.diration == 0:
                self.state = self.LEFT_ATTACK
          elif (event.type, event.key) == (SDL_KEYDOWN, SDLK_LCTRL) and self.diration == 1:
                self.state = self.RIGHT_ATTACK
          elif (event.type, event.key) == (SDL_KEYDOWN, SDLK_LCTRL) and self.diration == 2:
                self.state = self.UP_ATTACK
          elif (event.type, event.key) == (SDL_KEYDOWN, SDLK_LCTRL) and self.diration == 3:
                self.state = self.DOWN_ATTACK





         #Key Up
          elif (event.type, event.key) == (SDL_KEYUP, SDLK_LEFT):
            if self.state == self.LEFT_MOVE:
                self.state = self.STANDING

          elif (event.type, event.key) == (SDL_KEYUP, SDLK_RIGHT):
            if self.state == self.RIGHT_MOVE:
                self.state = self.STANDING

          elif (event.type, event.key) == (SDL_KEYUP, SDLK_UP):
            if self.state == self.UP_MOVE:
                self.state = self.STANDING

          elif (event.type, event.key) == (SDL_KEYUP, SDLK_DOWN):
            if self.state == self.DOWN_MOVE:
                self.state = self.STANDING


          elif (event.type, event.key) == (SDL_KEYUP, SDLK_LCTRL):
              if self.state == self.RIGHT_ATTACK:
                  self.state = self.STANDING
                  ranger.x = 0
          elif (event.type, event.key) == (SDL_KEYUP, SDLK_LCTRL):
              if self.state == self.LEFT_ATTACK:
                  self.state = self.STANDING
                  ranger.x = 0
          elif (event.type, event.key) == (SDL_KEYUP, SDLK_LCTRL):
              if self.state == self.UP_ATTACK:
                  self.state = self.STANDING
                  ranger.y = 0
          elif (event.type, event.key) == (SDL_KEYUP, SDLK_LCTRL):
              if self.state == self.DOWN_ATTACK:
                  self.state = self.STANDING
                  ranger.y = 0



    def MovingPlayer(self):
        if self.state == self.RIGHT_MOVE:
            if self.x > 775:
                pass
            else:
                self.x += (self.dir * self.distance/2)
                #self.right_collid = True

        elif self.state == self.LEFT_MOVE:
            if self.x < 30:
                pass
            else:
                self.x -= (self.dir * self.distance/2)
                #self.left_collid = True


        elif self.state == self.UP_MOVE:
            if self.y > 575:
                pass
            else:
                self.y += (self.dir * self.distance/2)
                #self.up_collid = True

        elif self.state == self.DOWN_MOVE:
            if self.y < 43:
                pass
            else:
                self.y -= (self.dir * self.distance/2)
                #self.down_collid = True






    def leftCollide_Player(self):
      self.x += (self.dir * self.distance/2) + 5.5

    def rightCollide_Player(self):
       self.x -= (self.dir * self.distance/2) + 5.5

    def upCollide_Player(self):
       self.y -= (self.dir * self.distance/2) + 5.5

    def downCollide_Player(self):
       self.y += (self.dir * self.distance/2) + 5.5


    def get_BJ(self):
         global BJ_count
         self.BJ_count +=1

    def get_RJ(self):
         global RJ_count
         self.RJ_count +=1

    def get_GJ(self):
         global GJ_count
         self.GJ_count +=1

    def get_YJ(self):
         global YJ_count
         self.YJ_count +=1




    def update(self, frame_time):
        self.distance = Player.RUN_SPEED_PPS * frame_time
        self.total_frames += Player.FRAMES_PER_ACTION * Player.ACTION_PER_TIME * frame_time
        self.frame = (self.frame + 1) % 6
        self.frame_x = (self.frame_x + 1) % 8
        self.MovingPlayer()

        ranger.AttackUpdate(frame_time,self.state, self.RIGHT_ATTACK, self.LEFT_ATTACK, self.UP_ATTACK, self.DOWN_ATTACK,self.x,self.y)






    def draw(self):
       self.PlayerMoveImage.clip_draw(self.frame * 41, self.state * 30, 41, 30, self.x, self.y)
       ranger.AttackDraw(self.x, self.y,self.state,self.RIGHT_ATTACK,self.LEFT_ATTACK,self.UP_ATTACK,self.DOWN_ATTACK)

       ranger.draw_bb(self.x, self.y)


    def get_bb(self):
        return self.x-6.5,self.y-7.5,self.x+6.5,self.y+5.5

    def draw_bb(self):
        draw_rectangle(*self.get_bb())




















