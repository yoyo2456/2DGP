import random
import json
import os

from pico2d import *
from maze import *
from Player import *


import game_framework
import title_state


name = "MainState"

player = None
background = None
tile = None
font = None


def get_frame_time():

    global current_time

    frame_time = get_time() - current_time
    current_time += frame_time
    return frame_time


def enter():
    global  player, background, maze
    player = Player()
    background = Background()


    tile.set_center_object(player)



def exit():
    pass


def pause():
    pass


def resume():
    pass


def set_all_pos():
    tile.set_pos(2500,1200)

def handle_events(frame_time):
    events = get_events()
    for event in events:
        if event.type == SDL_QUIT:
            game_framework.quit()
        elif event.type == SDL_KEYDOWN and event.key == SDLK_ESCAPE:
            game_framework.change_state(title_state)
        else:
            player.handle_event(event)

current_time = 0.0



def update(frame_time):
    player.update(frame_time)



def draw(frame_time):
    clear_canvas()
    background.draw()
    tile.draw()
    player.draw()
    update_canvas()












