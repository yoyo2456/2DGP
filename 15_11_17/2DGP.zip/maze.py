__author__ = 'incipe'

from pico2d import *


class Background:
    def __init__(self):
        self.image = load_image('Background2.png')

    def draw(self):
        self.image.draw(1024, 1024)










