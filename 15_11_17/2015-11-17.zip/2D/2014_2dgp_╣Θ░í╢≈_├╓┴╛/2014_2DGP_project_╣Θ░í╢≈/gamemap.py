import random
import os

from player import Player
from pico2d import *
import viewport

class Info :
    def __init__(self):
        self.image = load_image('resources\\info.png')

    def draw(self):
        self.image.draw(400,300)

    def update(self, frame_time):
        pass

    def handle_event(self, event):
        pass

class Bg :
    def __init__(self):
        self.image = load_image('resources\\base_scroll2.jpg')
        self.left = 0
        self.bottom = 0

        self.canvas_width = get_canvas_width()
        self.canvas_height = get_canvas_height()

        self.width = self.image.w
        self.height = self.image.h

    def set_center_object(self, o):
        self.center_object = o

    def draw(self):
        self.image.clip_draw_to_origin(self.left,self.bottom,self.canvas_width,self.canvas_height,0,0)

    def update(self, frame_time):
        self.left = clamp(0, int(self.center_object.x) - self.canvas_width//2,self.width - self.canvas_width)
        self.bottom = clamp(0, int(self.center_object.y) - self.canvas_height//2,self.height - self.canvas_height)

    def handle_event(self, event):
        pass

class Wall_tile:

    image = None;

    def __init__(self):
        self.x, self.y = 0,0
        if Wall_tile.image == None:
            Wall_tile.image = load_image('resources\\out_wall.png')

        self.left = 0
        self.bottom = 0

        self.canvas_width = get_canvas_width()
        self.canvas_height = get_canvas_height()

        self.width = self.image.w
        self.height = self.image.h



    def set_center_object(self, o):
        self.center_object = o

    def draw(self):
        self.image.draw(self.x - viewport.left,self.y-viewport.bottom)

        #self.image.clip_draw_to_origin(self.left,self.bottom,self.canvas_width,self.canvas_height,0,0)

    def update(self, frame_time):

      self.left = clamp(0, int(self.center_object.x) - self.canvas_width//2,self.width - self.canvas_width)
      self.bottom = clamp(0, int(self.center_object.y) - self.canvas_height//2,self.height - self.canvas_height)

    def draw_bb(self):
        draw_rectangle(*self.get_bb())

    def get_bb(self):
          return self.x - 20, self.y - 125, self.x + 20, self.y + 125

    def set_pos(self,x,y):
        self.x = x
        self.y = y


class Safezone :
    def __init__(self):
        self.image = load_image('resources\\safe.png')
        self.x,self.y = 400,300
    def draw(self):

        if self.x < viewport.left : return
        if self.x > viewport.left+viewport.width : return
        if self.y < viewport.bottom : return
        if self.y > viewport.bottom + viewport.height : return

        self.image.draw(self.x - viewport.left,self.y-viewport.bottom)

    def draw_bb(self):
        draw_rectangle(*self.get_bb())

    def get_bb(self):
        return (self.x - viewport.left)  - 40, (self.y-viewport.bottom) - 40, (self.x - viewport.left)  + 40, (self.y-viewport.bottom) + 40

    def create_team():

        safe_file = open('resources\\safe_data.txt', 'r')
        safe_file_data = json.load(safe_file)
        safe_file.close()

        safe = []

        for i in safe_file_data:
            s = Safezone()
            s.i = i
            s.x = safe_file_data[i]['x']
            s.y = safe_file_data[i]['y']
            safe.append(s)

        return safe

class Width_tile:

    image = None;

    def __init__(self):
        self.x, self.y = 0,0
        if Width_tile.image == None:
            Width_tile.image = load_image('resources\\width_tile.jpg')

        self.left = 0
        self.bottom = 0

        self.canvas_width = get_canvas_width()
        self.canvas_height = get_canvas_height()

        self.width = self.image.w
        self.height = self.image.h


    def update(self, frame_time):
        pass

    def set_center_object(self, o):
        print("heycomeon")
        self.center_object = o

    def draw(self):
         self.image.draw(self.x - viewport.left,self.y-viewport.bottom)

    def draw_bb(self):
        draw_rectangle(*self.get_bb())

    def get_bb(self):

        return (self.x - viewport.left) - 125, (self.y-viewport.bottom) - 20,(self.x - viewport.left) + 125,(self.y-viewport.bottom) +20

    def create_wall():

        wall_data_file = open('resources\\width_data.txt', 'r')
        wall_data = json.load(wall_data_file)
        wall_data_file.close()

        team = []

        for name in wall_data:
            wtile = Width_tile()
            wtile.name = name
            wtile.x = wall_data[name]['x']
            wtile.y = wall_data[name]['y']
            team.append(wtile)

        return team

class Long_tile:

    image = None;

    def __init__(self):
        self.x, self.y = 620,470
        if Long_tile.image == None:
            Long_tile.image = load_image('resources\\long_tile.jpg')

        self.left = 0
        self.bottom = 0

        self.canvas_width = get_canvas_width()
        self.canvas_height = get_canvas_height()

        self.width = self.image.w
        self.height = self.image.h


    def update(self, frame_time):
        pass

    def set_center_object(self, o):
        print("heycomeon")
        self.center_object = o

    def draw(self):
        self.image.draw(self.x - viewport.left,self.y-viewport.bottom)

    def draw_bb(self):
        draw_rectangle(*self.get_bb())

    def get_bb(self):

        return (self.x - viewport.left) - 20, (self.y-viewport.bottom) - 125,(self.x - viewport.left) + 20,(self.y-viewport.bottom) + 125
    def create_wall():

        wall_data_file = open('resources\\Lwall_data.txt', 'r')
        wall_data = json.load(wall_data_file)
        wall_data_file.close()

        team = []

        for name in wall_data:
            ltile = Long_tile()
            ltile.name = name
            ltile.x = wall_data[name]['x']
            ltile.y = wall_data[name]['y']
            team.append(ltile)

        return team

class Small_tile:

    image = None;

    def __init__(self):
        self.x, self.y = random.randint(100, 700), random.randint(100,500)
        if Small_tile.image == None:
            Small_tile.image = load_image('resources\\small_tile.jpg')

        self.left = 0
        self.bottom = 0

        self.canvas_width = get_canvas_width()
        self.canvas_height = get_canvas_height()

        self.width = self.image.w
        self.height = self.image.h

    def set_center_object(self, o):
        print("heycomeon")
        self.center_object = o

    def update(self, frame_time):
        pass

    def draw(self):

        self.image.draw(self.x - viewport.left,self.y-viewport.bottom)

    def draw_bb(self):
        draw_rectangle(*self.get_bb())

    def get_bb(self):
        return (self.x - viewport.left) - 20, (self.y-viewport.bottom) - 20,(self.x - viewport.left) + 20,(self.y-viewport.bottom) + 20

    def create_wall():

        wall_data_file = open('resources\\around_key_data.txt', 'r')
        wall_data = json.load(wall_data_file)
        wall_data_file.close()

        team = []

        for name in wall_data:
            stile = Small_tile()
            stile.name = name
            stile.x = wall_data[name]['x']
            stile.y = wall_data[name]['y']
            team.append(stile)

        return team

class Tree:

    def __init__(self):
        self.image = load_image('resources\\tree.png')
        self.x, self.y = 0,0 # random.randint(200,2400),random.randint(100,1000)

    def update(self, frame_time):
        pass

    def draw(self):
        if self.x < viewport.left : return
        if self.x > viewport.left+viewport.width : return
        if self.y < viewport.bottom : return
        if self.y > viewport.bottom + viewport.height : return

        self.image.draw(self.x - viewport.left,self.y-viewport.bottom)

    def draw_bb(self):
        draw_rectangle(*self.get_bb())

    def get_bb(self):
        return (self.x - viewport.left) -75, (self.y-viewport.bottom) - 75, (self.x - viewport.left) + 75, (self.y-viewport.bottom) + 75

    def create_team():

        tree_data_file = open('resources\\tree_data.txt', 'r')
        tree_data = json.load(tree_data_file)
        tree_data_file.close()

        team = []

        for name in tree_data:
            tree = Tree()
            tree.name = name
            tree.x = tree_data[name]['x']
            tree.y = tree_data[name]['y']
            team.append(tree)

        return team