import random
import game_framework
import quiz_state
import os
import end_state

from pico2d import *

from gameobject import Item,Key,Door,Lifeheart,UI,Info
from player import Player
from gamemap import Long_tile,Small_tile,Safezone,Bg,Wall_tile,Tree,Width_tile
from boss import Boss,Enemy_green,Enemy_red
import viewport

name = "MainState"

player = None
bg = None
font = None

def create_world():

    global gameStage,hteam,boss,wall,wall2,key,door,heart,tree,trees,enemy_green,enemy_red
    global player,bg,font,item,ltile,stile
    global lteam,items,itemteam,steam,safeteam,wteam,ui
    global life_time,m_hint,m_hint_time,item2,safezone,info_time,bgm,lifeheart,info


    life_time = 0.0
    bg = Bg()
    player=Player()
    info = Info()
    ui = UI()
    #--- vilren-----------
    boss = Boss()
    enemy_green = Enemy_green()
    enemy_red =  Enemy_red()

    key = Key()
    door = Door()
    tree = Tree()
    item=Item()

    lifeheart = Lifeheart()

    safezone = Safezone()

  #--- making wall ----
    wall = Wall_tile()
    wall2 = Wall_tile()
    long = Long_tile()
    width = Width_tile()
    small = Small_tile()
  #--- making wall ----

    set_all_pos()


    # Factory -----------------------------------
    itemteam = Item.create_item()
    trees = Tree.create_team()
    safeteam=Safezone.create_team()

    lteam = Long_tile.create_wall()
    steam = Small_tile.create_wall()
    wteam = Width_tile.create_wall()

    # ---------------------------------------------
    font=load_font('resources\\ENCR10B.TTF')

    #--- set viewport -----------------------------
    player.set_background(bg)

    bg.set_center_object(player)

    wall.set_center_object(player)

    for long in lteam:
        long.set_center_object(player)

    for small in steam:
        small.set_center_object(player)

    for width in wteam:
        width.set_center_object(player)

    viewport.set_center_object(player)
    viewport.set_background(bg)

    #player.key = True

    bgm = load_music('resources\\bgm.mp3')
    bgm.set_volume(30)
    bgm.repeat_play()
    #--- set viewport -----------------------------

def destroy_world():

    global player,font,item,boss,wall,wall2,key,door,enemy_green,enemy_red
    global bg,ltile,wtile,stile,safezone,bgm,lifeheart

    del(key)
    del(bgm)
    del(player)
    del(font)
    del(safezone)
    del(item)
    del(door)
    del(enemy_green)
    del(enemy_red)
    del(lifeheart)

def enter():
    game_framework.reset_time()
    create_world()

def exit():
    destroy_world()
    game_framework.reset_time()

def pause():
    pass

def resume():
    pass

def set_all_pos():
    wall.set_pos(2500,1200)
    wall2.set_pos(2500,10)

# collide check ---------------------------------------------------
def collide(a, b):
    left_a, bottom_a, right_a, top_a = a.get_bb()
    left_b, bottom_b, right_b, top_b = b.get_bb()

    if left_a > right_b: return False
    if right_a < left_b: return False
    if top_a < bottom_b: return False
    if bottom_a > top_b: return False

    return True

# collide check ---------------------------------------------------

def handle_events(frame_time):
    global m_hint,info

    events = get_events()
    for event in events:
        if event.type == SDL_QUIT:
            game_framework.quit()
        else :
             if (event.type,event.key) == (SDL_KEYDOWN,SDLK_ESCAPE):
                 game_framework.quit()
             else :
                if (event.type,event.key) == (SDL_KEYDOWN,SDLK_i):
                        info.info = False
                elif (event.type,event.key) == (SDL_KEYDOWN,SDLK_SPACE):
                    if player.meetboss == True :
                        bgm.stop()
                        game_framework.change_state(quiz_state)
                else :
                    player.handle_event(event)

def update(frame_time):

    global player,item,ltile,stil,wtile,player,px,py
    global life_time,m_hint,m_hint_time,steam,lteam,wteam,total_time

    viewport.update(frame_time)
    player.update(frame_time)
    player.get_stagenumber(3)
    bg.update(frame_time)

    if info.info == True:
        life_time = 0.0
    else :
        life_time += frame_time
  #  total_time += frame_time

    enemy_green.update(frame_time)
    enemy_red.update(frame_time)
    lifeheart.get_time(life_time)

    #------------------------------------------------------

    #------------------------------------------------------

    '''
    steam = Small_tile.create_wall()
    lteam = Long_tile.create_wall()
    wteam = Width_tile.create_wall()
    trees = Tree.create_team()
    '''

    #-- wall collide ----------

    for wtile in wteam:
        if collide(player,wtile):
            px,py = player.get_pos()
            #player.stop(px,py)
            player.stop()


    for ltile in lteam:
        if collide(player,ltile):
            px,py = player.get_pos()
            #player.stop(px,py)
            player.stop()


    for stile in steam:
        #stile.update(frame_time)
        if collide(player,stile):
            px,py = player.get_pos()
            #player.stop(px,py)
            player.stop()
            pass

    for safe in safeteam:
        if collide(player,safe) :
             life_time = 0.0
    #---------------------------

    if collide(player,boss) :
          player.meetboss = True
          px,py = player.get_pos()
          #player.stop(px,py)
          player.stop()

    if collide(player,door):
        if door.doormeet == False:
            px,py = player.get_pos()
            #player.stop(px,py)
            player.stop()

            if player.itemcount == 4 :
                if player.key == True :
                    door.remove_img()
                    door.doormeet = True
                    player.key = False
        else :
            pass


    for tree in trees :
       # tree.update(frame_time)
        if collide(player,tree) :
            px,py = player.get_pos()
           # player.stop(px,py)
            player.stop()

    if collide(player,key) :
            # key.remove_img()
             player.key = True
             player.playsound()

    for item in itemteam:

            item.update(frame_time)

            if collide(player,item):
                itemteam.remove(item)
                player.getItem()
                player.playsound()
                print("collide")

    if life_time == 0.0 :
        bgm.set_volume(30)

    if life_time > 15:
        bgm.set_volume(10)

def draw(frame_time):

    global life_time
    clear_canvas()

    bg.draw()

    boss.draw()
 #   boss.draw_bb()

    if player.key == False:
        key.draw()
  #      key.draw_bb()

    elif player.key == True:
        key.remove_img()



    for tree in trees :
        tree.draw()
   #     tree.draw_bb()

    enemy_green.draw()
 #   enemy_green.draw_bb()

    enemy_red.draw()
#    enemy_red.draw_bb()



    door.draw()
  #  door.draw_bb()

    for item in itemteam :
         item.draw()
      #   item.draw_bb()

    for stile in steam:
        stile.draw()
     #   stile.draw_bb()

    for ltile in lteam:
        ltile.draw()
       # ltile.draw_bb()

    for wtile in wteam:
        wtile.draw()
      #  wtile.draw_bb()

    for safe in safeteam:
        safe.draw()
       # safe.draw_bb()



    wall.draw()
    wall2.draw()

    player.draw()
   # player.draw_bb()

    ui.draw()

    lifeheart.draw()

    font.draw(600,30, 'Time : %3.2f' % life_time,(33,25,111))
    font.draw(10,30,' ItemCount : %d' % player.itemcount,(255,255,255))


    #-- Time limit ---

    if life_time > 45 :
        end_state.getEnd(1)
        game_framework.change_state(end_state)

    #-- Time limit ---

    #-- infomation --

   # if info == True :
    info.draw()

    update_canvas()

