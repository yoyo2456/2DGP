import random

from pico2d import *
import main_state

class Player :

    PIXEL_PER_METER = (10.0 / 0.3)           # 10 pixel 30 cm
    RUN_SPEED_KMPH = 25.0                    # Km / Hour
    RUN_SPEED_MPM = (RUN_SPEED_KMPH * 1000.0 / 60.0)
    RUN_SPEED_MPS = (RUN_SPEED_MPM / 60.0)
    RUN_SPEED_PPS = (RUN_SPEED_MPS * PIXEL_PER_METER)

    TIME_PER_ACTION = 0.5
    ACTION_PER_TIME = 1.0 / TIME_PER_ACTION
    FRAMES_PER_ACTION = 8

    RIGHT_RUN,LEFT_RUN,FRONT_RUN,BACK_RUN,RIGHT,LEFT,FRONT,BACK = 0,1,2,3,4,5,6,7

    eat_sound = None

    def __init__(self):
        self.x, self.y = 1000,600
        self.frame = random.randint(0,5)
        self.life_time = 0.0
        self.total_frames = 0.0
        self.xdir, self.ydir = 0, 0
        self.state = self.FRONT

        self.canvas_width = get_canvas_width()
        self.canvas_height = get_canvas_height()

        self.animaimage = load_image('resources\\animation_sheet3.png')
        self.frontimage = load_image('resources\\front.png')
        self.backimage = load_image('resources\\back.png')
        self.rightimage = load_image('resources\\right.png')
        self.leftimage = load_image('resources\\left.png')
        #------ key image --------------
        self.animaimage2 = load_image('resources\\animation_sheet3_key.png')
        self.frontimage2= load_image('resources\\front_k.png')
        self.backimage2 = load_image('resources\\back.png')
        self.rightimage2 = load_image('resources\\right_k.png')
        self.leftimage2 = load_image('resources\\left_k.png')
        #-----------------------
        self.stagenumber = 0
        self.itemcount = 0
        self.key = False
        self.meetboss = False
        self.doorcollide = False
        if Player.eat_sound == None :
            Player.eat_sound = load_wav('resources\\get.wav')
            Player.eat_sound.set_volume(15)

    def set_background(self, bg):
        self.bg = bg

    def update(self, frame_time):

        global distance

        def clamp(minimum, x, maximum):
            return max(minimum, min(x, maximum))

        self.life_time += frame_time
        distance = Player.RUN_SPEED_PPS * frame_time
        self.total_frames += Player.FRAMES_PER_ACTION * Player.ACTION_PER_TIME * frame_time
        self.frame = int(self.total_frames) % 6

        self.x += (self.xdir * distance)
        self.y += (self.ydir * distance)

        self.x = clamp(0, self.x, self.bg.width-1)
        self.y = clamp(0, self.y, self.bg.height-1)


        if self.xdir == -1: self.state = self.LEFT_RUN
        elif self.xdir == 1: self.state = self.RIGHT_RUN
        elif self.ydir == -1: self.state == self.FRONT_RUN
        elif self.ydir == 1 : self.state == self.BACK_RUN

        elif self.xdir == 0:
            if self.state == self.RIGHT_RUN: self.state = self.RIGHT
            elif self.state == self.LEFT_RUN: self.state = self.LEFT
        elif self.ydir == 0:
            if self.state == self.FRONT_RUN: self.state = self.FRONT
            elif self.state == self.BACK_RUN: self.state = self.BACK

        #------------------------------------------
       # print("x = %d" %self.x,"y = %d" %self.y)
        #------------------------------------------

    def set_background(self, bg):
        self.bg = bg


    def draw(self):

        global stagenumber

        x_left_offset = min(0, self.x - self.canvas_width//2)
        x_right_offset = max(0, self.x - self.bg.width + self.canvas_width//2)
        x_offset = x_left_offset + x_right_offset
        y_down_offset = min(0, self.y - self.canvas_height//2)
        y_up_offset = max(0, self.y - self.bg.height + self.canvas_height//2)
        y_offset = y_down_offset + y_up_offset

        if self.state == self.FRONT:
              if self.stagenumber == 3 :
                if self.key == True :
                    self.frontimage2.draw( self.canvas_width//2+x_offset, self.canvas_height//2+y_offset)#self.x,self.y)
                else :
                    self.frontimage.draw( self.canvas_width//2+x_offset, self.canvas_height//2+y_offset)#self.x,self.y)
              else:
                self.frontimage.draw( self.canvas_width//2+x_offset, self.canvas_height//2+y_offset)#self.x,self.y)
        elif self.state == self.BACK:
            self.backimage.draw( self.canvas_width//2+x_offset, self.canvas_height//2+y_offset)#self.x,self.y)

        elif self.state == self.RIGHT:
             if self.stagenumber == 3 :
                if self.key == True :
                   self.rightimage2.draw( self.canvas_width//2+x_offset, self.canvas_height//2+y_offset)#self.x,self.y)
                else :
                    self.rightimage.draw( self.canvas_width//2+x_offset, self.canvas_height//2+y_offset)#self.x,self.y)
             else:
                self.rightimage.draw( self.canvas_width//2+x_offset, self.canvas_height//2+y_offset)#self.x,self.y)
        elif self.state == self.LEFT:
             if self.stagenumber == 3 :
                if self.key == True :
                   self.leftimage2.draw( self.canvas_width//2+x_offset, self.canvas_height//2+y_offset)#self.x,self.y)
                else :
                    self.leftimage.draw(self.canvas_width//2+x_offset, self.canvas_height//2+y_offset)#self.x,self.y)
             else:
                self.leftimage.draw(self.canvas_width//2+x_offset, self.canvas_height//2+y_offset)#self.x,self.y)
        else :
            if self.stagenumber == 3 :
                if self.key == True :
                    self.animaimage2.clip_draw(self.frame * 70,self.state * 70 ,70,70, self.canvas_width//2+x_offset, self.canvas_height//2+y_offset) #self.x, self.y)
                else :
                    self.animaimage.clip_draw(self.frame * 70,self.state * 70 ,70,70, self.canvas_width//2+x_offset, self.canvas_height//2+y_offset) #self.x, self.y)
            else :
                self.animaimage.clip_draw(self.frame * 70,self.state * 70 ,70,70, self.canvas_width//2+x_offset, self.canvas_height//2+y_offset) #self.x, self.y)


    def draw_bb(self):
        draw_rectangle(*self.get_bb())

    def get_bb(self):

        x_left_offset = min(0, self.x - self.canvas_width//2)
        x_right_offset = max(0, self.x - self.bg.width + self.canvas_width//2)
        x_offset = x_left_offset + x_right_offset


        y_down_offset = min(0, self.y - self.canvas_height//2)
        y_up_offset = max(0, self.y - self.bg.height + self.canvas_height//2)
        y_offset = y_down_offset + y_up_offset

        return (self.canvas_width//2+x_offset)-30,(self.canvas_height//2+y_offset)-30,(self.canvas_width//2+x_offset)+30,(self.canvas_height//2+y_offset)+30

    def handle_event(self, event):
        #'''
        if (event.type, event.key) == (SDL_KEYDOWN, SDLK_LEFT):
            if self.state in (self.FRONT_RUN, self.BACK_RUN, self.RIGHT_RUN,self.FRONT,self.BACK,self.RIGHT,self.LEFT,self.LEFT_RUN):
                self.state = self.LEFT_RUN
                self.xdir += -1
        elif (event.type, event.key) == (SDL_KEYDOWN, SDLK_RIGHT):
            if self.state in (self.FRONT_RUN, self.BACK_RUN, self.LEFT_RUN,self.FRONT,self.BACK,self.RIGHT,self.LEFT,self.RIGHT_RUN):
                self.state = self.RIGHT_RUN
                self.xdir += 1
        elif (event.type, event.key) == (SDL_KEYDOWN, SDLK_DOWN):
            if self.state in (self.LEFT_RUN, self.BACK_RUN, self.RIGHT_RUN,self.FRONT,self.BACK,self.RIGHT,self.LEFT):
                self.state = self.FRONT_RUN
                self.ydir += -1
        elif (event.type, event.key) == (SDL_KEYDOWN, SDLK_UP):
            if self.state in  (self.LEFT_RUN, self.FRONT_RUN, self.RIGHT_RUN,self.FRONT,self.BACK,self.RIGHT,self.LEFT):
                self.state = self.BACK_RUN
                self.ydir += 1

        elif (event.type, event.key) == (SDL_KEYUP,SDLK_LEFT):
            if self.state in (self.LEFT_RUN, self.FRONT_RUN, self.RIGHT_RUN,self.BACK_RUN,self.FRONT,self.BACK,self.RIGHT,self.LEFT):
                 self.xdir += 1
                 self.state = self.LEFT
        elif (event.type, event.key) == (SDL_KEYUP,SDLK_RIGHT):
            if self.state in (self.LEFT_RUN, self.FRONT_RUN, self.RIGHT_RUN,self.BACK_RUN,self.FRONT,self.BACK,self.RIGHT,self.LEFT):
                 self.xdir += -1
                 self.state = self.RIGHT
        elif (event.type, event.key) == (SDL_KEYUP,SDLK_UP):
            if self.state in (self.LEFT_RUN, self.FRONT_RUN, self.RIGHT_RUN,self.BACK_RUN,self.FRONT,self.BACK,self.RIGHT,self.LEFT):
                 self.ydir += -1
                 self.state = self.BACK

        elif (event.type, event.key) == (SDL_KEYUP,SDLK_DOWN):
            if self.state in (self.LEFT_RUN, self.FRONT_RUN, self.RIGHT_RUN,self.BACK_RUN,self.FRONT,self.BACK,self.RIGHT,self.LEFT):
                 self.ydir += 1
                 self.state = self.FRONT

    '''
        #--------------------------------------------------

        elif event.type == SDL_KEYUP:
            if event.key == SDLK_LEFT:
                 self.xdir += 1
                 self.state = self.LEFT
            elif event.key == SDLK_RIGHT:
                self.xdir += -1
                self.state = self.RIGHT
            elif event.key == SDLK_UP:
                self.ydir += -1
                self.state = self.BACK
            elif event.key == SDLK_DOWN:
                self.ydir += 1
                self.state = self.FRONT
        #-----------------------------------------------

        #bagic
        if event.type == SDL_KEYDOWN:
            if event.key == SDLK_LEFT:
                self.xdir += -1
                self.state = self.LEFT_RUN

            elif event.key == SDLK_RIGHT:
                self.xdir += 1
                self.state = self.RIGHT_RUN
            elif event.key == SDLK_UP:
                self.ydir += 1
                self.state = self.BACK_RUN
            elif event.key == SDLK_DOWN:
                self.ydir += -1
                self.state = self.FRONT_RUN

        if event.type == SDL_KEYUP:
            if event.key == SDLK_LEFT:
                 self.xdir += 1
                 self.state = self.LEFT_RUN
            elif event.key == SDLK_RIGHT:
                self.xdir += -1
                self.state = self.RIGHT_RUN
            elif event.key == SDLK_UP:
                self.ydir += -1
                self.state = self.BACK_RUN
            elif event.key == SDLK_DOWN:
                self.ydir += 1
                self.state = self.FRONT_RUN
    '''

    def stop(self):

        if self.state in (self.RIGHT_RUN,self.RIGHT) :
            self.x -= (self.xdir * distance) + 5

        elif self.state in (self.LEFT_RUN,self.LEFT) :
            self.x -= (self.xdir * distance) - 5

        elif self.state in (self.FRONT_RUN,self.FRONT):
            self.y -= (self.ydir * distance) - 5

        elif self.state in (self.BACK_RUN,self.BACK) :
            self.y -= (self.ydir * distance) + 5



    def playsound(self):

        self.eat_sound.play(1)

    def getItem(self):

        global itemcount
        if self.itemcount < 5:
            self.itemcount += 1
            print("itemcount = ",self.itemcount)
        else :
            print("dont need more item")

    def useItem(self):
        global itemcount
        if self.itemcount >= 0 :
          self.itemcount -= 1
          print("itemcount = ",self.itemcount)
        else :
            print ("can't use item")

    def usekey(self):
        self.key = False

    def set_pos(self,x,y):
        self.x = x
        self.y = y

    def get_stagenumber(self,num):
        self.stagenumber = num

    def get_pos(self):

        return self.x,self.y