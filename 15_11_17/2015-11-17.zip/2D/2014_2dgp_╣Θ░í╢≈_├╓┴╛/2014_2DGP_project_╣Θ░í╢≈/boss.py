import random
import os

from pico2d import *
import viewport

class Boss:

    image = None;

    def __init__(self):
        self.x, self.y = 4800,600
        self.state = None
        if Boss.image == None:
            Boss.image = load_image('resources\\boss.png')

    def update(self, frame_time):
        pass

    def draw(self):

        if self.x < viewport.left : return
        if self.x > viewport.left+viewport.width : return
        if self.y < viewport.bottom : return
        if self.y > viewport.bottom + viewport.height : return

        self.image.draw(self.x - viewport.left,self.y-viewport.bottom)

    def draw_bb(self):
        draw_rectangle(*self.get_bb())

    def get_bb(self):
        return (self.x - viewport.left) -75, (self.y-viewport.bottom) - 75, (self.x - viewport.left) + 75, (self.y-viewport.bottom) + 75

class Enemy_green:

    image = None;

    RIGHT_RUN,LEFT_RUN = 0,1

    def __init__(self):
        self.x, self.y = 1800,280
        self.frame = random.randint(0,2)
        self.xdir, self.ydir = 0, 0
        self.state = self.RIGHT_RUN
        self.speed = 50
        if Enemy_green.image == None:
            Enemy_green.image = load_image('resources\\green.png')

    def update(self, frame_time):
        self.x += frame_time * self.speed

        if self.x > 1800:
            self.xdir += 1
            self.x = 1800
            self.speed = -self.speed
            self.state = self.LEFT_RUN

        if  self.x <  1600:
            self.xdir -= 1
            self.x = 1600
            self.speed = -self.speed
            self.state = self.RIGHT_RUN

    def draw(self):

        if self.x < viewport.left : return
        if self.x > viewport.left+viewport.width : return
        if self.y < viewport.bottom : return
        if self.y > viewport.bottom + viewport.height : return

        if self.state == self.RIGHT_RUN:
            self.image.clip_draw(self.frame * 50,self.state * 50,50,50,self.x - viewport.left,self.y-viewport.bottom)
        elif self.state == self.LEFT_RUN:
            self.image.clip_draw(self.frame * 50,self.state * 50,50,50,self.x - viewport.left,self.y-viewport.bottom)

    def draw_bb(self):
        draw_rectangle(*self.get_bb())

    def get_bb(self):
        return (self.x - viewport.left) -20, (self.y-viewport.bottom) - 20, (self.x - viewport.left) + 20, (self.y-viewport.bottom) + 20



class Enemy_red:

    image = None;

    FRONT_RUN,BACK_RUN = 2,3

    def __init__(self):
        self.x, self.y = 300,450
        self.frame = random.randint(0,2)
        self.xdir, self.ydir = 0, 0
        self.state = self.FRONT_RUN
        self.speed = 100
        if Enemy_red.image == None:
            Enemy_red.image = load_image('resources\\red.png')

    def update(self, frame_time):
        self.y += frame_time * self.speed

        if self.y > 700:
            self.ydir += 1
            self.y = 700
            self.speed = -self.speed
            self.state = self.FRONT_RUN

        if  self.y < 500 :
            self.ydir -= 1
            self.y = 500
            self.speed = -self.speed
            self.state = self.BACK_RUN

    def draw(self):

        if self.x < viewport.left : return
        if self.x > viewport.left+viewport.width : return
        if self.y < viewport.bottom : return
        if self.y > viewport.bottom + viewport.height : return

        if self.state == self.FRONT_RUN:
            self.image.clip_draw(self.frame * 50,self.state * 50,50,50,self.x - viewport.left,self.y-viewport.bottom)
        elif self.state == self.BACK_RUN:
            self.image.clip_draw(self.frame * 50,self.state * 50,50,50,self.x - viewport.left,self.y-viewport.bottom)

    def draw_bb(self):
        draw_rectangle(*self.get_bb())

    def get_bb(self):
        return (self.x - viewport.left) -20, (self.y-viewport.bottom) - 20, (self.x - viewport.left) + 20, (self.y-viewport.bottom) + 20

