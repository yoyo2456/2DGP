import game_framework
import main_state
import quiz_state
import start_state
import title_state

from pico2d import *

name = "endstate"
image = None

def enter():
    global sadimage,happyimage
    global endnumber
    endnumber = 1

    sadimage = load_image('resources\\ending_s.jpg')
    happyimage= load_image('resources\\ending_h.jpg')

def exit():
    '''
    global sadimage,happyimage
    del(sadimage)
    del(happyimage)
    '''

def pause():
    pass

def resume():
    pass


def handle_events(frame_time):
    events = get_events()
    for event in events:
        if event.type == SDL_QUIT:
            game_framework.quit()
        else :
            if (event.type,event.key) == (SDL_KEYDOWN,SDLK_ESCAPE):
              game_framework.quit()

            elif (event.type,event.key) == (SDL_KEYDOWN,SDLK_r):
                game_framework.push_state(title_state)


def update(frame_time):
    pass


def draw(frame_time):
    global image
    clear_canvas()

    if endnumber == 1:
        sadimage.draw(400,300)
    else :
        happyimage.draw(400,300)

    update_canvas()

def getEnd(number):

    global endnumber
    endnumber = number

