import game_framework
import quiz_state
from pico2d import *
import os
from player import Player

name = "TitleState"
image = None

def enter():
    global h1image,h2image,h3image,h4image,h5image
    global hint_time
    global quiz_num

    hint_time = 0.0
    quiz_num = 0

    h1image = load_image('resources\\h1.png')
    h2image = load_image('resources\\h2.png')
    h3image = load_image('resources\\h3.png')
    h4image = load_image('resources\\h4.png')
    h5image = load_image('resources\\h5.png')

def exit():
    global h1image,h2image,h3image,h4image,h5image
    del(h1image)
    del(h2image)
    del(h3image)
    del(h4image)
    del(h5image)

def pause():
    pass

def resume():
    pass


def handle_events(frame_time):
    events = get_events()
    for event in events:
        if event.type == SDL_QUIT:
            game_framework.quit()
        else :
            if (event.type,event.key) == (SDL_KEYDOWN,SDLK_ESCAPE):
              game_framework.quit()

            elif (event.type,event.key) == (SDL_KEYDOWN,SDLK_h):
                pass
              #  game_framework.pop_state()



def update(frame_time):
    global hint_time

    hint_time += frame_time

    if hint_time > 3:
        game_framework.pop_state()


def draw(frame_time):
    global h1image,h2image,h3image,h4image,h5image,quiz_num


    #h1image.draw(400,300)

    quiz_num = quiz_state.set_qStage()

    if quiz_num == 1:
        h1image.draw(400,300)
    elif quiz_num == 2:
        h2image.draw(400,300)
    elif quiz_num == 3:
        h3image.draw(400,300)
    elif quiz_num == 4:
        h4image.draw(400,300)
    elif quiz_num == 5:
        h5image.draw(400,300)

    update_canvas()




