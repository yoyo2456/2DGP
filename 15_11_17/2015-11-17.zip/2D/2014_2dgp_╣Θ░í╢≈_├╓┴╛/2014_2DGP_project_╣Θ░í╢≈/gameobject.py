import random
import os

from pico2d import *
import viewport

class Item:

    image = None;

    def __init__(self):
        self.x, self.y = 100,100
        self.state = None
        if Item.image == None:
            Item.image = load_image('resources\\item.png')

    def update(self, frame_time):
        pass

    def draw(self):
        if self.x < viewport.left : return
        if self.x > viewport.left+viewport.width : return
        if self.y < viewport.bottom : return
        if self.y > viewport.bottom + viewport.height : return

        self.image.draw(self.x - viewport.left,self.y-viewport.bottom)

    def draw_bb(self):
        draw_rectangle(*self.get_bb())

    def get_bb(self):
       return (self.x - viewport.left) - 20, (self.y-viewport.bottom) - 20,(self.x - viewport.left) + 20,(self.y-viewport.bottom) + 20

    def create_item():

        item_data_file = open('resources\\Item_data.txt', 'r')
        item_data = json.load(item_data_file)
        item_data_file.close()

        team = []

        for name in item_data:
            item = Item()
            item.name = name
            item.x = item_data[name]['x']
            item.y = item_data[name]['y']
            team.append(item)

        return team

class Key:

    image = None;

    def __init__(self):
        self.x, self.y = 100,600
        if Key.image == None:
            Key.image = load_image('resources\\key.png')
           # Key.
    def update(self, frame_time):
        pass

    def draw(self):

        if self.x < viewport.left : return
        if self.x > viewport.left+viewport.width : return
        if self.y < viewport.bottom : return
        if self.y > viewport.bottom + viewport.height : return

        self.image.opacify(100)
        self.image.draw(self.x - viewport.left,self.y-viewport.bottom)

    def draw_bb(self):
        draw_rectangle(*self.get_bb())

    def get_bb(self):
        return  (self.x - viewport.left)- 20,(self.y-viewport.bottom) - 20,  (self.x - viewport.left) + 20, (self.y-viewport.bottom) + 20

    def remove_img(self) :
        self.image.opacify(0)


class Door:

    image = None;
    doorsound = None

    def __init__(self):
        self.x, self.y = 4300,547
        if Door.image == None:
            Door.image = load_image('resources\\door.png')
        self.doormeet = False
        if Door.doorsound == None :
            Door.doorsound =load_wav('resources\\doorbreak.wav')
            Door.doorsound.set_volume(15)

    def update(self, frame_time):
        pass

    def draw(self):
        if self.x < viewport.left : return
        if self.x > viewport.left+viewport.width : return
        if self.y < viewport.bottom : return
        if self.y > viewport.bottom + viewport.height : return
        self.image.opacify(100)
        self.image.draw(self.x - viewport.left,self.y-viewport.bottom)


    def draw_bb(self):
        draw_rectangle(*self.get_bb())

    def get_bb(self):
        return (self.x - viewport.left)- 50,(self.y-viewport.bottom) - 50,  (self.x - viewport.left) + 50, (self.y-viewport.bottom) + 50

    def remove_img(self) :
        self.doorsound.play()
        self.image.opacify(0)

class UI :
    def __init__(self):
        self.image = load_image('resources\\ui.png')

    def draw(self):
        self.image.draw(400,300)

class Info :
    def __init__(self):
        self.image = load_image('resources\\info.png')
        self.info = True

    def draw(self):
        if self.info == True :
            self.image.opacify(100)
            self.image.draw(400,300)
        elif self.info == False:
            self.image.opacify(0)


class Lifeheart :

    def __init__(self):
         self.x,self.y = 700,75
         self.image1 = load_image('resources\\life3.png')
         self.image2 = load_image('resources\\life2.png')
         self.image3 = load_image('resources\\life1.png')
         self.sound = load_wav('resources\\clock.wav')
         self.time = 0.0

    def draw(self):
        if self.time < 15:
           self.image1.draw(self.x,self.y)
           self.sound.set_volume(0)
        elif self.time < 30:
           self.image2.draw(self.x,self.y)
           self.sound.play()
           self.sound.set_volume(50)
        elif self.time < 45:
           self.image3.draw(self.x,self.y)
           self.sound.play(70)
    def get_time(self,t):
        self.time = t


