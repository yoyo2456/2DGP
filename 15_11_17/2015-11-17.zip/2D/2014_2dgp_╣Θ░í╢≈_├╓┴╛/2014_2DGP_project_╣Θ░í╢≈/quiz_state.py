import game_framework
from pico2d import *
import json
import title_state
import hint_state
import os
from player import Player

name = "quizstate"

player = None

def enter():
    global font,rAnswer,wAnswer,player
    global q1image,q2image,q3image,q4image,q5image,quiz_bg
    global h1image,h2image,h3image,h4image,h5image,hint
    global qStage,points,hStage,hint_time
    global g1image,g2image,g3image,gaugeimage
    global sadimage,happyimage
    global endnumber,bgm,hintpoint

    player = Player()

    hint = False
    hint_time = 0.0
    hintpoint = 4

    endnumber = 0
    qStage = 1
    rAnswer = 0
    wAnswer = 0

    font=load_font('resources\\ENCR10B.TTF')
    q1image = load_image('resources\\q1.png')
    q2image = load_image('resources\\q2.png')
    q3image = load_image('resources\\q3.png')
    q4image = load_image('resources\\q4.png')
    q5image = load_image('resources\\q5.png')
    quiz_bg = load_image('resources\\quiz_bg.png')

    sadimage = load_image('resources\\ending_s.jpg')
    happyimage= load_image('resources\\ending_h.jpg')


    g1image = load_image('resources\\g1.png')
    g2image = load_image('resources\\g2.png')
    g3image = load_image('resources\\g3.png')
    gaugeimage = load_image('resources\\gaugebar.png')

    bgm = load_music('resources\\quiz.mp3')

    bgm.set_volume(100)
    bgm.repeat_play()


def exit():

    global g1image,g2image,g3image,gaugeimage,hintpoint

    del(g1image)
    del(g2image)
    del(g3image)
    del(gaugeimage)
    del(hintpoint)
    pass

def set_qStage():
    return qStage

def update(frame_time):
    pass

def draw(frame_time):
    global q1image,q2image,q3image,q4image,q5image,quiz_bg
    global g1image,g2image,g3image,gaugeimage
    global qStage,hStage,rAnswer

    clear_canvas()
    quiz_bg.draw(400,300)

    gaugeimage.draw(400,300)

    if rAnswer == 0 : g1image.draw(400,300)
    elif rAnswer == 1 : g2image.draw(400,300)
    elif rAnswer == 2 : g3image.draw(400,300)

   # image.draw(400,300)

    if qStage == 1 : q1image.draw(400,300)
    elif qStage == 2: q2image.draw(400,300)
    elif qStage == 3: q3image.draw(400,300)
    elif qStage == 4: q4image.draw(400,300)
    elif qStage == 5: q5image.draw(400,300)
    elif qStage == 6 : happyimage.draw(400,300)
    elif qStage == 7 : sadimage.draw(400,300)

    update_canvas()

def handle_events(frame_time):
    global hintpoint
    events = get_events()
    for event in events:
        if event.type == SDL_QUIT:
            game_framework.quit()
        else :
             if (event.type,event.key) == (SDL_KEYDOWN,SDLK_ESCAPE):
                  game_framework.quit()

             elif (event.type,event.key) == (SDL_KEYDOWN,SDLK_1):
                  check_anwser(1)
             elif (event.type,event.key) == (SDL_KEYDOWN,SDLK_2):
                  check_anwser(2)
             elif (event.type,event.key) == (SDL_KEYDOWN,SDLK_3):
                   check_anwser(3)

             elif (event.type,event.key) == (SDL_KEYDOWN,SDLK_h):
                    if hintpoint > 0 :
                       game_framework.push_state(hint_state)
                       hintpoint -= 1

                     #  print("player item = ",player.itemcount )

             elif (event.type,event.key) == (SDL_KEYDOWN,SDLK_r):
                  game_framework.push_state(title_state)


def check_anwser(answer):

    global qStage,rAnswer,wAnswer

    if qStage == 1 :
        if answer == 1 :
            rAnswer += 1
        else :
            wAnswer += 1
        qStage = 2

    elif qStage == 2 :
        if answer == 2 :
            rAnswer += 1
        else :
            wAnswer += 1
        qStage = 3

    elif qStage == 3:
        if answer == 3  :
            rAnswer += 1
        else :
            wAnswer += 1
        qStage = 4

    elif qStage == 4 :
        if answer ==  2:
            rAnswer += 1
        else :
            wAnswer += 1
        qStage = 5

    elif qStage == 5 :
        if answer == 2 :
            rAnswer += 1
        else :
            wAnswer += 1

    print("rAnswer = ",rAnswer,"wAnswer = ",wAnswer)

    if  rAnswer  == 3 or wAnswer == 3:   # + wAnswer == 5:
        result_check(rAnswer,wAnswer)

def result_check(r,w):

    global qStage #,rAnswer,wAnswer

    if r >= 3 :
        print("clear game")
        qStage = 6
    if w >= 3:
        print(" You Can't ecape the castle")
        qStage = 7


'''
def result_check(r,w):
    global qStage

    if r > 3 :
        print("clear game")
        qStage = 6
    else :
        print(" You Can't ecape the castle")
        qStage = 7
'''

def pause(): pass

def resume(): pass


