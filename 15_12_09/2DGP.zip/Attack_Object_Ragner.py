__author__ = 'incipe'

from pico2d import *
from Attack_Object import *
from maze import*
import random

ADAO = None
ALAO = None
ARAO  = None

class Down_Attack_Ranger:
    DA = 0


    PIXEL_PER_METER = (10.0 / 0.3)
    RUN_SPEED_KMPH = 20.0
    RUN_SPEED_MPM = (RUN_SPEED_KMPH * 1000.0 / 60.0)
    RUN_SPEED_MPS = (RUN_SPEED_MPM / 60.0)
    RUN_SPEED_PPS = (RUN_SPEED_MPS * PIXEL_PER_METER)

    TIME_PER_ACTION = 0.5
    ACTION_PER_TIME = 1.0 / TIME_PER_ACTION
    FRAMES_PER_ACTION = 8

    def __init__(self):
        global ADAO

       #Base Setting
        self.frame = random.randint(0, 1)
        self.down_attack = load_image('resource\\AttackObject\\attack.png')
        self.state = 0
        self.x=0
        self.y1=0
        self.y2=0
        self.y3=0
        self.y4=0
        self.total_frames = 0
        ADAO = Auto_Down_Attack_Object()






    def DownAttackUpdate(self, frame_time,State,DA):
        self.distance = Down_Attack_Ranger.RUN_SPEED_PPS * frame_time
        self.total_frames += Down_Attack_Ranger.FRAMES_PER_ACTION * Down_Attack_Ranger.ACTION_PER_TIME * frame_time

        if State == DA:
              if self.y1 > 0:
                self.y1 = 0
              elif self.x !=0:
                 self.x = 0
              else:
                self.y1 -= (self.distance/2)

        if State == DA:
              if self.y2 > 0:
                self.y2 = 0
              elif self.x !=0:
                 self.x = 0
              else:
                self.y2 -= (self.distance/2)

        if State == DA:
              if self.y3 > 0:
                self.y3 = 0
              elif self.x !=0:
                 self.x = 0
              else:
                self.y3 -= (self.distance/2)


        if State == DA:
              if self.y4 > 0:
                self.y4 = 0
              elif self.x !=0:
                 self.x = 0
              else:
                self.y4 -= (self.distance/2)




        #원거리 공격 사거리
        if self.y1 <= -300:
            self.y1 = 0

        if self.y2 <= -300:
            self.y2 = 0

        if self.y3 <= -300:
            self.y3 = 0

        if self.y4 <= -300:
            self.y4 = 0


    def DownAttackDraw(self,x,y):
      if y == ADAO.object_y1 and x == ADAO.object_x1:
        self.down_attack.draw(self.x + ADAO.object_x1, self.y1 + ADAO.object_y1 )
      if y == ADAO.object_y2 and x == ADAO.object_x2:
        self.down_attack.draw(self.x + ADAO.object_x2, self.y2 + ADAO.object_y2 )
      if y == ADAO.object_y3 and x == ADAO.object_x3:
        self.down_attack.draw(self.x + ADAO.object_x3, self.y3 + ADAO.object_y3 )
      if y == ADAO.object_y4 and x == ADAO.object_x4:
        self.down_attack.draw(self.x + ADAO.object_x4, self.y4 + ADAO.object_y4 )


    def get_bb2(self,x,y):
       if y == ADAO.object_y1 and x == ADAO.object_x1:
           return (self.x + x) - 5.5,(self.y1 + y) - 5.5,(self.x + x) + 5.5,(self.y1 + y) +5.5
       if y == ADAO.object_y2 and x == ADAO.object_x2:
           return (self.x + x) - 5.5,(self.y2 + y) - 5.5,(self.x + x) + 5.5,(self.y2 + y) +5.5
       if y == ADAO.object_y3 and x == ADAO.object_x3:
           return (self.x + x) - 5.5,(self.y3 + y) - 5.5,(self.x + x) + 5.5,(self.y3 + y) +5.5
       if y == ADAO.object_y4 and x == ADAO.object_x4:
           return (self.x + x) - 5.5,(self.y4 + y) - 5.5,(self.x + x) + 5.5,(self.y4 + y) +5.5


    def draw_bb(self,x,y):
        draw_rectangle(*self.get_bb2(x,y))



class Left_Attack_Ranger:
    LA = 0

    PIXEL_PER_METER = (10.0 / 0.3)
    RUN_SPEED_KMPH = 20.0
    RUN_SPEED_MPM = (RUN_SPEED_KMPH * 1000.0 / 60.0)
    RUN_SPEED_MPS = (RUN_SPEED_MPM / 60.0)
    RUN_SPEED_PPS = (RUN_SPEED_MPS * PIXEL_PER_METER)

    TIME_PER_ACTION = 0.5
    ACTION_PER_TIME = 1.0 / TIME_PER_ACTION
    FRAMES_PER_ACTION = 8

    def __init__(self):

       #Base Setting
        self.frame = random.randint(0, 1)
        self.left_attack = load_image('resource\\AttackObject\\left_attack.png')
        self.state = self.LA
        self.x1=0
        self.x2=0
        self.y=0
        self.total_frames = 0

        global ALAO
        ALAO = Auto_Left_Attack_Object()



    def LeftAttackUpdate(self, frame_time,State,LA):
        self.distance = Left_Attack_Ranger.RUN_SPEED_PPS * frame_time
        self.total_frames += Left_Attack_Ranger.FRAMES_PER_ACTION * Left_Attack_Ranger.ACTION_PER_TIME * frame_time

        if State == LA:
            if self.x1 < 0:
                self.x1 = 0
            elif self.y !=0:
               self.y = 0
            else:
                self.x1 += self.distance/4

        if State == LA:
            if self.x2 < 0:
                self.x2 = 0
            elif self.y !=0:
               self.y = 0
            else:
                self.x2 += self.distance/4


        #원거리 공격 사거리
        if self.x1 >= 500:
            self.x1 = 0

        if self.x2 >= 500:
            self.x2 = 0


    def LeftAttackDraw(self,x,y):
          if y == ALAO.object_y1 and x == ALAO.object_x1:
              self.left_attack.draw(self.x1 + ALAO.object_x1, self.y + ALAO.object_y1 )
          if y == ALAO.object_y2 and x == ALAO.object_x2:
              self.left_attack.draw(self.x2 + ALAO.object_x2, self.y + ALAO.object_y2 )

    def get_bb2(self,x,y):
         if y == ALAO.object_y1 and x == ALAO.object_x1:
              return (self.x1 + x) - 5.5,(self.y + y) - 5.5,(self.x1 + x) + 5.5,(self.y + y) +5.5
         if y == ALAO.object_y2 and x == ALAO.object_x2:
              return (self.x2 + x) - 5.5,(self.y + y) - 5.5,(self.x2 + x) + 5.5,(self.y + y) +5.5

    def draw_bb(self,x,y):
        draw_rectangle(*self.get_bb2(x,y))




class Right_Attack_Ranger:
    RA = 0

    PIXEL_PER_METER = (10.0 / 0.3)
    RUN_SPEED_KMPH = 20.0
    RUN_SPEED_MPM = (RUN_SPEED_KMPH * 1000.0 / 60.0)
    RUN_SPEED_MPS = (RUN_SPEED_MPM / 60.0)
    RUN_SPEED_PPS = (RUN_SPEED_MPS * PIXEL_PER_METER)

    TIME_PER_ACTION = 0.5
    ACTION_PER_TIME = 1.0 / TIME_PER_ACTION
    FRAMES_PER_ACTION = 8

    def __init__(self):

       #Base Setting
        self.frame = random.randint(0, 1)
        self.right_attack = load_image('resource\\AttackObject\\right_attack.png')
        self.state = self.RA
        self.x1=0
        self.y=0
        self.total_frames = 0

        global ARAO
        ARAO = Auto_Right_Attack_Object()



    def RightAttackUpdate(self, frame_time,State,RA):
        self.distance = Right_Attack_Ranger.RUN_SPEED_PPS * frame_time
        self.total_frames += Right_Attack_Ranger.FRAMES_PER_ACTION * Right_Attack_Ranger.ACTION_PER_TIME * frame_time

        if State == RA:
            if self.x1 > 0:
                self.x1 = 0
            elif self.y !=0:
               self.y = 0
            else:
                self.x1 -= self.distance/4


        #원거리 공격 사거리
        if self.x1 < -500:
            self.x1 = 0



    def RightAttackDraw(self,x,y):
          if y == ARAO.object_y1 and x == ARAO.object_x1:
              self.right_attack.draw(self.x1 + ARAO.object_x1, self.y + ARAO.object_y1 )


    def get_bb2(self,x,y):
         if y == ARAO.object_y1 and x == ARAO.object_x1:
              return (self.x1 + x) - 5.5,(self.y + y) - 5.5,(self.x1 + x) + 5.5,(self.y + y) +5.5

    def draw_bb(self,x,y):
        draw_rectangle(*self.get_bb2(x,y))