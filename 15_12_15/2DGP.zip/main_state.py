import os, sys,json, random
import end_state
from pico2d import *
from maze import *
from Player import *
from Player_Ranger import *
from Effect import *
from AI import *
from AI_Ranger import *
from Object import *
from Attack_Object import *
from Attack_Object_Ragner import *
import title_state
import game_framework


name = "MainState"
count = None
font = None
ui_font = None




def get_frame_time():

    global current_time

    frame_time = get_time() - current_time
    current_time += frame_time
    return frame_time


# Global 변수 및 기타 변수 선언
def enter():

    #Player 관련
    global player,background
    global ranger #플레이어 원거리 공격

    #Effect 관련
    global effect, effect_2


    #AI 관련
    global ai_1,ai_2,ai_3,ai_4
    global ai_ranger_1,ai_ranger_2,ai_ranger_3,ai_ranger_4
    global ai_1s

    #Map 관련
    global out_tile,in_tile,ui_board

    #Object 관련
    global blue_jewelry,red_jewelry, green_jewelry, yellow_jewelry
    global hp_object,power_object

    #Attack 오브젝트 관련
    global auto_down_attack_object,auto_left_attack_object,auto_right_attack_object
    global auto_down_ranger,auto_left_ranger,auto_right_ranger,jewelry_sound

    #-s 관련
    global out_tiles, in_tiles, blue_jewelrys, red_jewelrys, green_jewelrys, yellow_jewelrys


    #Font & UI_Draw 관련
    global font, ui_font
    global timer

    timer = 0.0

    #...... Sound 관련 ......#
    jewelry_sound = Jewelry_Sound()

    #......Player 관련 ......#
    player = Player()
    ranger = Ranger()

     #......Effect 관련 ......#
    effect = Effect_1()
    effect_2 = Effect_2()

     #......Font 관련 ......#
    font = load_font('Font\\2DGP.TTF')
    ui_font = ui_load_font('Font\\2DGP.TTF')

    #......AI 관련 ......#
    ai_1 = AI_1()
    ai_2 = AI_2()
    ai_3 = AI_3()
    ai_4 = AI_4()

    ai_ranger_1 = AI_Ranger_1()
    ai_ranger_2 = AI_Ranger_2()
    ai_ranger_3 = AI_Ranger_3()
    ai_ranger_4 = AI_Ranger_4()

     #......Map 관련 ......#
    background = Background()
    ui_board = UI_Board()
    out_tile = Out_Tile()
    in_tile = In_Tile()

    in_tiles = in_tile.create_in_tile()
    #out_tiles = out_tile.create_out_tile()

    #......Ojbect 관련 ......#
    red_jewelry = red_Jewelry()
    blue_jewelry = blue_Jewelry()
    green_jewelry = green_Jewelry()
    yellow_jewelry = yellow_Jewelry()
    hp_object = HP_Object()
    power_object = Power_Object()


    blue_jewelrys = blue_jewelry.create_blue_jewelry()
    red_jewelrys = red_jewelry.create_red_jewelry()
    green_jewelrys = green_jewelry.create_green_jewelry()
    yellow_jewelrys =  yellow_jewelry.create_yellow_jewelry()

    #......Auto Attack_Obect 관련 ......#

    #..Down..#
    auto_down_attack_object =  Auto_Down_Attack_Object()
    auto_down_ranger = Down_Attack_Ranger()

    #..Left..#
    auto_left_attack_object =  Auto_Left_Attack_Object()
    auto_left_ranger = Left_Attack_Ranger()

    #..Right..#
    auto_right_attack_object = Auto_Right_Attack_Object()
    auto_right_ranger = Right_Attack_Ranger()


# Collide
def collide(a,b):
     left_a, bottom_a, right_a, top_a = a.get_bb()
     left_b, bottom_b, right_b, top_b = b.get_bb()

     if left_a > right_b:
         return False
     if right_a < left_b:
         return False
     if top_a < bottom_b:
          return False
     if bottom_a > top_b:
          return False
     return True


# Collide2, Ranger 전용
def collide2(a,b,player_x,player_y):
     left_a, bottom_a, right_a, top_a = a.get_bb2(player_x,player_y)
     left_b, bottom_b, right_b, top_b = b.get_bb()

     if left_a > right_b:
         return False
     if right_a < left_b:
         return False
     if top_a < bottom_b:
          return False
     if bottom_a > top_b:
          return False
     return True


def collide3(a,b,X1,Y1,X2,Y2):
     left_a, bottom_a, right_a, top_a = a.get_bb2(X1,Y1)
     left_b, bottom_b, right_b, top_b = b.get_bb2(X2,Y2)

     if left_a > right_b:
         return False
     if right_a < left_b:
         return False
     if top_a < bottom_b:
          return False
     if bottom_a > top_b:
          return False
     return True


def handle_events(frame_time):
    events = get_events()
    for event in events:
        if event.type == SDL_QUIT:
            game_framework.quit()
        elif event.type == SDL_KEYDOWN and event.key == SDLK_ESCAPE:
            game_framework.change_state(title_state)
        else:
            player.handle_event(event)

current_time = 0.0



def update(frame_time):
    global out_tile,out_tiles,in_tile,in_tiles,road,roads
    global count, timer

    out_tiles = out_tile.create_out_tile() #Frame 조절용






#.........................................................................#
                  # Object Collide #


    #for hp_object in hp_objects:
    if hp_object.switch == True and hp_object.random_number[0] == 0:
           if collide(player, hp_object):
              player.hp +=20
              hp_object.get_hp_sound.play()
              hp_object.x, hp_object.y = -25, -25
              player.score +=200
              hp_object.switch = False
           if player.hp >= 100:
              player.hp = 100

    if power_object.switch == True:
           if collide(player, power_object):
              if power_object.random_number[0] == 0:
                  power_object.get_power_sound.play()
                  player.power += 20
                  ranger.basic_power_switch = False
                  ranger.mid_power_switch = True
                  ranger.high_power_switch = False
                  player.score +=250
                  power_object.x, power_object.y = -50, -50
                  power_object.switch = False
                  if player.power > 50:
                      player.power = 50

              if power_object.random_number[1] == 2:
                  power_object.get_power_sound.play()
                  player.power += 70
                  ranger.basic_power_switch = False
                  ranger.mid_power_switch = False
                  ranger.high_power_switch = True
                  player.score +=300
                  power_object.x, power_object.y = -50, -50
                  power_object.switch = False
                  if player.power > 100:
                      player.power = 100







    for blue_jewelry in blue_jewelrys:
        if collide(player, blue_jewelry):
           blue_jewelrys.remove(blue_jewelry)
           jewelry_sound.get_jewelry_sound.play()
           player.get_BJ()
           player.score +=1000

    for yellow_jewelry in yellow_jewelrys:
        if collide(player, yellow_jewelry):
           yellow_jewelrys.remove(yellow_jewelry)
           jewelry_sound.get_jewelry_sound.play()
           player.get_YJ()
           player.score +=1000

    for red_jewelry in red_jewelrys:
        if collide(player, red_jewelry):
           red_jewelrys.remove(red_jewelry)
           jewelry_sound.get_jewelry_sound.play()
           player.get_RJ()
           player.score +=1000

    for green_jewelry in green_jewelrys:
        if collide(player, green_jewelry):
           green_jewelrys.remove(green_jewelry)
           jewelry_sound.get_jewelry_sound.play()
           player.get_GJ()
           player.score +=1000

#.........................................................................#

#.........................................................................#
                  # player 관련 Collide #

    # Out_tile 관련 Collide
    for out_tile in out_tiles:
       #Player, tile Attack Collide(원거리 공격)
       if collide2(ranger,out_tile,player.x,player.y):
           ranger.old_y = 0
           ranger.old_x = 0
           if player.state == player.LEFT_ATTACK:
               if player.x + ranger.x  < out_tile.x:
                   ranger.old_x = ranger.x
                   effect.effect_switch = True
                   ranger.x = 0

           if player.state == player.RIGHT_ATTACK:
               if player.x + ranger.x + 75 > out_tile.x: # xPos +75 보정값
                   ranger.old_x = ranger.x
                   effect.effect_switch = True
                   ranger.x = 0

           if player.state == player.UP_ATTACK :
               if player.y + ranger.y + 25 > out_tile.y: # yPos +25 보정값
                   ranger.old_y = ranger.y
                   effect.effect_switch = True
                   ranger.y = 0

           if player.state == player.DOWN_ATTACK:
               if player.y + ranger.y + 25 > out_tile.y:
                   ranger.old_y = ranger.y
                   effect.effect_switch = True
                   ranger.y = 0

    # in_tile 관련 Collide
    for in_tile in in_tiles:
       if collide(player,in_tile):
           #1 Player, Tile Move Collide
           if (player.state == player.LEFT_MOVE or player.state == player.STANDING):
                if player.x  < in_tile.x:
                   if player.x > in_tile.x + 25:
                       pass
                elif player.x < in_tile.x + 25:
                      player.leftCollide_Player()

           if (player.state == player.RIGHT_MOVE or player.state == player.STANDING):
                if player.x  < in_tile.x:
                   if player.x > in_tile.x - 25:
                       pass
                   elif player.x < in_tile.x - 25:
                      player.rightCollide_Player()

           if (player.state == player.UP_MOVE or player.state == player.STANDING):
               if player.y  < in_tile.y:
                   if player.y > in_tile.y - 25:
                       pass
                   elif player.y < in_tile.y - 25:
                      player.upCollide_Player()

           if (player.state == player.DOWN_MOVE or player.state == player.STANDING):
                 if player.y  > in_tile.y:
                     player.downCollide_Player()


    #2 player, Tile Attack Collide(원거리 공격)
    for in_tile in in_tiles:
       if collide2(ranger,in_tile,player.x,player.y):
           #새로운 old 좌표 받기전에 이전 좌표 초기화
           ranger.old_y = 0
           ranger.old_x = 0

           if player.state == player.LEFT_ATTACK:
               if player.x + ranger.x  < in_tile.x:
                   ranger.old_x = ranger.x
                   effect.effect_switch = True
                   ranger.x = 0

           if player.state == player.RIGHT_ATTACK:
               if player.x + ranger.x  < in_tile.x:
                   ranger.old_x = ranger.x
                   effect.effect_switch = True
                   ranger.x = 0

           if player.state == player.UP_ATTACK :
               if player.y + ranger.y  < in_tile.y:
                   ranger.old_y = ranger.y
                   effect.effect_switch = True
                   ranger.y = 0

           if player.state == player.DOWN_ATTACK:
               if player.y + ranger.y - 25 < in_tile.y:
                   ranger.old_y = ranger.y
                   effect.effect_switch = True
                   ranger.y = 0

#.........................................................................#





# 기본적인 IF 조건 설정 후 내부에서 '25' 수치를 이용해 각 방향에 따른 충돌체크 보정#

#.........................................................................#
                  # player -> AI Collide  #

    #1-1 Player Ranger, AI  attack Collide
    if collide2(ranger,ai_1,player.x,player.y):
          if player.state == player.LEFT_ATTACK:
             if ai_1.switch == True:
               if player.x + ranger.x  < ai_1.x:
                   ranger.x = 0
                   ai_1.hp -=player.power
                   effect.effect_switch = True
                   if ai_1.hp <= 0:
                     player.score +=2000
                     ai_1.switch = False
                     random.shuffle(hp_object.random_number)
                     hp_object.switch = True
                     hp_object.x = ai_1.x
                     hp_object.y = ai_1.y


          if player.state == player.RIGHT_ATTACK:
             if ai_1.switch == True:
               if player.x + ranger.x  < ai_1.x:
                   ranger.x = 0
                   ai_1.hp -=player.power
                   effect.effect_switch = True
                   if ai_1.hp <= 0:
                       player.score +=2000
                       random.shuffle(hp_object.random_number)
                       ai_1.switch = False
                       hp_object.switch = True
                       hp_object.x = ai_1.x
                       hp_object.y = ai_1.y

          if player.state == player.UP_ATTACK :
             if ai_1.switch == True:
               if player.y + ranger.y  < ai_1.y:
                   ranger.y = 0
                   ai_1.hp -=player.power
                   effect.effect_switch = True
                   if ai_1.hp <= 0:
                       player.score +=2000
                       random.shuffle(hp_object.random_number)
                       ai_1.switch = False
                       hp_object.switch = True
                       hp_object.x = ai_1.x
                       hp_object.y = ai_1.y

          if player.state == player.DOWN_ATTACK:
              if ai_1.switch == True:
               if player.y + ranger.y - 25 < ai_1.y:
                   ranger.y = 0
                   ai_1.hp -=player.power
                   effect.effect_switch = True
                   if ai_1.hp <= 0:
                       player.score +=2000
                       random.shuffle(hp_object.random_number)
                       ai_1.switch = False
                       hp_object.switch = True
                       hp_object.x = ai_1.x
                       hp_object.y = ai_1.y



    #1-2 Player Ranger, AI  attack Collide
    if collide2(ranger,ai_2,player.x,player.y):
          if player.state == player.LEFT_ATTACK:
             if ai_2.switch == True:
               if player.x + ranger.x  < ai_2.x:
                   ranger.x = 0
                   ai_2.hp -=player.power
                   effect.effect_switch = True
                   if ai_2.hp <= 0:
                       player.score +=2000
                       random.shuffle(hp_object.random_number)
                       ai_2.switch = False
                       hp_object.switch = True
                       hp_object.x = ai_2.x
                       hp_object.y = ai_2.y

          if player.state == player.RIGHT_ATTACK:
             if ai_2.switch == True:
               if player.x + ranger.x  < ai_2.x:
                   ranger.x = 0
                   ai_2.hp -=player.power
                   effect.effect_switch = True
                   if ai_2.hp <= 0:
                       player.score +=2000
                       random.shuffle(hp_object.random_number)
                       ai_2.switch = False
                       hp_object.switch = True
                       hp_object.x = ai_2.x
                       hp_object.y = ai_2.y


          if player.state == player.UP_ATTACK :
             if ai_2.switch == True:
               if player.y + ranger.y  < ai_2.y:
                   ranger.y = 0
                   ai_2.hp -=player.power
                   effect.effect_switch = True
                   if ai_2.hp <= 0:
                       player.score +=2000
                       random.shuffle(hp_object.random_number)
                       ai_2.switch = False
                       hp_object.switch = True
                       hp_object.x = ai_2.x
                       hp_object.y = ai_2.y


          if player.state == player.DOWN_ATTACK:
             if ai_2.switch == True:
               if player.y + ranger.y - 25 < ai_2.y:
                   ranger.y = 0
                   ai_2.hp -=player.power
                   effect.effect_switch = True
                   if ai_2.hp <= 0:
                       player.score +=2000
                       random.shuffle(hp_object.random_number)
                       ai_2.switch = False
                       hp_object.switch = True
                       hp_object.x = ai_2.x
                       hp_object.y = ai_2.y



    #1-3 Player Ranger, AI  attack Collide
    if collide2(ranger,ai_3,player.x,player.y):
          if player.state == player.LEFT_ATTACK:
             if ai_3.switch == True:
               if player.x + ranger.x  < ai_3.x:
                   ranger.x = 0
                   ai_3.hp -=player.power
                   effect.effect_switch = True
                   if ai_3.hp <= 0:
                       player.score +=2000
                       random.shuffle(hp_object.random_number)
                       ai_3.switch = False
                       hp_object.switch = True
                       hp_object.x = ai_3.x
                       hp_object.y = ai_3.y


          if player.state == player.RIGHT_ATTACK:
             if ai_3.switch == True:
               if player.x + ranger.x  < ai_3.x:
                   ranger.x = 0
                   ai_3.hp -=player.power
                   effect.effect_switch = True
                   if ai_3.hp <= 0:
                       player.score +=2000
                       random.shuffle(hp_object.random_number)
                       ai_3.switch = False
                       hp_object.switch = True
                       hp_object.x = ai_3.x
                       hp_object.y = ai_3.y

          if player.state == player.UP_ATTACK :
             if ai_3.switch == True:
               if player.y + ranger.y  < ai_3.y:
                   ranger.y = 0
                   ai_3.hp -=player.power
                   effect.effect_switch = True
                   if ai_3.hp <= 0:
                       player.score +=2000
                       random.shuffle(hp_object.random_number)
                       ai_3.switch = False
                       hp_object.switch = True
                       hp_object.x = ai_3.x
                       hp_object.y = ai_3.y

          if player.state == player.DOWN_ATTACK:
             if ai_3.switch == True:
               if player.y + ranger.y - 25 < ai_3.y:
                   ranger.y = 0
                   ai_3.hp -=player.power
                   effect.effect_switch = True
                   if ai_3.hp <= 0:
                       player.score +=2000
                       random.shuffle(hp_object.random_number)
                       ai_3.switch = False
                       hp_object.switch = True
                       hp_object.x = ai_3.x
                       hp_object.y = ai_3.y


    #1-4 Player Ranger, AI  attack Collide
    if collide2(ranger,ai_4,player.x,player.y):
          if player.state == player.LEFT_ATTACK:
             if ai_4.switch == True:
               if player.x + ranger.x  < ai_4.x:
                   ranger.x = 0
                   ai_4.hp -=player.power
                   effect.effect_switch = True
                   if ai_4.hp <= 0:
                       player.score +=2000
                       random.shuffle(hp_object.random_number)
                       ai_4.switch = False
                       hp_object.switch = True
                       hp_object.x = ai_4.x
                       hp_object.y = ai_4.y

          if player.state == player.RIGHT_ATTACK:
             if ai_4.switch == True:
               if player.x + ranger.x  < ai_4.x:
                   ranger.x = 0
                   ai_4.hp -=player.power
                   effect.effect_switch = True
                   if ai_4.hp <= 0:
                       player.score +=2000
                       random.shuffle(hp_object.random_number)
                       ai_4.switch = False
                       hp_object.switch = True
                       hp_object.x = ai_4.x
                       hp_object.y = ai_4.y

          if player.state == player.UP_ATTACK :
             if ai_4.switch == True:
               if player.y + ranger.y  < ai_4.y:
                   ranger.y = 0
                   ai_4.hp -=player.power
                   effect.effect_switch = True
                   if ai_4.hp <= 0:
                       player.score +=2000
                       random.shuffle(hp_object.random_number)
                       ai_4.switch = False
                       hp_object.switch = True
                       hp_object.x = ai_4.x
                       hp_object.y = ai_4.y

          if player.state == player.DOWN_ATTACK:
             if ai_4.switch == True:
               if player.y + ranger.y - 25 < ai_4.y:
                   ranger.y = 0
                   ai_4.hp -=player.power
                   effect.effect_switch = True
                   if ai_4.hp <= 0:
                       player.score +=2000
                       random.shuffle(hp_object.random_number)
                       ai_4.switch = False
                       hp_object.switch = True
                       hp_object.x = ai_4.x
                       hp_object.y = ai_4.y
#.........................................................................#

#.........................................................................#
                  # player -> Auto Collide  #

    #1-1 Player Ranger & DownAttack Obeject_1
    if auto_down_ranger.switch_1 == True :
          if collide3(ranger,auto_down_attack_object,player.x,player.y,auto_down_attack_object.object_x1,auto_down_attack_object.object_y1):
               ranger.old_y = 0
               ranger.old_x = 0

               if player.state == player.LEFT_ATTACK:
                       if player.x + ranger.x  < auto_down_attack_object.object_x1 :
                           ranger.x = 0
                           auto_down_attack_object.object1_hp -= player.power
                           ranger.old_x = ranger.x
                           effect.effect_switch = True
                       if auto_down_attack_object.object1_hp <= 0:
                           player.score +=2500
                           auto_down_ranger.switch_1 = False
                           auto_down_attack_object.remove(auto_down_attack_object.down_attack_object_1)
                           power_object.switch = True
                           random.shuffle(power_object.random_number)
                           power_object.x = auto_down_attack_object.object_x1
                           power_object.y = auto_down_attack_object.object_y1





               if player.state == player.RIGHT_ATTACK:
                       if player.x + ranger.x  > auto_down_attack_object.object_x1:
                        ranger.x = 0
                        auto_down_attack_object.object1_hp -= player.power
                        ranger.old_x = ranger.x
                        effect.effect_switch = True
                       if auto_down_attack_object.object1_hp <= 0:
                        player.score +=2500
                        auto_down_ranger.switch_1 = False
                        auto_down_attack_object.remove(auto_down_attack_object.down_attack_object_1)
                        power_object.switch = True
                        random.shuffle(power_object.random_number)
                        power_object.x = auto_down_attack_object.object_x1
                        power_object.y = auto_down_attack_object.object_y1


               if player.state == player.UP_ATTACK :
                     if player.y + ranger.y  > auto_down_attack_object.object_y1:
                        ranger.y = 0
                        auto_down_attack_object.object1_hp -= player.power
                        ranger.old_y = ranger.y
                        effect.effect_switch = True
                     if auto_down_attack_object.object1_hp <= 0:
                        player.score +=2500
                        auto_down_ranger.switch_1 = False
                        auto_down_attack_object.remove(auto_down_attack_object.down_attack_object_1)
                        power_object.switch = True
                        random.shuffle(power_object.random_number)
                        power_object.x = auto_down_attack_object.object_x1
                        power_object.y = auto_down_attack_object.object_y1

               if player.state == player.DOWN_ATTACK:
                     if player.y + ranger.y  < auto_down_attack_object.object_y1:
                       ranger.y = 0
                       auto_down_attack_object.object1_hp -= player.power
                       ranger.old_y = ranger.y
                       effect.effect_switch = True
                     if auto_down_attack_object.object1_hp <= 0:
                       player.score +=2500
                       auto_down_ranger.switch_1 = False
                       auto_down_attack_object.remove(auto_down_attack_object.down_attack_object_1)
                       power_object.switch = True
                       random.shuffle(power_object.random_number)
                       power_object.x = auto_down_attack_object.object_x1
                       power_object.y = auto_down_attack_object.object_y1





    #1-2 Player Ranger & DownAttack Obeject_2
    if auto_down_ranger.switch_2 == True :
        if collide3(ranger,auto_down_attack_object,player.x,player.y,auto_down_attack_object.object_x2,auto_down_attack_object.object_y2):
               ranger.old_y = 0
               ranger.old_x = 0

               if player.state == player.LEFT_ATTACK:
                       if player.x + ranger.x  < auto_down_attack_object.object_x2 :
                           ranger.x = 0
                           auto_down_attack_object.object2_hp -= player.power
                           ranger.old_x = ranger.x
                           effect.effect_switch = True
                       if auto_down_attack_object.object2_hp <= 0:
                           player.score +=2500
                           auto_down_ranger.switch_2 = False
                           auto_down_attack_object.remove(auto_down_attack_object.down_attack_object_2)
                           power_object.switch = True
                           random.shuffle(power_object.random_number)
                           power_object.x = auto_down_attack_object.object_x2
                           power_object.y = auto_down_attack_object.object_y2

               if player.state == player.RIGHT_ATTACK:
                       if player.x + ranger.x  > auto_down_attack_object.object_x2:
                        ranger.x = 0
                        auto_down_attack_object.object2_hp -= player.power
                        ranger.old_x = ranger.x
                        effect.effect_switch = True
                       if auto_down_attack_object.object2_hp <= 0:
                        player.score +=2500
                        auto_down_ranger.switch_2 = False
                        auto_down_attack_object.remove(auto_down_attack_object.down_attack_object_2)
                        power_object.switch = True
                        random.shuffle(power_object.random_number)
                        power_object.x = auto_down_attack_object.object_x2
                        power_object.y = auto_down_attack_object.object_y2


               if player.state == player.UP_ATTACK :
                     if player.y + ranger.y  > auto_down_attack_object.object_y2:
                        ranger.y = 0
                        auto_down_attack_object.object2_hp -= player.power
                        ranger.old_y = ranger.y
                        effect.effect_switch = True
                     if auto_down_attack_object.object2_hp <= 0:
                        player.score +=2500
                        auto_down_ranger.switch_2 = False
                        auto_down_attack_object.remove(auto_down_attack_object.down_attack_object_2)
                        power_object.switch = True
                        random.shuffle(power_object.random_number)
                        power_object.x = auto_down_attack_object.object_x2
                        power_object.y = auto_down_attack_object.object_y2



               if player.state == player.DOWN_ATTACK:
                     if player.y + ranger.y  < auto_down_attack_object.object_y2:
                       ranger.y = 0
                       auto_down_attack_object.object2_hp -= player.power
                       ranger.old_y = ranger.y
                       effect.effect_switch = True
                     if auto_down_attack_object.object2_hp <= 0:
                       player.score +=2500
                       auto_down_ranger.switch_2 = False
                       auto_down_attack_object.remove(auto_down_attack_object.down_attack_object_2)
                       power_object.switch = True
                       random.shuffle(power_object.random_number)
                       power_object.x = auto_down_attack_object.object_x2
                       power_object.y = auto_down_attack_object.object_y2




    #1-3 Player Ranger & DownAttack Obeject_3
    if auto_down_ranger.switch_3 == True :
        if collide3(ranger,auto_down_attack_object,player.x,player.y,auto_down_attack_object.object_x3,auto_down_attack_object.object_y3):
               ranger.old_y = 0
               ranger.old_x = 0

               if player.state == player.LEFT_ATTACK:
                       if player.x + ranger.x  < auto_down_attack_object.object_x3:
                           ranger.x = 0
                           auto_down_attack_object.object3_hp -= player.power
                           ranger.old_x = ranger.x
                           effect.effect_switch = True
                       if auto_down_attack_object.object3_hp <= 0:
                           auto_down_ranger.switch_3 = False
                           auto_down_attack_object.remove(auto_down_attack_object.down_attack_object_3)
                           power_object.switch = True
                           random.shuffle(power_object.random_number)
                           power_object.x = auto_down_attack_object.object_x3
                           power_object.y = auto_down_attack_object.object_y3


               if player.state == player.RIGHT_ATTACK:
                       if player.x + ranger.x  > auto_down_attack_object.object_x3:
                        ranger.x = 0
                        auto_down_attack_object.object3_hp -= player.power
                        ranger.old_x = ranger.x
                        effect.effect_switch = True
                       if auto_down_attack_object.object3_hp <= 0:
                        player.score +=2500
                        auto_down_ranger.switch_3 = False
                        auto_down_attack_object.remove(auto_down_attack_object.down_attack_object_3)
                        power_object.switch = True
                        random.shuffle(power_object.random_number)
                        power_object.x = auto_down_attack_object.object_x3
                        power_object.y = auto_down_attack_object.object_y3

               if player.state == player.UP_ATTACK :
                     if player.y + ranger.y  > auto_down_attack_object.object_y3:
                        ranger.y = 0
                        auto_down_attack_object.object3_hp -= player.power
                        ranger.old_y = ranger.y
                        effect.effect_switch = True
                     if auto_down_attack_object.object3_hp <= 0:
                        player.score +=2500
                        auto_down_ranger.switch_3 = False
                        auto_down_attack_object.remove(auto_down_attack_object.down_attack_object_3)
                        power_object.switch = True
                        random.shuffle(power_object.random_number)
                        power_object.x = auto_down_attack_object.object_x3
                        power_object.y = auto_down_attack_object.object_y3

               if player.state == player.DOWN_ATTACK:
                     if player.y + ranger.y  < auto_down_attack_object.object_y3:
                       ranger.y = 0
                       auto_down_attack_object.object3_hp -= player.power
                       ranger.old_y = ranger.y
                       effect.effect_switch = True
                     if auto_down_attack_object.object3_hp <= 0:
                       player.score +=2500
                       auto_down_ranger.switch_3 = False
                       auto_down_attack_object.remove(auto_down_attack_object.down_attack_object_3)
                       power_object.switch = True
                       random.shuffle(power_object.random_number)
                       power_object.x = auto_down_attack_object.object_x3
                       power_object.y = auto_down_attack_object.object_y3


    #1-4 Player Ranger & DownAttack Obeject_4
    if auto_down_ranger.switch_4 == True :
        if collide3(ranger,auto_down_attack_object,player.x,player.y,auto_down_attack_object.object_x4,auto_down_attack_object.object_y4):
               ranger.old_y = 0
               ranger.old_x = 0

               if player.state == player.LEFT_ATTACK:
                       if player.x + ranger.x  < auto_down_attack_object.object_x4:
                           ranger.x = 0
                           auto_down_attack_object.object4_hp -= player.power
                           ranger.old_x = ranger.x
                           effect.effect_switch = True
                       if auto_down_attack_object.object4_hp <= 0:
                           player.score +=2500
                           auto_down_ranger.switch_4 = False
                           auto_down_attack_object.remove(auto_down_attack_object.down_attack_object_4)
                           power_object.switch = True
                           random.shuffle(power_object.random_number)
                           power_object.x = auto_down_attack_object.object_x4
                           power_object.y = auto_down_attack_object.object_y4

               if player.state == player.RIGHT_ATTACK:
                       if player.x + ranger.x  > auto_down_attack_object.object_x4:
                        ranger.x = 0
                        auto_down_attack_object.object4_hp -= player.power
                        ranger.old_x = ranger.x
                        effect.effect_switch = True
                       if auto_down_attack_object.object4_hp <= 0:
                        player.score +=2500
                        auto_down_ranger.switch_4 = False
                        auto_down_attack_object.remove(auto_down_attack_object.down_attack_object_4)
                        power_object.switch = True
                        random.shuffle(power_object.random_number)
                        power_object.x = auto_down_attack_object.object_x4
                        power_object.y = auto_down_attack_object.object_y4

               if player.state == player.UP_ATTACK :
                     if player.y + ranger.y  > auto_down_attack_object.object_y4:
                        ranger.y = 0
                        auto_down_attack_object.object4_hp -= player.power
                        ranger.old_y = ranger.y
                        effect.effect_switch = True
                     if auto_down_attack_object.object4_hp <= 0:
                        player.score +=2500
                        auto_down_ranger.switch_4 = False
                        auto_down_attack_object.remove(auto_down_attack_object.down_attack_object_4)
                        power_object.switch = True
                        random.shuffle(power_object.random_number)
                        power_object.x = auto_down_attack_object.object_x4
                        power_object.y = auto_down_attack_object.object_y4

               if player.state == player.DOWN_ATTACK:
                     if player.y + ranger.y  < auto_down_attack_object.object_y4:
                       ranger.y = 0
                       auto_down_attack_object.object4_hp -= player.power
                       ranger.old_y = ranger.y
                       effect.effect_switch = True
                     if auto_down_attack_object.object4_hp <= 0:
                       player.score +=2500
                       auto_down_ranger.switch_4 = False
                       auto_down_attack_object.remove(auto_down_attack_object.down_attack_object_4)
                       power_object.switch = True
                       random.shuffle(power_object.random_number)
                       power_object.x = auto_down_attack_object.object_x4
                       power_object.y = auto_down_attack_object.object_y4



    #2-1 Player Ranger & LeftAttack Obeject_1
    if auto_left_ranger.switch_1 == True:
        if collide3(ranger,auto_left_attack_object,player.x,player.y,auto_left_attack_object.object_x1,auto_left_attack_object.object_y1):
               ranger.old_y = 0
               ranger.old_x = 0

               if player.state == player.LEFT_ATTACK:
                       if player.x + ranger.x  < auto_left_attack_object.object_x1 :
                           ranger.x = 0
                           auto_left_attack_object.object1_hp -= player.power
                           ranger.old_x = ranger.x
                           effect.effect_switch = True
                       if auto_left_attack_object.object1_hp <= 0:
                           player.score +=2500
                           auto_left_ranger.switch_1 = False
                           auto_left_attack_object.remove(auto_left_attack_object.left_attack_object_1)
                           power_object.switch = True
                           random.shuffle(power_object.random_number)
                           power_object.x = auto_left_attack_object.object_x1
                           power_object.y = auto_left_attack_object.object_y1


               if player.state == player.RIGHT_ATTACK:
                       if player.x + ranger.x  > auto_left_attack_object.object_x1:
                        ranger.x = 0
                        auto_left_attack_object.object1_hp -= player.power
                        ranger.old_x = ranger.x
                        effect.effect_switch = True
                       if auto_left_attack_object.object1_hp <= 0:
                        player.score +=2500
                        auto_left_ranger.switch_1 = False
                        auto_left_attack_object.remove(auto_left_attack_object.left_attack_object_1)
                        power_object.switch = True
                        random.shuffle(power_object.random_number)
                        power_object.x = auto_left_attack_object.object_x1
                        power_object.y = auto_left_attack_object.object_y1


               if player.state == player.UP_ATTACK :
                     if player.y + ranger.y  > auto_left_attack_object.object_y1:
                        ranger.y = 0
                        auto_left_attack_object.object1_hp -= player.power
                        ranger.old_y = ranger.y
                        effect.effect_switch = True
                     if auto_left_attack_object.object1_hp <= 0:
                        player.score +=2500
                        auto_left_ranger.switch_1 = False
                        auto_left_attack_object.remove(auto_left_attack_object.left_attack_object_1)
                        power_object.switch = True
                        random.shuffle(power_object.random_number)
                        power_object.x = auto_left_attack_object.object_x1
                        power_object.y = auto_left_attack_object.object_y1


               if player.state == player.DOWN_ATTACK:
                     if player.y + ranger.y  < auto_left_attack_object.object_y1:
                       ranger.y = 0
                       auto_left_attack_object.object1_hp -= player.power
                       ranger.old_y = ranger.y
                       effect.effect_switch = True
                     if auto_left_attack_object.object1_hp <= 0:
                       player.score +=2500
                       auto_left_attack_object.switch_1 = False
                       auto_left_attack_object.remove(auto_left_attack_object.left_attack_object_1)
                       power_object.switch = True
                       random.shuffle(power_object.random_number)
                       power_object.x = auto_left_attack_object.object_x1
                       power_object.y = auto_left_attack_object.object_y1



    #2-2 Player Ranger & LeftAttack Obeject_2
    if auto_left_ranger.switch_2 == True:
        if collide3(ranger,auto_left_attack_object,player.x,player.y,auto_left_attack_object.object_x2,auto_left_attack_object.object_y2):
               ranger.old_y = 0
               ranger.old_x = 0

               if player.state == player.LEFT_ATTACK:
                       if player.x + ranger.x  < auto_left_attack_object.object_x2 :
                           ranger.x = 0
                           auto_left_attack_object.object2_hp -= player.power
                           ranger.old_x = ranger.x
                           effect.effect_switch = True
                       if auto_left_attack_object.object2_hp <= 0:
                           player.score +=2500
                           auto_left_ranger.switch_2 = False
                           auto_left_attack_object.remove(auto_left_attack_object.left_attack_object_2)
                           power_object.switch = True
                           random.shuffle(power_object.random_number)
                           power_object.x = auto_left_attack_object.object_x2
                           power_object.y = auto_left_attack_object.object_y2

               if player.state == player.RIGHT_ATTACK:
                       if player.x + ranger.x  > auto_left_attack_object.object_x2:
                        ranger.x = 0
                        auto_left_attack_object.object2_hp -= player.power
                        ranger.old_x = ranger.x
                        effect.effect_switch = True
                       if auto_left_attack_object.object2_hp <= 0:
                        player.score +=2500
                        auto_left_ranger.switch_2 = False
                        auto_left_attack_object.remove(auto_left_attack_object.left_attack_object_2)
                        power_object.switch = True
                        random.shuffle(power_object.random_number)
                        power_object.x = auto_left_attack_object.object_x2
                        power_object.y = auto_left_attack_object.object_y2


               if player.state == player.UP_ATTACK :
                     if player.y + ranger.y  > auto_left_attack_object.object_y2:
                        ranger.y = 0
                        auto_left_attack_object.object2_hp -= player.power
                        ranger.old_y = ranger.y
                        effect.effect_switch = True
                     if auto_left_attack_object.object2_hp <= 0:
                        player.score +=2500
                        auto_left_ranger.switch_2 = False
                        auto_left_attack_object.remove(auto_left_attack_object.left_attack_object_2)
                        power_object.switch = True
                        random.shuffle(power_object.random_number)
                        power_object.x = auto_left_attack_object.object_x2
                        power_object.y = auto_left_attack_object.object_y2

               if player.state == player.DOWN_ATTACK:
                     if player.y + ranger.y  < auto_left_attack_object.object_y2:
                       ranger.y = 0
                       auto_left_attack_object.object2_hp -= player.power
                       ranger.old_y = ranger.y
                       effect.effect_switch = True
                     if auto_left_attack_object.object2_hp <= 0:
                       player.score +=2500
                       auto_left_attack_object.switch_2 = False
                       auto_left_attack_object.remove(auto_left_attack_object.left_attack_object_2)
                       power_object.switch = True
                       random.shuffle(power_object.random_number)
                       power_object.x = auto_left_attack_object.object_x2
                       power_object.y = auto_left_attack_object.object_y2


    #3-1 Player Ranger & RihgtAttack Obeject_1
    if auto_right_ranger.switch == True:
        if collide3(ranger,auto_right_attack_object,player.x,player.y,auto_right_attack_object.object_x1,auto_right_attack_object.object_y1):
               ranger.old_y = 0
               ranger.old_x = 0

               if player.state == player.LEFT_ATTACK:
                       if player.x + ranger.x  < auto_right_attack_object.object_x1 :
                           ranger.x = 0
                           auto_right_attack_object.object1_hp -= player.power
                           ranger.old_x = ranger.x
                           effect.effect_switch = True
                       if auto_right_attack_object.object1_hp <= 0:
                           player.score +=2500
                           auto_right_ranger.switch = False
                           auto_right_attack_object.remove(auto_right_attack_object.right_attack_object_1)
                           power_object.switch = True
                           random.shuffle(power_object.random_number)
                           power_object.x = auto_right_attack_object.object_x1
                           power_object.y = auto_right_attack_object.object_y1

               if player.state == player.RIGHT_ATTACK:
                       if player.x + ranger.x  > auto_right_attack_object.object_x1:
                        ranger.x = 0
                        auto_right_attack_object.object1_hp -= player.power
                        ranger.old_x = ranger.x
                        effect.effect_switch = True
                       if auto_right_attack_object.object1_hp <= 0:
                        player.score +=2500
                        auto_right_ranger.switch = False
                        auto_right_attack_object.remove(auto_right_attack_object.right_attack_object_1)
                        power_object.switch = True
                        random.shuffle(power_object.random_number)
                        power_object.x = auto_right_attack_object.object_x1
                        power_object.y = auto_right_attack_object.object_y1


               if player.state == player.UP_ATTACK :
                     if player.y + ranger.y  > auto_right_attack_object.object_y1:
                        ranger.y = 0
                        auto_right_attack_object.object1_hp -= player.power
                        ranger.old_y = ranger.y
                        effect.effect_switch = True
                     if auto_right_attack_object.object1_hp <= 0:
                        player.score +=2500
                        auto_right_ranger.switch = False
                        auto_right_attack_object.remove(auto_right_attack_object.right_attack_object_1)
                        power_object.switch = True
                        random.shuffle(power_object.random_number)
                        power_object.x = auto_right_attack_object.object_x1
                        power_object.y = auto_right_attack_object.object_y1

               if player.state == player.DOWN_ATTACK:
                     if player.y + ranger.y  < auto_right_attack_object.object_y1:
                       ranger.y = 0
                       auto_right_attack_object.object1_hp -= player.power
                       ranger.old_y = ranger.y
                       effect.effect_switch = True
                     if auto_right_attack_object.object1_hp <= 0:
                       player.score +=2500
                       auto_right_attack_object.switch = False
                       auto_right_attack_object.remove(auto_right_attack_object.right_attack_object_1)
                       power_object.switch = True
                       random.shuffle(power_object.random_number)
                       power_object.x = auto_right_attack_object.object_x1
                       power_object.y = auto_right_attack_object.object_y1



    #3-2 Player Ranger & RihgtAttack Obeject_2
    if auto_right_ranger.switch_2 == True :
        if collide3(ranger,auto_right_attack_object,player.x,player.y,auto_right_attack_object.object_x2,auto_right_attack_object.object_y2):
               ranger.old_y = 0
               ranger.old_x = 0

               if player.state == player.RIGHT_ATTACK:
                       if player.x + ranger.x  > auto_right_attack_object.object_x2:
                        ranger.x = 0
                        auto_right_attack_object.object2_hp -= player.power
                        ranger.old_x = ranger.x
                        effect.effect_switch = True
                       if auto_right_attack_object.object2_hp <= 0:
                        player.score +=2500
                        auto_right_ranger.switch_2 = False
                        auto_right_attack_object.remove(auto_right_attack_object.right_attack_object_2)
                        power_object.switch = True
                        random.shuffle(power_object.random_number)
                        power_object.x = auto_right_attack_object.object_x2
                        power_object.y = auto_right_attack_object.object_y2
  #.........................................................................#








#..........................................................................#
                  # AI -> Player Attack  #


    for in_tile in in_tiles:
          #.......AI_1 Attack.......#
         if collide2(ai_ranger_1,player,ai_1.x,ai_1.y):
             if ai_1.state == ai_1.LEFT_MOVE:
                if ai_1.switch == True:
                   if ai_1.x + ai_ranger_1.x  < player.x:
                      player.hp -=  ai_1.power
                      effect.effect_ai1_switch = True
                      ai_ranger_1.x = 0
                      if player.live != 0 and player.hp <=0:
                         player.live -=1
                         player.hp = 100

             if ai_1.state == ai_1.RIGHT_MOVE:
                  if ai_1.switch == True:
                     if ai_1.x + ai_ranger_1.x  > in_tile.x:
                        player.hp -= ai_1.power
                        effect.effect_ai1_switch = True
                        ai_ranger_1.x = 0
                        if player.live != 0 and player.hp <=0:
                         player.live -=1
                         player.hp = 100

             if ai_1.state == ai_1.UP_MOVE:
                  if ai_1.switch == True:
                    if ai_1.y + ai_ranger_1.y + 25 > in_tile.y: # yPos +25 보정값
                        player.hp -= ai_1.power
                        effect.effect_ai1_switch = True
                        ai_ranger_1.y = 0
                        if player.live != 0 and player.hp <=0:
                         player.live -=1
                         player.hp = 100

             if ai_1.state == ai_1.DOWN_MOVE:
                  if ai_1.switch == True:
                    if ai_1.y + ai_ranger_1.y < in_tile.y:
                        player.hp -= ai_1.power
                        effect.effect_ai1_switch = True
                        ai_ranger_1.y = 0
                        if player.live != 0 and player.hp <=0:
                         player.live -=1
                         player.hp = 100



         #.......AI_2 Attack.......#
         if collide2(ai_ranger_2,player,ai_2.x,ai_2.y):
             if ai_2.state == ai_2.LEFT_MOVE:
                if ai_2.switch == True:
                   if ai_2.x + ai_ranger_2.x  < player.x:
                      player.hp -=  ai_2.power
                      effect.effect_ai2_switch = True
                      ai_ranger_2.x = 0
                      if player.live != 0 and player.hp <=0:
                        player.live -=1
                        player.hp = 100

             if ai_2.state == ai_2.RIGHT_MOVE:
                  if ai_2.switch == True:
                     if ai_2.x + ai_ranger_2.x  > in_tile.x:
                        player.hp -= ai_2.power
                        effect.effect_ai2_switch = True
                        ai_ranger_2.x = 0
                        if player.live != 0 and player.hp <=0:
                         player.live -=1
                         player.hp = 100


             if ai_2.state == ai_2.UP_MOVE:
                  if ai_2.switch == True:
                    if ai_2.y + ai_ranger_2.y + 25 > in_tile.y: # yPos +25 보정값
                        player.hp -= ai_2.power
                        effect.effect_ai2_switch = True
                        ai_ranger_2.y = 0
                        if player.live != 0 and player.hp <=0:
                         player.live -=1
                         player.hp = 100


             if ai_2.state == ai_2.DOWN_MOVE:
                  if ai_2.switch == True:
                    if ai_2.y + ai_ranger_2.y < in_tile.y:
                        player.hp -= ai_2.power
                        effect.effect_ai2_switch = True
                        ai_ranger_2.y = 0
                        if player.live != 0 and player.hp <=0:
                         player.live -=1
                         player.hp = 100


          #.......AI_3 Attack.......#
         if collide2(ai_ranger_3,player,ai_3.x,ai_3.y):
             if ai_3.state == ai_3.LEFT_MOVE:
                if ai_3.switch == True:
                   if ai_3.x + ai_ranger_3.x  < player.x:
                      player.hp -=  ai_3.power
                      effect.effect_ai3_switch = True
                      ai_ranger_3.x = 0
                      if player.live != 0 and player.hp <=0:
                       player.live -=1
                       player.hp = 100

             if ai_3.state == ai_3.RIGHT_MOVE:
                  if ai_3.switch == True:
                     if ai_3.x + ai_ranger_3.x  > in_tile.x:
                        player.hp -= ai_3.power
                        effect.effect_ai3_switch = True
                        ai_ranger_3.x = 0
                        if player.live != 0 and player.hp <=0:
                           player.live -=1
                           player.hp = 100

             if ai_3.state == ai_3.UP_MOVE:
                  if ai_3.switch == True:
                    if ai_3.y + ai_ranger_3.y + 25 > in_tile.y: # yPos +25 보정값
                        player.hp -= ai_3.power
                        effect.effect_ai3_switch = True
                        ai_ranger_3.y = 0
                        if player.live != 0 and player.hp <=0:
                           player.live -=1
                           player.hp = 100

             if ai_3.state == ai_3.DOWN_MOVE:
                  if ai_3.switch == True:
                    if ai_3.y + ai_ranger_3.y < in_tile.y:
                        player.hp -= ai_3.power
                        effect.effect_ai3_switch = True
                        ai_ranger_3.y = 0
                        if player.live != 0 and player.hp <=0:
                           player.live -=1
                           player.hp = 100


         #.......AI_4 Attack.......#
         if collide2(ai_ranger_4,player,ai_4.x,ai_4.y):
             if ai_4.state == ai_4.LEFT_MOVE:
                if ai_4.switch == True:
                   if ai_4.x + ai_ranger_4.x  < player.x:
                      player.hp -=  ai_4.power
                      effect.effect_ai4_switch = True
                      ai_ranger_4.x = 0
                      if player.live != 0 and player.hp <=0:
                           player.live -=1
                           player.hp = 100

             if ai_4.state == ai_4.RIGHT_MOVE:
                  if ai_4.switch == True:
                     if ai_4.x + ai_ranger_4.x  > in_tile.x:
                        player.hp -= ai_4.power
                        effect.effect_ai4_switch = True
                        ai_ranger_4.x = 0
                        if player.live != 0 and player.hp <=0:
                           player.live -=1
                           player.hp = 100

             if ai_4.state == ai_4.UP_MOVE:
                  if ai_4.switch == True:
                    if ai_4.y + ai_ranger_4.y + 25 > in_tile.y: # yPos +25 보정값
                        player.hp -= ai_4.power
                        effect.effect_ai4_switch = True
                        ai_ranger_4.y = 0
                        if player.live != 0 and player.hp <=0:
                           player.live -=1
                           player.hp = 100



             if ai_4.state == ai_4.DOWN_MOVE:
                  if ai_4.switch == True:
                    if ai_4.y + ai_ranger_4.y < in_tile.y:
                        player.hp -= ai_4.power
                        effect.effect_ai4_switch = True
                        ai_ranger_4.y = 0
                        if player.live != 0 and player.hp <=0:
                            player.live -=1
                            player.hp = 100

#.........................................................................#





#.........................................................................#
                       # AutoAttack & Intile Collide #

    for in_tile in in_tiles:
          #,,,Down Attack,,,#
          if collide2(auto_down_ranger,in_tile,auto_down_attack_object.object_x1,auto_down_attack_object.object_y1):
             auto_down_ranger.old_y1 = 0

             if auto_down_attack_object.state == auto_down_attack_object.DOWN_ATTACK:
                  if auto_down_attack_object.object_y1 + auto_down_ranger.y1 < in_tile.y:
                      auto_down_ranger.shot_sound.play()
                      auto_down_ranger.old_y1 = auto_down_ranger.y1
                      effect_2.effect_auto_down_switch_1 = True
                      auto_down_ranger.y1 = 0

          if collide2(auto_down_ranger,in_tile,auto_down_attack_object.object_x2,auto_down_attack_object.object_y2):
             auto_down_ranger.old_y2 = 0

             if auto_down_attack_object.state == auto_down_attack_object.DOWN_ATTACK:
                  if auto_down_attack_object.object_y2 + auto_down_ranger.y2 < in_tile.y:
                      auto_down_ranger.shot_sound.play()
                      auto_down_ranger.old_y2 = auto_down_ranger.y2
                      effect_2.effect_auto_down_switch_2 = True
                      auto_down_ranger.y2 = 0

          if collide2(auto_down_ranger,in_tile,auto_down_attack_object.object_x3,auto_down_attack_object.object_y3):
             auto_down_ranger.old_y3 = 0

             if auto_down_attack_object.state == auto_down_attack_object.DOWN_ATTACK:
                  if auto_down_attack_object.object_y3 + auto_down_ranger.y3 < in_tile.y:
                      auto_down_ranger.shot_sound.play()
                      auto_down_ranger.old_y3 = auto_down_ranger.y3
                      effect_2.effect_auto_down_switch_3 = True
                      auto_down_ranger.y3 = 0

          if collide2(auto_down_ranger,in_tile,auto_down_attack_object.object_x4,auto_down_attack_object.object_y4):
             auto_down_ranger.old_y4 = 0

             if auto_down_attack_object.state == auto_down_attack_object.DOWN_ATTACK:
                  if auto_down_attack_object.object_y4 + auto_down_ranger.y4 < in_tile.y:
                      auto_down_ranger.shot_sound.play()
                      auto_down_ranger.old_y4 = auto_down_ranger.y4
                      effect_2.effect_auto_down_switch_4 = True
                      auto_down_ranger.y4 = 0

          #,,,Left Attack,,,#
          if collide2(auto_left_ranger,in_tile,auto_left_attack_object.object_x1,auto_left_attack_object.object_y1):
             auto_left_ranger.old_x1 = 0

             if auto_left_attack_object.state == auto_left_attack_object.LEFT_ATTACK:
                  if auto_left_attack_object.object_x1 + auto_left_ranger.x1 < in_tile.x:
                      auto_left_ranger.boom_sound.play()
                      auto_left_ranger.old_x1 = auto_left_ranger.x1
                      effect_2.effect_auto_left_switch_1 = True
                      auto_left_ranger.x1 = 0

          if collide2(auto_left_ranger,in_tile,auto_left_attack_object.object_x2,auto_left_attack_object.object_y2):
             auto_left_ranger.old_x2 = 0

             if auto_left_attack_object.state == auto_left_attack_object.LEFT_ATTACK:
                  if auto_left_attack_object.object_x2 + auto_left_ranger.x2 < in_tile.x:
                      auto_left_ranger.boom_sound.play()
                      auto_left_ranger.old_x2 = auto_left_ranger.x2
                      effect_2.effect_auto_left_switch_2 = True
                      auto_left_ranger.x2 = 0


          #,,,Right Attack,,,#
          if collide2(auto_right_ranger,in_tile,auto_right_attack_object.object_x1,auto_right_attack_object.object_y1):
             auto_right_ranger.old_x1 = 0

             if auto_right_attack_object.state == auto_right_attack_object.RIGHT_ATTACK:
                  if auto_right_attack_object.object_x1 + auto_right_ranger.x1 > in_tile.x:
                      auto_left_ranger.boom_sound.play()
                      auto_right_ranger.old_x1 = auto_right_ranger.x1
                      effect_2.effect_auto_right_switch = True
                      auto_right_ranger.x1 = 0

          if collide2(auto_right_ranger,in_tile,auto_right_attack_object.object_x2,auto_right_attack_object.object_y2):
             auto_right_ranger.old_x2 = 0

             if auto_right_attack_object.state == auto_right_attack_object.RIGHT_ATTACK:
                  if auto_right_attack_object.object_x2 + auto_right_ranger.x2 > in_tile.x:
                      auto_left_ranger.boom_sound.play()
                      auto_right_ranger.old_x2 = auto_right_ranger.x2
                      effect_2.effect_auto_right_switch_2 = True
                      auto_right_ranger.x2 = 0
 #.........................................................................#


#.........................................................................#
                        # AutoAttack & Player Collide #


    #,,,Down Attack,,,#
    if auto_down_ranger.switch_1 == True:
          if collide2(auto_down_ranger,player,auto_down_attack_object.object_x1,auto_down_attack_object.object_y1):
             auto_down_ranger.old_y1 = 0

             if auto_down_attack_object.state == auto_down_attack_object.DOWN_ATTACK:
                  if auto_down_attack_object.object_y1 + auto_down_ranger.y1 < player.y:
                      auto_down_ranger.old_y1 = auto_down_ranger.y1
                      player.hp -= 5
                      effect_2.effect_auto_down_switch_1 = True
                      auto_down_ranger.shot_sound.play()
                      auto_down_ranger.y1 = 0
                      if player.live != 0 and player.hp <=0:
                       player.live -=1
                       player.hp = 100


    if auto_down_ranger.switch_2 == True:
          if collide2(auto_down_ranger,player,auto_down_attack_object.object_x2,auto_down_attack_object.object_y2):
             auto_down_ranger.old_y2 = 0

             if auto_down_attack_object.state == auto_down_attack_object.DOWN_ATTACK:
                  if auto_down_attack_object.object_y2 + auto_down_ranger.y2 < player.y:
                      auto_down_ranger.old_y2 = auto_down_ranger.y2
                      player.hp -= 5
                      effect_2.effect_auto_down_switch_2 = True
                      auto_down_ranger.shot_sound.play()
                      auto_down_ranger.y2 = 0
                      if player.live != 0 and player.hp <=0:
                         player.live -=1
                         player.hp = 100


    if auto_down_ranger.switch_3 == True:
          if collide2(auto_down_ranger,player,auto_down_attack_object.object_x3,auto_down_attack_object.object_y3):
             auto_down_ranger.old_y3 = 0

             if auto_down_attack_object.state == auto_down_attack_object.DOWN_ATTACK:
                  if auto_down_attack_object.object_y3 + auto_down_ranger.y3 < player.y:
                      auto_down_ranger.old_y3 = auto_down_ranger.y3
                      player.hp -= 5
                      effect_2.effect_auto_down_switch_3 = True
                      auto_down_ranger.shot_sound.play()
                      auto_down_ranger.y3 = 0
                      if player.live != 0 and player.hp <=0:
                         player.live -=1
                         player.hp = 100

    if auto_down_ranger.switch_4 == True:
          if collide2(auto_down_ranger,player,auto_down_attack_object.object_x4,auto_down_attack_object.object_y4):
             auto_down_ranger.old_y4 = 0

             if auto_down_attack_object.state == auto_down_attack_object.DOWN_ATTACK:
                  if auto_down_attack_object.object_y4 + auto_down_ranger.y4 < player.y:
                      auto_down_ranger.old_y4 = auto_down_ranger.y4
                      player.hp -= 5
                      effect_2.effect_auto_down_switch_4 = True
                      auto_down_ranger.shot_sound.play()
                      auto_down_ranger.y4 = 0
                      if player.live != 0 and player.hp <=0:
                         player.live -=1
                         player.hp = 100

    #,,,Left Attack,,,#
    if auto_left_ranger.switch_1 == True:
          if collide2(auto_left_ranger,player,auto_left_attack_object.object_x1,auto_left_attack_object.object_y1):
             auto_left_ranger.old_x1 = 0

             if auto_left_attack_object.state == auto_left_attack_object.LEFT_ATTACK:
                  if auto_left_attack_object.object_x1 + auto_left_ranger.x1 < player.x:
                      auto_left_ranger.old_x1 = auto_left_ranger.x1
                      player.hp -= 5
                      effect_2.effect_auto_left_switch_1 = True
                      auto_left_ranger.boom_sound.play()
                      auto_left_ranger.x1 = 0
                      if player.live != 0 and player.hp <=0:
                         player.live -=1
                         player.hp = 100

    if auto_left_ranger.switch_2 == True:
          if collide2(auto_left_ranger,player,auto_left_attack_object.object_x2,auto_left_attack_object.object_y2):
             auto_left_ranger.old_x2 = 0

             if auto_left_attack_object.state == auto_left_attack_object.LEFT_ATTACK:
                  if auto_left_attack_object.object_x2 + auto_left_ranger.x2 < player.x:
                      auto_left_ranger.old_x2 = auto_left_ranger.x2
                      player.hp -= 5
                      effect_2.effect_auto_left_switch_2 = True
                      auto_left_ranger.boom_sound.play()
                      auto_left_ranger.x2 = 0
                      if player.live != 0 and player.hp <=0:
                         player.live -=1
                         player.hp = 100



    #,,,Right Attack,,,#
    if auto_right_ranger.switch == True:
          if collide2(auto_right_ranger,player,auto_right_attack_object.object_x1,auto_right_attack_object.object_y1):
             auto_right_ranger.old_x1 = 0

             if auto_right_attack_object.state == auto_right_attack_object.RIGHT_ATTACK:
                  if auto_right_attack_object.object_x1 + auto_right_ranger.x1 > player.x:
                      auto_right_ranger.old_x1 = auto_right_ranger.x1
                      player.hp -= 5
                      effect_2.effect_auto_right_switch = True
                      auto_left_ranger.boom_sound.play()
                      auto_right_ranger.x1 = 0
                      if player.live != 0 and player.hp <=0:
                         player.live -=1
                         player.hp = 100

    if auto_right_ranger.switch_2 == True:
          if collide2(auto_right_ranger,player,auto_right_attack_object.object_x2,auto_right_attack_object.object_y2):
             auto_right_ranger.old_x2 = 0

             if auto_right_attack_object.state == auto_right_attack_object.RIGHT_ATTACK:
                  if auto_right_attack_object.object_x2 + auto_right_ranger.x2 > player.x:
                      auto_right_ranger.old_x2 = auto_right_ranger.x2
                      player.hp -= 5
                      effect_2.effect_auto_right_switch_2 = True
                      auto_left_ranger.boom_sound.play()
                      auto_right_ranger.x2 = 0
                      if player.live != 0 and player.hp <=0:
                         player.live -=1
                         player.hp = 100
 #.........................................................................#









#..........................................................................#
                  # AI Out_Tile_Attack_Collide  #

    # Out_tile 관련 Collide
    for out_tile in out_tiles:

        #.......AI_1 Attack.......#
       if collide2(ai_ranger_1,out_tile,ai_1.x,ai_1.y):
           ai_ranger_1.old_x = 0
           ai_ranger_1.old_y = 0

           if ai_1.state == ai_1.LEFT_MOVE:
               if ai_1.x + ai_ranger_1.x - 50 < out_tile.x:
                   ai_ranger_1.old_x = ai_ranger_1.x
                   effect.effect_ai1_switch = True
                   ai_ranger_1.x = 0

           if ai_1.state == ai_1.RIGHT_MOVE:
               if ai_1.x + ai_ranger_1.x + 50 > out_tile.x:
                   ai_ranger_1.old_x = ai_ranger_1.x
                   effect.effect_ai1_switch = True
                   ai_ranger_1.x = 0

           if ai_1.state == ai_1.UP_MOVE :
               if ai_1.y + ai_ranger_1.y + 50  > out_tile.y:
                   ai_ranger_1.old_y = ai_ranger_1.y
                   effect.effect_ai1_switch = True
                   ai_ranger_1.y = 0

           if ai_1.state == ai_1.DOWN_MOVE:
               if ai_1.y + ai_ranger_1.y - 50  < out_tile.y:
                   ai_ranger_1.old_y = ai_ranger_1.y
                   effect.effect_ai1_switch = True
                   ai_ranger_1.y = 0


       #.......AI_1 Move.......#
       if collide(ai_1,out_tile):
              if (ai_1.state == ai_1.RIGHT_MOVE):
                  if ai_1.x < out_tile.x:
                      ai_1.x-=5
                      ai_1.state=random.randint(1,4)
              elif (ai_1.state == ai_1.UP_MOVE):
                  if ai_1.y < out_tile.y:
                      ai_1.y-=5
                      ai_1.state=random.randint(1,4)
                  while 1:
                    if(ai_1.state == ai_1.UP_MOVE):
                        ai_1.state=random.randint(1,4)
                    else:
                        break;
              elif (ai_1.state == ai_1.LEFT_MOVE):
                  if ai_1.x > out_tile.x:
                      ai_1.x+=5
                      ai_1.state=random.randint(1,4)
                  while 1:
                     if(ai_1.state == ai_2.LEFT_MOVE):
                         ai_1.state=random.randint(1,4)
                     else:
                        break;
              elif (ai_1.state == ai_1.DOWN_MOVE):
                   if ai_1.y > out_tile.y:
                       ai_1.y+=5
                       ai_1.state=random.randint(1,4)




       #.......AI_2 Attack.......#
       if collide2(ai_ranger_2,out_tile,ai_2.x,ai_2.y):
           ai_ranger_2.old_x = 0
           ai_ranger_2.old_y = 0

           if ai_2.state == ai_2.LEFT_MOVE:
               if ai_2.x + ai_ranger_2.x - 50 < out_tile.x:
                   ai_ranger_2.old_x = ai_ranger_2.x
                   effect.effect_ai2_switch = True
                   ai_ranger_2.x = 0

           if ai_2.state == ai_2.RIGHT_MOVE:
               if ai_2.x + ai_ranger_2.x + 50  > out_tile.x:
                   ai_ranger_2.old_x = ai_ranger_2.x
                   effect.effect_ai2_switch = True
                   ai_ranger_2.x = 0

           if ai_2.state == ai_2.UP_MOVE :
               if ai_2.y + ai_ranger_2.y + 50  > out_tile.y: # yPos +25 보정값
                   ai_ranger_2.old_y = ai_ranger_2.y
                   effect.effect_ai2_switch = True
                   ai_ranger_2.y = 0

           if ai_2.state == ai_2.DOWN_MOVE:
               if ai_2.y + ai_ranger_2.y - 50 < out_tile.y:
                   ai_ranger_2.old_y = ai_ranger_2.y
                   effect.effect_ai2_switch = True
                   ai_ranger_2.y = 0

       #.......AI_2 Move.......#
       if collide(ai_2,out_tile):
              if (ai_2.state == ai_2.RIGHT_MOVE):
                  if ai_2.x < out_tile.x:
                      ai_2.x-=5
                      ai_2.state=random.randint(1,4)
              elif (ai_2.state == ai_2.UP_MOVE):
                  if ai_2.y < out_tile.y:
                      ai_2.y-=5
                      ai_2.state=random.randint(1,4)
                  while 1:
                    if(ai_2.state == ai_2.UP_MOVE):
                        ai_2.state=random.randint(1,4)
                    else:
                        break;
              elif (ai_2.state == ai_2.LEFT_MOVE):
                  if ai_2.x > out_tile.x:
                      ai_2.x+=5
                      ai_2.state=random.randint(1,4)
                  while 1:
                     if(ai_2.state == ai_2.LEFT_MOVE):
                         ai_2.state=random.randint(1,4)
                     else:
                        break;
              elif (ai_2.state == ai_2.DOWN_MOVE):
                   if ai_2.y > out_tile.y:
                       ai_2.y+=5
                       ai_2.state=random.randint(1,4)





        #.......AI_3 Attack.......#
       if collide2(ai_ranger_3,out_tile,ai_3.x,ai_3.y):
           ai_ranger_3.old_x = 0
           ai_ranger_3.old_y = 0

           if ai_3.state == ai_3.LEFT_MOVE:
               if ai_3.x + ai_ranger_3.x - 50 < out_tile.x:
                   ai_ranger_3.old_x = ai_ranger_3.x
                   effect.effect_ai3_switch = True
                   ai_ranger_3.x = 0

           if ai_3.state == ai_3.RIGHT_MOVE:
               if ai_3.x + ai_ranger_3.x + 50  > out_tile.x:
                   ai_ranger_3.old_x = ai_ranger_3.x
                   effect.effect_ai3_switch = True
                   ai_ranger_3.x = 0

           if ai_3.state == ai_3.UP_MOVE :
               if ai_3.y + ai_ranger_3.y + 50  >  out_tile.y: # yPos +25 보정값
                   ai_ranger_3.old_x = ai_ranger_3.x
                   effect.effect_ai3_switch = True
                   ai_ranger_3.y = 0

           if ai_3.state == ai_3.DOWN_MOVE:
               if ai_3.y + ai_ranger_3.y - 50 <  out_tile.y:
                   ai_ranger_3.old_x = ai_ranger_3.x
                   effect.effect_ai3_switch = True
                   ai_ranger_3.y = 0

       #.......AI_3 Move.......#
       if collide(ai_3,out_tile):
              if (ai_3.state == ai_3.RIGHT_MOVE):
                  if ai_3.x < out_tile.x:
                      ai_3.x-=5
                      ai_3.state=random.randint(1,4)
              elif (ai_3.state == ai_3.UP_MOVE):
                  if ai_3.y < out_tile.y:
                      ai_3.y-=5
                      ai_3.state=random.randint(1,4)
                  while 1:
                    if(ai_3.state == ai_3.UP_MOVE):
                        ai_3.state=random.randint(1,4)
                    else:
                        break;
              elif (ai_3.state == ai_3.LEFT_MOVE):
                  if ai_3.x > out_tile.x:
                      ai_3.x+=5
                      ai_3.state=random.randint(1,4)
                  while 1:
                     if(ai_3.state == ai_3.LEFT_MOVE):
                         ai_3.state=random.randint(1,4)
                     else:
                        break;
              elif (ai_3.state == ai_3.DOWN_MOVE):
                   if ai_3.y > out_tile.y:
                       ai_3.y+=5
                       ai_3.state=random.randint(1,4)


         #.......AI_4 Attack.......#
       if collide2(ai_ranger_4,out_tile,ai_4.x,ai_4.y):
           ai_ranger_4.old_x = 0
           ai_ranger_4.old_y = 0

           if ai_4.state == ai_4.LEFT_MOVE:
               if ai_4.x + ai_ranger_4.x - 25 < out_tile.x:
                   ai_ranger_4.old_x = ai_ranger_4.x
                   effect.effect_ai4_switch = True
                   ai_ranger_4.x = 0

           if ai_4.state == ai_4.RIGHT_MOVE:
               if ai_4.x + ai_ranger_4.x  > out_tile.x:
                   ai_ranger_4.old_x = ai_ranger_4.x
                   effect.effect_ai4_switch = True
                   ai_ranger_4.x = 0

           if ai_4.state == ai_4.UP_MOVE :
               if ai_4.y + ai_ranger_4.y  > out_tile.y: # yPos +25 보정값
                   ai_ranger_4.old_x = ai_ranger_4.x
                   effect.effect_ai4_switch = True
                   ai_ranger_4.y = 0

           if ai_4.state == ai_4.DOWN_MOVE:
               if ai_4.y + ai_ranger_4.y + 25 < out_tile.y:
                   ai_ranger_4.old_x = ai_ranger_4.x
                   effect.effect_ai4_switch = True
                   ai_ranger_4.y = 0


       #.......AI_4 Move.......#
       if collide(ai_4,out_tile):
              if (ai_4.state == ai_4.RIGHT_MOVE):
                  if ai_4.x < out_tile.x:
                      ai_4.x-=5
                      ai_4.state=random.randint(1,4)
              elif (ai_4.state == ai_4.UP_MOVE):
                  if ai_4.y < out_tile.y:
                      ai_4.y-=5
                      ai_4.state=random.randint(1,4)
                  while 1:
                    if(ai_4.state == ai_4.UP_MOVE):
                        ai_4.state=random.randint(1,4)
                    else:
                        break;
              elif (ai_4.state == ai_4.LEFT_MOVE):
                  if ai_4.x > out_tile.x:
                      ai_4.x+=5
                      ai_4.state=random.randint(1,4)
                  while 1:
                     if(ai_4.state == ai_3.LEFT_MOVE):
                         ai_4.state=random.randint(1,4)
                     else:
                        break;
              elif (ai_4.state == ai_4.DOWN_MOVE):
                   if ai_4.y > out_tile.y:
                       ai_4.y+=5
                       ai_4.state=random.randint(1,4)

#..........................................................................#


#..........................................................................#
                  # AI In_Tile_Move & Attack_Collide  #


    for in_tile in in_tiles:
          #.......AI_1 Move.......#
          if collide(ai_1,in_tile):
              if (ai_1.state == ai_1.RIGHT_MOVE):
                  if ai_1.x < in_tile.x:
                      ai_1.x-=5
                      ai_1.state=random.randint(1,4)
              elif (ai_1.state == ai_1.UP_MOVE):
                  if ai_1.y < in_tile.y:
                      ai_1.y-=5
                      ai_1.state=random.randint(1,4)
                  while 1:
                    if(ai_1.state == ai_1.UP_MOVE):
                        ai_1.state=random.randint(1,4)
                    else:
                        break;
              elif (ai_1.state == ai_1.LEFT_MOVE):
                  if ai_1.x > in_tile.x:
                      ai_1.x+=5
                      ai_1.state=random.randint(1,4)
                  while 1:
                     if(ai_1.state == ai_1.LEFT_MOVE):
                         ai_1.state=random.randint(1,4)
                     else:
                        break;
              elif (ai_1.state == ai_1.DOWN_MOVE):
                   if ai_1.y > in_tile.y:
                       ai_1.y+=5
                       ai_1.state=random.randint(1,4)

          #.......AI_1 Attack.......#
          if collide2(ai_ranger_1,in_tile,ai_1.x,ai_1.y):
              ai_ranger_1.old_x = 0
              ai_ranger_1.old_y = 0
              if ai_1.state == ai_1.LEFT_MOVE:
                  if ai_1.x + ai_ranger_1.x  < in_tile.x:
                      ai_ranger_1.old_x = ai_ranger_1.x
                      effect.effect_ai1_switch = True
                      ai_ranger_1.x = 0

              if ai_1.state == ai_1.RIGHT_MOVE:
                  if ai_1.x + ai_ranger_1.x  > in_tile.x:
                      ai_ranger_1.old_x = ai_ranger_1.x
                      effect.effect_ai1_switch = True
                      ai_ranger_1.x = 0

              if ai_1.state == ai_1.UP_MOVE:
                  if ai_1.y + ai_ranger_1.y + 25 > in_tile.y: # yPos +25 보정값
                      ai_ranger_1.old_y = ai_ranger_1.y
                      effect.effect_ai1_switch = True
                      ai_ranger_1.y = 0

              if ai_1.state == ai_1.DOWN_MOVE:
                  if ai_1.y + ai_ranger_1.y < in_tile.y:
                      ai_ranger_1.old_y = ai_ranger_1.y
                      effect.effect_ai1_switch = True
                      ai_ranger_1.y = 0



          #.......AI_2 Move.......#
          if collide(ai_2,in_tile):
              if (ai_2.state == ai_2.RIGHT_MOVE):
                  if ai_2.x < in_tile.x:
                      ai_2.x-=5
                      ai_2.state=random.randint(1,4)
              elif (ai_2.state == ai_2.UP_MOVE):
                  if ai_2.y < in_tile.y:
                      ai_2.y-=5
                      ai_2.state=random.randint(1,4)
                  while 1:
                    if(ai_2.state == ai_2.UP_MOVE):
                        ai_2.state=random.randint(1,4)
                    else:
                        break;
              elif (ai_2.state == ai_2.LEFT_MOVE):
                  if ai_2.x > in_tile.x:
                      ai_2.x+=5
                      ai_2.state=random.randint(1,4)
                  while 1:
                     if(ai_2.state == ai_2.LEFT_MOVE):
                         ai_2.state=random.randint(1,4)
                     else:
                        break;
              elif (ai_2.state == ai_2.DOWN_MOVE):
                   if ai_2.y > in_tile.y:
                       ai_2.y+=5
                       ai_2.state=random.randint(1,4)

          #.......AI_2 Attack.......#
          if collide2(ai_ranger_2,in_tile,ai_2.x,ai_2.y):
              ai_ranger_2.old_x = 0
              ai_ranger_2.old_y = 0

              if ai_2.state == ai_2.LEFT_MOVE:
                  if ai_2.x + ai_ranger_2.x  < in_tile.x:
                      ai_ranger_2.old_x = ai_ranger_2.x
                      effect.effect_ai2_switch = True
                      ai_ranger_2.x = 0

              if ai_2.state == ai_2.RIGHT_MOVE:
                  if ai_2.x + ai_ranger_2.x  > in_tile.x:
                      ai_ranger_2.old_x = ai_ranger_2.x
                      effect.effect_ai2_switch = True
                      ai_ranger_2.x = 0

              if ai_2.state == ai_2.UP_MOVE:
                  if ai_2.y + ai_ranger_2.y + 25 > in_tile.y: # yPos +25 보정값
                      ai_ranger_2.old_y = ai_ranger_2.y
                      effect.effect_ai2_switch = True
                      ai_ranger_2.y = 0

              if ai_2.state == ai_2.DOWN_MOVE:
                  if ai_2.y + ai_ranger_2.y < in_tile.y:
                      ai_ranger_2.old_y = ai_ranger_2.y
                      effect.effect_ai2_switch = True
                      ai_ranger_2.y = 0




           #.......AI_3 Move.......#
          if collide(ai_3,in_tile):
              if (ai_3.state == ai_3.RIGHT_MOVE):
                  if ai_3.x < in_tile.x:
                      ai_3.x-=5
                      ai_3.state=random.randint(1,4)
              elif (ai_3.state == ai_3.UP_MOVE):
                  if ai_3.y < in_tile.y:
                      ai_3.y-=5
                      ai_3.state=random.randint(1,4)
                  while 1:
                    if(ai_3.state == ai_3.UP_MOVE):
                        ai_3.state=random.randint(1,4)
                    else:
                        break;
              elif (ai_3.state == ai_3.LEFT_MOVE):
                  if ai_3.x > in_tile.x:
                      ai_3.x+=5
                      ai_3.state=random.randint(1,4)
                  while 1:
                     if(ai_3.state == ai_3.LEFT_MOVE):
                         ai_3.state=random.randint(1,4)
                     else:
                        break;
              elif (ai_3.state == ai_3.DOWN_MOVE):
                   if ai_3.y > in_tile.y:
                       ai_3.y+=5
                       ai_3.state=random.randint(1,4)

          #.......AI_3 Attack.......#
          if collide2(ai_ranger_3,in_tile,ai_3.x,ai_3.y):
              ai_ranger_3.old_x = 0
              ai_ranger_3.old_y = 0

              if ai_3.state == ai_3.LEFT_MOVE:
                  if ai_3.x + ai_ranger_3.x  < in_tile.x:
                      ai_ranger_3.old_x = ai_ranger_3.x
                      effect.effect_ai3_switch = True
                      ai_ranger_3.x = 0

              if ai_3.state == ai_3.RIGHT_MOVE:
                  if ai_3.x + ai_ranger_3.x  > in_tile.x:
                      ai_ranger_3.old_x = ai_ranger_3.x
                      effect.effect_ai3_switch = True
                      ai_ranger_3.x = 0

              if ai_3.state == ai_3.UP_MOVE:
                  if ai_3.y + ai_ranger_3.y + 25 > in_tile.y: # yPos +25 보정값
                      ai_ranger_3.old_y = ai_ranger_3.y
                      effect.effect_ai3_switch = True
                      ai_ranger_3.y = 0

              if ai_3.state == ai_3.DOWN_MOVE:
                  if ai_3.y + ai_ranger_3.y < in_tile.y:
                      ai_ranger_3.old_y = ai_ranger_3.y
                      effect.effect_ai3_switch = True
                      ai_ranger_3.y = 0


          #.......AI_4 Move.......#
          if collide(ai_4,in_tile):
              if (ai_4.state == ai_4.RIGHT_MOVE):
                  if ai_4.x < in_tile.x:
                      ai_4.x-=5
                      ai_4.state=random.randint(1,4)
              elif (ai_4.state == ai_4.UP_MOVE):
                  if ai_4.y < in_tile.y:
                      ai_4.y-=5
                      ai_4.state=random.randint(1,4)
                  while 1:
                    if(ai_4.state == ai_4.UP_MOVE):
                        ai_4.state=random.randint(1,4)
                    else:
                        break;
              elif (ai_4.state == ai_4.LEFT_MOVE):
                  if ai_4.x > in_tile.x:
                      ai_4.x+=5
                      ai_4.state=random.randint(1,4)
                  while 1:
                     if(ai_4.state == ai_4.LEFT_MOVE):
                         ai_4.state=random.randint(1,4)
                     else:
                        break;
              elif (ai_4.state == ai_4.DOWN_MOVE):
                   if ai_4.y > in_tile.y:
                       ai_4.y+=5
                       ai_4.state=random.randint(1,4)

          #.......AI_4 Attack.......#
          if collide2(ai_ranger_4,in_tile,ai_4.x,ai_4.y):
              ai_ranger_4.old_x = 0
              ai_ranger_4.old_y = 0

              if ai_4.state == ai_4.LEFT_MOVE:
                  if ai_4.x + ai_ranger_4.x  < in_tile.x:
                      ai_ranger_4.old_x = ai_ranger_4.x
                      effect.effect_ai4_switch = True
                      ai_ranger_4.x = 0

              if ai_4.state == ai_4.RIGHT_MOVE:
                  if ai_4.x + ai_ranger_4.x  > in_tile.x:
                      ai_ranger_4.old_x = ai_ranger_4.x
                      effect.effect_ai4_switch = True
                      ai_ranger_4.x = 0

              if ai_4.state == ai_4.UP_MOVE:
                  if ai_4.y + ai_ranger_4.y + 25 > in_tile.y: # yPos +25 보정값
                      ai_ranger_4.old_y = ai_ranger_4.y
                      effect.effect_ai4_switch = True
                      ai_ranger_4.y = 0

              if ai_4.state == ai_4.DOWN_MOVE:
                  if ai_4.y + ai_ranger_4.y < in_tile.y:
                      ai_ranger_4.old_y = ai_ranger_4.y
                      effect.effect_ai4_switch = True
                      ai_ranger_4.y = 0
#.........................................................................#




#........Update........#

    #Timer
    timer += frame_time

    #Player 관련
    player.update(frame_time)
    ranger.AttackUpdate(frame_time,player.state, player.RIGHT_ATTACK, player.LEFT_ATTACK, player.UP_ATTACK, player.DOWN_ATTACK)

    #Effect 관련
    effect.update()
    effect_2.update(frame_time)

    #Auto 관련
    auto_down_ranger.DownAttackUpdate(frame_time,auto_down_attack_object.state,auto_down_attack_object.DOWN_ATTACK )
    auto_left_ranger.LeftAttackUpdate(frame_time,auto_left_attack_object.state,auto_left_attack_object.LEFT_ATTACK)
    auto_right_ranger.RightAttackUpdate(frame_time,auto_right_attack_object.state,auto_right_attack_object.RIGHT_ATTACK)

    #AI 관련
    if ai_1.switch == True:
        ai_ranger_1.AttackUpdate(frame_time,ai_1.state, ai_1.RIGHT_MOVE, ai_1.LEFT_MOVE, ai_1.UP_MOVE, ai_1.DOWN_MOVE)
        ai_1.update(frame_time)

    if ai_2.switch == True:
        ai_ranger_2.AttackUpdate(frame_time,ai_2.state, ai_2.RIGHT_MOVE, ai_2.LEFT_MOVE, ai_2.UP_MOVE, ai_2.DOWN_MOVE)
        ai_2.update(frame_time)

    if ai_3.switch == True:
       ai_ranger_3.AttackUpdate(frame_time,ai_3.state, ai_3.RIGHT_MOVE, ai_3.LEFT_MOVE, ai_3.UP_MOVE, ai_3.DOWN_MOVE)
       ai_3.update(frame_time)

    if ai_4.switch == True:
      ai_ranger_4.AttackUpdate(frame_time,ai_4.state, ai_4.RIGHT_MOVE, ai_4.LEFT_MOVE, ai_4.UP_MOVE, ai_4.DOWN_MOVE)
      ai_4.update(frame_time)

    #Change -> End_State
    if timer > 180:
       game_framework.change_state(end_state)

    elif player.BJ_count == 3 and player.RJ_count == 3 and player.YJ_count == 3 and player.GJ_count == 3:
       player.end_switch = True

    elif player.live == 0 and player.hp == 0:
        game_framework.change_state(end_state)







def draw(frame_time):
    clear_canvas()

    #........Draw Background & White Board........#
    background.draw()
    ui_board.draw()

    #........Draw Tile.........#
    for out_tile in out_tiles:
        out_tile.draw()
        #out_tile.draw_bb()

    for in_tile in in_tiles:
        in_tile.draw()



    #........Draw Jewely.........#
    for red_jewelry in red_jewelrys:
        red_jewelry.draw()
        #red_jewelry.draw_bb()

    for green_jewelry in green_jewelrys:
        green_jewelry.draw()
        #green_jewelry.draw_bb()

    for yellow_jewelry in yellow_jewelrys:
        yellow_jewelry.draw()
        #yellow_jewelry.draw_bb()

    for blue_jewelry in blue_jewelrys:
        blue_jewelry.draw()


    #........Draw Font.........#
    ui_font.draw(810,550, 'Timer : %3.2f' % (timer),(0,255,0))
    ui_font.draw(810,500, '- Player ',(0,0,0))
    font.draw(830,460, 'HP : %d' % (player.hp),(255,0,0))
    font.draw(830,420, 'Live : %d' % (player.live),(255,0,0))
    font.draw(830,340, 'Power : %d' % (player.power),(0,0,255))
    font.draw(830,300, 'Score : %d' % (player.score),(0,0,0))
    ui_font.draw(810,250, '- Jewelry',(0,0,0))
    font.draw(830,210, 'Blue : %d' % (player.BJ_count),(0,0,255))
    font.draw(830,170, 'Red : %d' % (player.RJ_count),(255,0,0))
    font.draw(830,130, 'Yellow : %d' % (player.YJ_count),(255,255,0))
    font.draw(830,90, 'Green : %d' % (player.GJ_count),(0,255,0))


    if player.power == 30:
        font.draw(830,380, 'WP Type : Basic' ,(0,0,255))
    if player.power == 50:
        font.draw(830,380, 'WP Type : Middle' ,(0,0,255))
    if player.power == 100:
        font.draw(830,380, 'WP Type : High' ,(0,0,255))



    #........Player관련 Draw.........#
    player.draw()
    ranger.AttackDraw(player.x, player.y,player.state,player.RIGHT_ATTACK,player.LEFT_ATTACK,player.UP_ATTACK,player.DOWN_ATTACK) #원거리 공격 Draw
    effect.draw(player.x + ranger.old_x, player.y + ranger.old_y,player.state,player.LEFT_ATTACK,player.RIGHT_ATTACK,player.DOWN_ATTACK,player.UP_ATTACK)


    #........Auto관련 Draw.........#
    auto_down_attack_object.draw()
    auto_left_attack_object.draw()
    auto_right_attack_object.draw()


    # Down #
    if auto_down_ranger.switch_1 == True:
        auto_down_ranger.DownAttackDraw(auto_down_attack_object.object_x1,auto_down_attack_object.object_y1)
        effect_2.auto_down_draw_1(auto_down_attack_object.object_x1 + auto_down_ranger.x1 ,auto_down_attack_object.object_y1 + auto_down_ranger.old_y1, auto_down_attack_object.state, auto_down_attack_object.DOWN_ATTACK,auto_down_ranger.y1)
    if auto_down_ranger.switch_2 == True:
        auto_down_ranger.DownAttackDraw(auto_down_attack_object.object_x2,auto_down_attack_object.object_y2)
        effect_2.auto_down_draw_2(auto_down_attack_object.object_x2 + auto_down_ranger.x2 ,auto_down_attack_object.object_y2 + auto_down_ranger.old_y2, auto_down_attack_object.state, auto_down_attack_object.DOWN_ATTACK,auto_down_ranger.y2)
    if auto_down_ranger.switch_3 == True:
        auto_down_ranger.DownAttackDraw(auto_down_attack_object.object_x3,auto_down_attack_object.object_y3)
        effect_2.auto_down_draw_3(auto_down_attack_object.object_x3 + auto_down_ranger.x3 ,auto_down_attack_object.object_y3 + auto_down_ranger.old_y3, auto_down_attack_object.state, auto_down_attack_object.DOWN_ATTACK,auto_down_ranger.y3)
    if auto_down_ranger.switch_4 == True:
        auto_down_ranger.DownAttackDraw(auto_down_attack_object.object_x4,auto_down_attack_object.object_y4)
        effect_2.auto_down_draw_4(auto_down_attack_object.object_x4 + auto_down_ranger.x4 ,auto_down_attack_object.object_y4 + auto_down_ranger.old_y4, auto_down_attack_object.state, auto_down_attack_object.DOWN_ATTACK,auto_down_ranger.y4)


     # Left #
    if auto_left_ranger.switch_1 == True:
       auto_left_ranger.LeftAttackDraw(auto_left_attack_object.object_x1,auto_left_attack_object.object_y1)
       effect_2.auto_left_draw_1(auto_left_attack_object.object_x1 + auto_left_ranger.old_x1,auto_left_attack_object.object_y1 + auto_left_ranger.y1,auto_left_attack_object.state,auto_left_attack_object.LEFT_ATTACK,auto_left_ranger.x1)
    if auto_left_ranger.switch_2 == True:
       auto_left_ranger.LeftAttackDraw(auto_left_attack_object.object_x2,auto_left_attack_object.object_y2)
       effect_2.auto_left_draw_2(auto_left_attack_object.object_x2 + auto_left_ranger.old_x2,auto_left_attack_object.object_y2 + auto_left_ranger.y2,auto_left_attack_object.state,auto_left_attack_object.LEFT_ATTACK,auto_left_ranger.x2)

    # Right #
    if auto_right_ranger.switch == True:
       auto_right_ranger.RightAttackDraw(auto_right_attack_object.object_x1,auto_right_attack_object.object_y1)
       effect_2.auto_right_draw(auto_right_attack_object.object_x1 + auto_right_ranger.old_x1,auto_right_attack_object.object_y1 + auto_right_ranger.y1,auto_right_attack_object.state,auto_right_attack_object.RIGHT_ATTACK,auto_right_ranger.x1)
    if auto_right_ranger.switch_2 == True:
       auto_right_ranger.RightAttackDraw(auto_right_attack_object.object_x2,auto_right_attack_object.object_y2)
       effect_2.auto_right_draw_2(auto_right_attack_object.object_x2 + auto_right_ranger.old_x2,auto_right_attack_object.object_y2 + auto_right_ranger.y2,auto_right_attack_object.state,auto_right_attack_object.RIGHT_ATTACK,auto_right_ranger.x2)


    #........Draw AI.........#
    if ai_1.switch == True:
        ai_ranger_1.AttackDraw(ai_1.x, ai_1.y,ai_1.state,ai_1.RIGHT_MOVE,ai_1.LEFT_MOVE,ai_1.UP_MOVE,ai_1.DOWN_MOVE) # AI 원거리 공격 Draw
        effect.ai1_draw(ai_1.x + ai_ranger_1.old_x,ai_1.y + ai_ranger_1.old_y,ai_1.state,ai_1.LEFT_MOVE,ai_1.RIGHT_MOVE,ai_1.DOWN_MOVE,ai_1.UP_MOVE ) # AI Effect
        ai_1.draw()

    if ai_2.switch == True:
       ai_ranger_2.AttackDraw(ai_2.x, ai_2.y,ai_2.state,ai_2.RIGHT_MOVE,ai_2.LEFT_MOVE,ai_2.UP_MOVE,ai_2.DOWN_MOVE) # AI 원거리 공격 Draw
       effect.ai2_draw(ai_2.x + ai_ranger_2.old_x,ai_2.y + ai_ranger_2.old_y,ai_2.state,ai_2.LEFT_MOVE,ai_2.RIGHT_MOVE,ai_2.DOWN_MOVE,ai_2.UP_MOVE ) # AI Effect
       ai_2.draw()

    if ai_3.switch == True:
        ai_ranger_3.AttackDraw(ai_3.x, ai_3.y,ai_3.state,ai_3.RIGHT_MOVE,ai_3.LEFT_MOVE,ai_3.UP_MOVE,ai_3.DOWN_MOVE) # AI 원거리 공격 Draw
        effect.ai3_draw(ai_3.x + ai_ranger_3.old_x,ai_3.y + ai_ranger_3.old_y,ai_3.state,ai_3.LEFT_MOVE,ai_3.RIGHT_MOVE,ai_3.DOWN_MOVE,ai_3.UP_MOVE ) # AI Effect
        ai_3.draw()

    if ai_4.switch == True:
        ai_ranger_4.AttackDraw(ai_4.x, ai_4.y,ai_4.state,ai_4.RIGHT_MOVE,ai_4.LEFT_MOVE,ai_4.UP_MOVE,ai_4.DOWN_MOVE) # AI 원거리 공격 Draw
        effect.ai4_draw(ai_4.x + ai_ranger_4.old_x,ai_4.y + ai_ranger_4.old_y,ai_4.state,ai_4.LEFT_MOVE,ai_4.RIGHT_MOVE,ai_4.DOWN_MOVE,ai_4.UP_MOVE ) # AI Effect
        ai_4.draw()



    #........Draw Object........#

    #HP Item
    hp_object.draw()
    power_object.draw()




    update_canvas()












