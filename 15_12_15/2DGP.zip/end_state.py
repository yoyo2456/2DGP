__author__ = 'Administrator'

import os, sys,json, random
import game_framework
import main_state



from pico2d import *
from sdl2 import *
from sdl2.sdlimage import *
from sdl2.sdlttf import *
from sdl2.sdlmixer import *



name = "TitleState"
image = None
bgm = None


ui_font = None
end_font_1 = None
end_font_2 = None



def get_frame_time():

    global current_time, end_frame_timem, frame_time
    frame_time = SDL_GetTicks() / 1000.0
    return frame_time





def enter():

    global image, end_font_1, end_font_2
    global player
    global end_switch

    image = load_image('resource\\EndState\\end.png')
    end_font_1 = end_load_font_1('Font\\2DGP.TTF')
    end_font_2 = end_load_font_2('Font\\2DGP.TTF')





def exit():
    global image
    del(image)



def handle_events(frame_time):
    events = get_events()
    for event in events:
        if event.type == SDL_QUIT:
            game_framework.quit()
        else:
            if(event.type, event.key) == (SDL_KEYDOWN, SDLK_r):
                game_framework.change_state(main_state)
            elif(event.type, event.key) == (SDL_KEYDOWN, SDLK_SPACE):
                game_framework.quit()




def draw(frame_time):
    clear_canvas()
    image.draw(500,300)
    update_canvas()



def update(frame_time):
    pass


def pause():
    pass


def resume():
    pass






